/*
 * Copyright (C) 2026 piko <https://github.com/crimera/piko>
 *
 * See the included NOTICE file for GPLv3 §7(b) terms that apply to this code.
 */


package app.morphe.extension.instagram.constants;

import static app.morphe.extension.instagram.utils.IgStr.str;

import app.morphe.extension.crimera.constants.ExtensionStrings;
import app.morphe.extension.crimera.downloader.StorageUtils;
import app.morphe.extension.instagram.settings.ActivityHook;

public class Constants {
    public static final String PIKO = "piko";
    public static final String PIKO_SETTINGS = PIKO + "_settings";
    public static final String SHARED_PREF_NAME = PIKO_SETTINGS;
    public static final String DEFAULT_PIKO_FOLDER = "Piko-Instagram";
    public static final String DEFAULT_AUDIO_FOLDER = "Audio";
    public static final String DEFAULT_DM_FOLDER = "DM";
    public static final String DEFAULT_GIF_FOLDER = "Gif";
    public static final String INSTAGRAM_SHARE_LINK = "https://www.instagram.com/%s/%s/";
    // https://www.instagram.com/p/<short code>/
    // https://www.instagram.com/reel/<short code>/
    // https://www.instagram.com/stories/<user name>/<post id>
    public static final String REC_FLAGS = PIKO + "_recommended_flags_v3";
    public static final String PIKO_MAPPINGS_PATH = "https://github.com/crimera/piko/raw/refs/heads/dev/docs/mappings/";

    public static final String AB_SETTINGS_ICON = "SETTINGS_ICON";
    public static final String AB_AUDIO_CALL_ICON = "AUDIO_CALL_ICON";
    public static final String AB_VIDEO_CALL_ICON = "VIDEO_CALL_ICON";
    public static final String AB_CREATE = "CREATE";
    public static final String AB_NOTIFICATIONS = "NOTIFICATIONS";
    public static final String AB_GHOST_MODE_ICON = "GHOST_MODE_ICON";
    public static final String AB_JUMP_OLDEST_ICON = "JUMP_OLDEST_ICON";
    public static final String AB_PROFILE_INFO_ICON = "PROFILE_INFO_ICON";

    public static final String PIKO_FRAGMENT_TITLE = "piko_frag_title";
    public static final String PIKO_FRAGMENT_NAME = "piko_frag_name";
    public static final String PIKO_SEARCH_TARGET_PREFERENCE_KEY = "piko_search_target_preference_key";
    public static final String PIKO_APP_VERSION_PREFERENCE = "piko_app_version_preference";
    public static final String PIKO_PATCH_VERSION_PREFERENCE = "piko_patch_version_preference";
    public static final String PIKO_PATCH_INFO_PREFERENCE_CATEGORY = "piko_patch_info_preference_category";

    public static final String PIKO_FRAGMENT_SETTINGS = "piko_frag_settings";
    public static final String PIKO_FRAGMENT_ADS = "piko_frag_ads";
    public static final String PIKO_FRAGMENT_GHOST = "piko_frag_ghost";
    public static final String PIKO_FRAGMENT_STORY = "piko_frag_story";
    public static final String PIKO_FRAGMENT_LINKS = "piko_frag_links";
    public static final String PIKO_FRAGMENT_DISTRACTION_FREE = "piko_frag_distraction_free";
    public static final String PIKO_FRAGMENT_FOCUS_LOCK = "piko_frag_focus_lock";
    public static final String PIKO_FRAGMENT_MISC = "piko_frag_misc";
    public static final String PIKO_FRAGMENT_DOWNLOAD_MEDIA = "piko_frag_download_media";
    public static final String PIKO_FRAGMENT_NAV_BTNS = "piko_frag_nav_btns";
    public static final String PIKO_FRAGMENT_DEV_OPTIONS = "piko_frag_dev_options";
    public static final String PIKO_FRAGMENT_ABOUT = "piko_frag_about";
    public static final String PIKO_FRAGMENT_ACTION_BAR = "piko_frag_action_bar";
    public static final String PIKO_FRAGMENT_DM = "piko_frag_dm";
    public static final String PIKO_FRAGMENT_FILTER_CONTENT = "piko_frag_filter_content";
    public static final String PIKO_FRAGMENT_REC_FLAGS = "piko_frag_rec_flags";
    public static final String PIKO_FRAGMENT_INSTANTS = "piko_frag_instants";
    public static final String PIKO_FRAGMENT_FONT = "piko_frag_font";

    public static void load() {
        app.morphe.extension.instagram.patches.navigation.FloatingNavBar.start();
        StorageUtils.setStorageAccessLauncher(ctx -> ActivityHook.launchFragment(ctx, "piko_download_set_path"));
        ExtensionStrings.setDefaultPikoFolder(Constants.DEFAULT_PIKO_FOLDER);
        ExtensionStrings.setDownloadOngoing(str("piko_downloading_media"));
        ExtensionStrings.setDownloadCompleted(str("piko_downloaded_media"));
        ExtensionStrings.setDownloadError(str("piko_download_failed_media"));
        ExtensionStrings.setDownloadSetPathFailed(str("piko_download_set_path_failed"));
        ExtensionStrings.setDownloadSetPathSuccess(str("piko_download_set_path_success"));
        ExtensionStrings.setDownloadGrantPermission(str("piko_download_choose_folder"));
        ExtensionStrings.setDownloadGrantPermissionFailed(str("piko_download_choose_folder_failed"));
    }
}
