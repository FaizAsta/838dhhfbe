/*
 * Copyright (C) 2026 piko <https://github.com/crimera/piko>
 *
 * See the included NOTICE file for GPLv3 §7(b) terms that apply to this code.
 */


package app.morphe.extension.instagram.settings.preference;

import static app.morphe.extension.instagram.utils.IgStr.str;

import android.content.Context;
import android.preference.PreferenceScreen;
import android.preference.Preference;
import android.preference.PreferenceCategory;
import android.text.format.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TreeMap;
import java.util.Map;
import java.util.List;
import java.util.Locale;

import app.morphe.extension.instagram.patches.devFlags.RecommendedFlags;
import app.morphe.extension.instagram.patches.devFlags.Flag;

import app.morphe.extension.crimera.downloader.StorageUtils;
import app.morphe.extension.crimera.sharedPreference.SharedPref;
import app.morphe.extension.instagram.patches.Links;
import app.morphe.extension.instagram.patches.customise.font.FontStorage;
import app.morphe.extension.instagram.patches.focusLock.FocusLock;
import app.morphe.extension.instagram.patches.focusLock.FocusLockTargets;
import app.morphe.extension.instagram.settings.SettingsStatus;
import app.morphe.extension.instagram.settings.BooleanSetting;
import app.morphe.extension.instagram.settings.Settings;
import app.morphe.extension.instagram.settings.preference.widgets.*;
import app.morphe.extension.shared.Utils;
import app.morphe.extension.instagram.utils.Pref;
import app.morphe.extension.instagram.constants.Constants;
import app.morphe.extension.instagram.theme.MaterialYouTheme;

public class ScreenBuilder {
    private final Context context;
    private final PreferenceScreen screen;
    private final Helper helper;
    private final List<DashboardRowPref.Tile> pendingTiles = new ArrayList<>();
    private boolean dashboardLayout;
    /** True while the search index is built: pages that hide rows behind buttons must then show every row. */
    private boolean searchIndexing;
    /** The row a search result leads to, so a page with buttons can open on the button that holds it. */
    private String targetPreferenceKey;

    public ScreenBuilder(Context context, PreferenceScreen screen, Helper helper) {
        this.context = context;
        this.screen = screen;
        this.helper = helper;
    }

    /** Shows the root page as a dashboard of tiles. Leave off for search indexing. */
    public ScreenBuilder dashboard(boolean enabled) {
        this.dashboardLayout = enabled;
        return this;
    }

    /** The key of the row the person is going to (from a search result), or null. */
    public ScreenBuilder targetPreference(String preferenceKey) {
        this.targetPreferenceKey = preferenceKey;
        return this;
    }

    public void buildFragment(String fragmentName) {
        if (Constants.PIKO_FRAGMENT_SETTINGS.equals(fragmentName)) {
            buildSettingsPage();
        } else if (Constants.PIKO_FRAGMENT_ADS.equals(fragmentName)) {
            buildAdsSection();
        } else if (Constants.PIKO_FRAGMENT_GHOST.equals(fragmentName)) {
            ghostSection();
        } else if (Constants.PIKO_FRAGMENT_STORY.equals(fragmentName)) {
            storySection();
        } else if (Constants.PIKO_FRAGMENT_LINKS.equals(fragmentName)) {
            linksSection();
        } else if (Constants.PIKO_FRAGMENT_DISTRACTION_FREE.equals(fragmentName)) {
            distractionFreeSection();
        } else if (Constants.PIKO_FRAGMENT_MISC.equals(fragmentName)) {
            buildMiscSection();
        } else if (Constants.PIKO_FRAGMENT_DOWNLOAD_MEDIA.equals(fragmentName)) {
            buildDownloadSection();
        } else if (Constants.PIKO_FRAGMENT_NAV_BTNS.equals(fragmentName)) {
            buildNavigationSection();
        } else if (Constants.PIKO_FRAGMENT_DEV_OPTIONS.equals(fragmentName)) {
            buildDeveloperSection();
        } else if (Constants.PIKO_FRAGMENT_ABOUT.equals(fragmentName)) {
            aboutSection(SettingsStatus.FLAGS);
        } else if (Constants.PIKO_FRAGMENT_ACTION_BAR.equals(fragmentName)) {
            buildActionBarSection();
        } else if (Constants.PIKO_FRAGMENT_DM.equals(fragmentName)) {
            dmSection();
        } else if (Constants.PIKO_FRAGMENT_FILTER_CONTENT.equals(fragmentName)) {
            filterContentSection();
        } else if (Constants.PIKO_FRAGMENT_REC_FLAGS.equals(fragmentName)) {
            buildRecommendedFlagsSection();
        } else if (Constants.PIKO_FRAGMENT_FOCUS_LOCK.equals(fragmentName)) {
            buildFocusLockSection();
        } else if (Constants.PIKO_FRAGMENT_INSTANTS.equals(fragmentName)) {
            buildInstantsSection();
        } else if (Constants.PIKO_FRAGMENT_FONT.equals(fragmentName)) {
            buildFontSection();
        }
    }

    public void buildFragmentForSearch(String fragmentName) {
        searchIndexing = true;
        if (Constants.PIKO_FRAGMENT_REC_FLAGS.equals(fragmentName)) {
            buildRecommendedFlagsSection(false);
        } else {
            buildFragment(fragmentName);
        }
    }

    private void addPreference(Preference pref) {
        addPreference(null, pref);
    }

    // Adding preference category might be used in the future
    // to segregate the preference inside the fragment
    private void addPreference(PreferenceCategory category, Preference pref) {
        if (category != null) {
            category.addPreference(pref);
        } else {
            screen.addPreference(pref);
        }
    }

    private PreferenceCategory addCategory(String title) {
        CategoryPref preferenceCategory = new CategoryPref(context);
        preferenceCategory.setFirstCategory(screen.getPreferenceCount() == 0);
        preferenceCategory.setTitle(title);
        screen.addPreference(preferenceCategory);
        return preferenceCategory;
    }

    public void buildAdsSection() {
        if (!(SettingsStatus.adsSection())) return;

        if (SettingsStatus.disableAds) {
            addPreference(
                    helper.switchPreference(
                            str("piko_disable_ads"),
                            "",
                            Settings.DISABLE_ADS
                    )
            );
        }
        if (SettingsStatus.hideSuggestedContent) {
            addPreference(
                    helper.switchPreference(
                            str("piko_hide_suggested_content"),
                            str("piko_hide_suggested_content_desc"),
                            Settings.HIDE_SUGGESTED_CONTENT
                    )
            );
        }
    }

    public void buildFontSection() {
        if (!(SettingsStatus.fontSection())) return;

        // Written here rather than left to the preference framework, which persists only after
        // this listener has run - FontStorage.useSystemFont() has to read the new value straight
        // away, from load() on the next start up.
        SwitchPref useSystemFont = new SwitchPref(context);
        useSystemFont.setTitle(str("piko_use_system_font"));
        useSystemFont.setSummary(str("piko_use_system_font_desc"));
        useSystemFont.setKey(Settings.USE_SYSTEM_FONT.key);
        useSystemFont.setPersistent(false);
        useSystemFont.setChecked(FontStorage.useSystemFont());
        useSystemFont.setOnPreferenceChangeListener((preference, newValue) -> {
            FontStorage.setUseSystemFont(Boolean.TRUE.equals(newValue));
            return true;
        });
        addPreference(useSystemFont);

        addPreference(helper.buttonPreference(
                str("piko_pref_add_font"),
                str("piko_pref_add_font_desc"),
                "piko_pref_add_font"
        ));

        addPreference(helper.buttonPreference(
                str("piko_pref_delete_font"),
                "",
                "piko_pref_delete_font"
        ));
    }

    public void buildDeveloperSection() {
        if (!(SettingsStatus.developerOptionsSection())) return;

        // PreferenceCategory category= addCategory(str("piko_category_dev_options"));
        if (SettingsStatus.recommendedFlags) {
            addPreference(
                    helper.buttonPreference(
                            str("piko_category_rec_flags"),
                            str("piko_category_rec_flags_desc"),
                            Constants.PIKO_FRAGMENT_REC_FLAGS
                    )
            );
        }

        if (SettingsStatus.unlockEmployeeOptions) {
            addPreference(
                    helper.switchPreference(
                            str("piko_enable_emp_options"),
                            str("piko_enable_emp_options_desc"),
                            Settings.ENABLE_EMP_OPTIONS
                    )
            );
        }
        if (SettingsStatus.allowUserNetworkCertificate) {
            addPreference(
                    helper.switchPreference(
                            str("piko_allow_user_network_certificate"),
                            str("piko_allow_user_network_certificate_desc"),
                            Settings.ALLOW_USER_NETWORK_CERTIFICATE
                    )
            );
        }
        if (SettingsStatus.enableDeveloperOptions) {
            addPreference(
                    helper.switchPreference(
                            str("piko_enable_dev_options"),
                            str("piko_enable_dev_options_desc"),
                            Settings.DEVELOPER_OPTIONS
                    )
            );
            addPreference(
                    helper.availableWhen(
                            helper.switchPreference(
                                    str("piko_directly_open_metaconfig"),
                                    str("piko_directly_open_metaconfig_desc"),
                                    Settings.DIRECTLY_OPEN_METACONFIG
                            ),
                            () -> SharedPref.getBooleanPref(Settings.DEVELOPER_OPTIONS)
                    )
            );
            addPreference(
                    helper.buttonPreference(
                            str("piko_export_dev_overrides"),
                            "",
                            "piko_export_dev_overrides"
                    )
            );
            addPreference(
                    helper.buttonPreference(
                            str("piko_import_dev_overrides"),
                            "",
                            "piko_import_dev_overrides"
                    )
            );
            addPreference(
                    helper.buttonPreference(
                            str("piko_import_id_mapping"),
                            "",
                            "piko_import_id_mapping"
                    )
            );
            addPreference(
                    helper.buttonPreference(
                            str("piko_download_id_mapping"),
                            "",
                            "piko_download_id_mapping"
                    )
            );

            if(Pref.pikoDebug()) {
                addPreference(
                        helper.buttonPreference(
                                str("piko_export_experiment_list"),
                                "",
                                "piko_export_experiment_list"
                        )
                );

                addPreference(
                        helper.buttonPreference(
                                str("piko_export_experiment_mappings"),
                                "",
                                "piko_export_experiment_mappings"
                        )
                );
            }
        }
    }

    public void dmSection() {
        if (!(SettingsStatus.dmSection())) return;

        if (SettingsStatus.disableDisappearingMessagesGesture) {
            addPreference(
                    helper.switchPreference(
                            str("piko_disable_disappearing_messages_gesture"),
                            str("piko_disable_disappearing_messages_gesture_desc"),
                            Settings.DISABLE_DISAPPEARING_MESSAGES_GESTURE
                    )
            );
        }

        if (SettingsStatus.unlimitedReplaysOnEphemeralMedia) {
            addPreference(
                    helper.switchPreference(
                            str("piko_unlimited_replays"),
                            str("piko_unlimited_replays_desc"),
                            Settings.UNLIMITED_REPLAYS
                    )
            );
            addPreference(
                    helper.switchPreference(
                            str("piko_ephemeral_caption"),
                            str("piko_ephemeral_caption_desc"),
                            Settings.EPHEMERAL_MEDIA_CAPTION
                    )
            );
        }

        if (SettingsStatus.markChatAsRead) {
            addPreference(
                    helper.switchPreference(
                            str("piko_enable_mark_chat_as_read"),
                            str("piko_enable_mark_chat_as_read_desc"),
                            Settings.ENABLE_MARK_CHAT_AS_READ
                    )
            );
        }

        if (SettingsStatus.inboxLock) {
            addPreference(
                    helper.switchPreference(
                            str("piko_inbox_lock"),
                            str("piko_inbox_lock_desc"),
                            Settings.INBOX_LOCK
                    )
            );
            addPreference(
                    helper.availableWhen(
                            helper.switchPreference(
                                    str("piko_inbox_lock_notifications"),
                                    str("piko_inbox_lock_notifications_desc"),
                                    Settings.INBOX_LOCK_NOTIFICATIONS
                            ),
                            () -> SharedPref.getBooleanPref(Settings.INBOX_LOCK)
                    )
            );
        }

        if (SettingsStatus.hiddenChats) {
            addPreference(
                    helper.switchPreference(
                            str("piko_hidden_chats"),
                            str("piko_hidden_chats_desc"),
                            Settings.HIDDEN_CHATS
                    )
            );
            addPreference(
                    helper.availableWhen(
                            helper.listPreference(
                                    str("piko_hidden_chats_taps"),
                                    str("piko_hidden_chats_taps_desc"),
                                    Settings.HIDDEN_CHATS_TAPS
                            ),
                            () -> SharedPref.getBooleanPref(Settings.HIDDEN_CHATS)
                    )
            );
            addPreference(
                    helper.availableWhen(
                            helper.switchPreference(
                                    str("piko_hidden_chats_mute"),
                                    str("piko_hidden_chats_mute_desc"),
                                    Settings.HIDDEN_CHATS_MUTE
                            ),
                            () -> SharedPref.getBooleanPref(Settings.HIDDEN_CHATS)
                    )
            );
        }

        if (SettingsStatus.saveDeletedMessages) {
            addPreference(
                    helper.switchPreference(
                            str("piko_save_deleted_messages"),
                            str("piko_save_deleted_messages_desc"),
                            Settings.SAVE_DELETED_MESSAGES
                    )
            );
            addPreference(
                    helper.buttonPreference(
                            str("piko_view_deleted_messages"),
                            "",
                            "view_deleted_messages"
                    )
            );
        }
    }

    public void ghostSection() {
        if (!(SettingsStatus.ghostSection())) return;

        // PreferenceCategory category= addCategory(str("piko_category_ghost"));

        addPreference(
                helper.switchPreference(
                        str("piko_turn_on_all_ghost_modes"),
                        "",
                        Settings.TURN_ON_ALL_GHOST_MODES
                )
        );

        if (SettingsStatus.viewStoriesAnonymously) {
            addPreference(
                    helper.switchPreference(
                            str("piko_view_stories_anonymously"),
                            "",
                            Settings.VIEW_STORIES_ANONYMOUSLY
                    )
            );
        }
        if (SettingsStatus.viewLiveAnonymously) {
            addPreference(
                    helper.switchPreference(
                            str("piko_view_live_anonymously"),
                            "",
                            Settings.VIEW_LIVE_ANONYMOUSLY
                    )
            );
        }
        if (SettingsStatus.disableTypingStatus) {
            addPreference(
                    helper.switchPreference(
                            str("piko_disable_typing_status"),
                            "",
                            Settings.DISABLE_TYPING_STATUS
                    )
            );
        }
        if (SettingsStatus.disableScreenshotDetection) {
            addPreference(
                    helper.switchPreference(
                            str("piko_disable_screenshot_detection"),
                            "",
                            Settings.DISABLE_SCREENSHOT_DETECTION
                    )
            );
        }
        if (SettingsStatus.viewDmAnonymously) {
            addPreference(
                    helper.switchPreference(
                            str("piko_view_dm_anonymously"),
                            str("piko_view_dm_anonymously_desc"),
                            Settings.VIEW_DM_ANONYMOUSLY
                    )
            );
        }
        if (SettingsStatus.markAsReadAfterReply) {
            addPreference(
                    helper.availableWhen(
                            helper.switchPreference(
                                    str("piko_mark_as_read_after_reply"),
                                    str("piko_mark_as_read_after_reply_desc"),
                                    Settings.MARK_AS_READ_AFTER_REPLY
                            ),
                            () -> SharedPref.getBooleanPref(Settings.VIEW_DM_ANONYMOUSLY)
                                    || SharedPref.getBooleanPref(Settings.TURN_ON_ALL_GHOST_MODES)
                    )
            );
        }

    }

    public void linksSection() {
        if (!(SettingsStatus.linksSection())) return;

        // PreferenceCategory category= addCategory(str("piko_category_links"));
        if (SettingsStatus.openLinksExternally) {
            addPreference(
                    helper.switchPreference(
                            str("piko_open_links_externally"),
                            str("piko_open_links_externally_desc"),
                            Settings.OPEN_LINKS_EXTERNALLY
                    )
            );
        }
        if (SettingsStatus.sanitizeShareLinks) {
            addPreference(
                    helper.switchPreference(
                            str("piko_sanitize_share_links"),
                            "",
                            Settings.SANITIZE_SHARE_LINKS
                    )
            );
        }
        if (SettingsStatus.customSharingDomain) {
            addPreference(
                    helper.editTextPreference(
                            str("piko_custom_sharing_domain"),
                            Links.customSharingDomainSummary(Pref.customSharingDomain()),
                            Settings.CUSTOM_SHARING_DOMAIN
                    )
            );
        }
    }

    public void distractionFreeSection() {
        if (!(SettingsStatus.distractionFreeSection())) return;

        // PreferenceCategory category= addCategory(str("piko_category_distraction_free"));

        if (SettingsStatus.focusLock) {
            addPreference(
                    helper.buttonPreference(
                            str("piko_focus_lock"),
                            FocusLock.statusSummary(),
                            Constants.PIKO_FRAGMENT_FOCUS_LOCK
                    )
            );
        }

        if (SettingsStatus.disableStories) {
            addLockableSwitch(
                    str("piko_disable_stories"),
                    "",
                    Settings.DISABLE_STORIES
            );
        }
        if (SettingsStatus.hideStoriesTray) {
            addLockableSwitch(
                    str("piko_hide_stories_tray"),
                    str("piko_hide_stories_tray_desc"),
                    Settings.HIDE_STORIES_TRAY
            );
        }
        if (SettingsStatus.hideHiddenRequests) {
            addLockableSwitch(
                    str("piko_hide_hidden_requests"),
                    str("piko_hide_hidden_requests_desc"),
                    Settings.HIDE_HIDDEN_REQUESTS
            );
        }
        if (SettingsStatus.disableHighlights) {
            addLockableSwitch(
                    str("piko_disable_highlights"),
                    "",
                    Settings.DISABLE_HIGHLIGHTS
            );
        }
        if (SettingsStatus.hideNotesTray) {
            addLockableSwitch(
                    str("piko_hide_notes_tray"),
                    str("piko_hide_notes_tray_desc"),
                    Settings.HIDE_NOTES_TRAY
            );
        }
        if (SettingsStatus.disableExplore) {
            addLockableSwitch(
                    str("piko_disable_explore"),
                    "",
                    Settings.DISABLE_EXPLORE
            );
        }
        if (SettingsStatus.disableComments) {
            addLockableSwitch(
                    str("piko_disable_comments"),
                    "",
                    Settings.DISABLE_COMMENTS
            );
        }
        if (SettingsStatus.hideFeedPosts) {
            addPreference(
                    helper.switchPreference(
                            str("piko_hide_feed_posts"),
                            str("piko_hide_feed_posts_desc"),
                            Settings.HIDE_FEED_POSTS
                    )
            );
        }
        if (SettingsStatus.limitFollowingFeed) {
            addLockableSwitch(
                    str("piko_limit_following_feed"),
                    str("piko_limit_following_feed_desc"),
                    Settings.LIMIT_FOLLOWING_FEED
            );
        }
        if (SettingsStatus.disableDiscoverPeople) {
            addPreference(
                    helper.switchPreference(
                            str("piko_disable_discover_people"),
                            "",
                            Settings.DISABLE_DISCOVER_PEOPLE
                    )
            );
        }
        if (SettingsStatus.disableReelsScrolling) {
            addLockableSwitch(
                    str("piko_disable_reels_scrolling"),
                    str("piko_disable_reels_scrolling_desc"),
                    Settings.DISABLE_REELS_SCROLLING
            );
        }
        if (SettingsStatus.disableSwipeToCreate) {
            addLockableSwitch(
                    str("piko_disable_swipe_to_create"),
                    str("piko_disable_swipe_to_create_desc"),
                    Settings.DISABLE_SWIPE_TO_CREATE
            );
        }
        if (SettingsStatus.hideGroupCreationOnSharesheet) {
            addLockableSwitch(
                    str("piko_hide_group_creation_button_on_sharesheet"),
                    "",
                    Settings.HIDE_GROUP_CREATION_BUTTON_ON_SHARESHEET
            );
        }
        if (SettingsStatus.hideReelsFollowButton) {
            addLockableSwitch(
                    str("piko_hide_reels_follow_button"),
                    str("piko_hide_reels_follow_button_desc"),
                    Settings.HIDE_REELS_FOLLOW_BUTTON
            );
        }
        if (SettingsStatus.hideLikes) {
            addPreference(
                    helper.switchPreference(
                            str("piko_hide_likes"),
                            "",
                            Settings.HIDE_LIKES
                    )
            );
        }
        if (SettingsStatus.hideShareButton) {
            addPreference(
                    helper.switchPreference(
                            str("piko_hide_share_button"),
                            "",
                            Settings.HIDE_SHARE_BUTTON
                    )
            );
        }
        if (SettingsStatus.hideSaveButtons) {
            addPreference(
                    helper.multiSelectListPref(
                            str("piko_hide_save_buttons"),
                            "",
                            Settings.HIDE_SAVE_BUTTON_SURFACES
                    )
            );
        }
        if (SettingsStatus.hideReshareButton) {
            addPreference(
                    helper.switchPreference(
                            str("piko_hide_reshare_button"),
                            "",
                            Settings.HIDE_RESHARE_BUTTON
                    )
            );
        }
        if (SettingsStatus.disableVideoAutoplay) {
            addPreference(
                    helper.switchPreference(
                            str("piko_disable_video_autoplay"),
                            "",
                            Settings.DISABLE_VIDEO_AUTOPLAY
                    )
            );
        }
        if (SettingsStatus.disableDoubleTapLike) {
            addLockableSwitch(
                    str("piko_disable_double_tap_like"),
                    "",
                    Settings.DISABLE_DOUBLE_TAP_LIKE
            );
        }
    }

    /** Adds a Distraction free switch, shown forced on while Focus Lock holds it. */
    private void addLockableSwitch(String title, String summary, BooleanSetting setting) {
        addPreference(
                helper.forcedSwitchPreference(
                        title,
                        summary,
                        setting,
                        FocusLock.isForced(setting),
                        str("piko_focus_lock_enforced")
                )
        );
    }

    /**
     * The Focus Lock screen: what to hold, for how long, and the lock itself.
     *
     * The picker lists the same settings as the Distraction free screen, by the same names, so
     * it is obvious what each entry will do. Everything except the action row is disabled while
     * the lock is on, since changing it then would defeat the point.
     */
    public void buildFocusLockSection() {
        if (!SettingsStatus.focusLock) return;

        boolean locked = FocusLock.isActive();

        addPreference(
                helper.buttonPreference(
                        FocusLock.buttonTitle(),
                        FocusLock.statusSummary(),
                        "piko_focus_lock_action"
                )
        );

        FocusLockDurationPreference duration = new FocusLockDurationPreference(context);
        duration.setTitle(str("piko_focus_lock_duration"));
        duration.setEnabled(!locked);
        addPreference(duration);

        PreferenceCategory targets = addCategory(str("piko_focus_lock_targets"));
        for (FocusLockTargets.Target target : FocusLockTargets.available()) {
            Preference pref = helper.switchPreference(
                    str(target.titleKey),
                    target.summaryKey == null ? "" : str(target.summaryKey),
                    Pref.focusLockSelection(target.key)
            );
            if (locked && pref instanceof SwitchPref) {
                ((SwitchPref) pref).setSwitchInteractionEnabled(false);
            }
            addPreference(targets, pref);
        }
    }

    public void buildMiscSection() {
        if (!(SettingsStatus.miscSection())) return;

        // PreferenceCategory category= addCategory(str("piko_category_misc"));
        if (MaterialYouTheme.isAmoledAvailable()) {
            addPreference(
                    helper.availableWhen(
                            helper.switchPreference(
                                    str("piko_amoled_title"),
                                    "",
                                    Settings.AMOLED_THEME
                            ),
                            () -> MaterialYouTheme.canEnableAmoled(context)
                    )
            );
        }
        if (MaterialYouTheme.isMaterialYouAvailable()) {
            addPreference(
                    helper.switchPreference(
                            str("piko_material_you_title"),
                            "",
                            Settings.MATERIAL_YOU_THEME
                    )
            );
        }
        if (SettingsStatus.fontSection()) {
            addPreference(
                    helper.buttonPreference(
                            str("piko_category_font"),
                            "",
                            Constants.PIKO_FRAGMENT_FONT
                    )
            );
        }
        if (SettingsStatus.changeLikeAnimation) {
            addPreference(
                    helper.listPreference(
                            str("piko_change_like_animation"),
                            str("piko_change_like_animation_desc"),
                            Settings.CHANGE_LIKE_ANIMATION
                    )
            );
        }
        if (SettingsStatus.disableAnalytics) {
            addPreference(
                    helper.switchPreference(
                            str("piko_disable_analytics"),
                            str("piko_disable_analytics_desc"),
                            Settings.DISABLE_ANALYTICS
                    )
            );
            addPreference(
                    helper.buttonPreference(
                            str("piko_delete_analytics_cache"),
                            "",
                            "piko_delete_analytics_cache"
                    )
            );
        }
        if (SettingsStatus.moreOptionsOnPost) {
            addPreference(
                    helper.switchPreference(
                            str("piko_enable_more_options_on_post"),
                            str("piko_enable_more_options_on_post_desc"),
                            Settings.ENABLE_MORE_OPTIONS_ON_POST
                    )
            );
        }
        if (SettingsStatus.followBackIndicator) {
            addPreference(
                    helper.switchPreference(
                            str("piko_follow_back_indicator"),
                            str("piko_follow_back_indicator_desc"),
                            Settings.FOLLOW_BACK_INDICATOR
                    )
            );
        }
        if (SettingsStatus.followBackIndicator || SettingsStatus.followListNonFollowerBadge) {
            addPreference(
                    helper.availableWhen(
                            helper.switchPreference(
                                    str("piko_fbi_color_indicator"),
                                    "",
                                    Settings.FOLLOW_BACK_COLOR_INDICATOR
                            ),
                            () -> (SettingsStatus.followBackIndicator
                                    && SharedPref.getBooleanPref(Settings.FOLLOW_BACK_INDICATOR))
                                    || (SettingsStatus.followListNonFollowerBadge
                                    && SharedPref.getBooleanPref(Settings.FOLLOW_LIST_NON_FOLLOWER_BADGE))
                    )
            );
        }
        if (SettingsStatus.followListNonFollowerBadge) {
            addPreference(
                    helper.switchPreference(
                            str("piko_follow_list_non_follower_badge"),
                            str("piko_follow_list_non_follower_badge_desc"),
                            Settings.FOLLOW_LIST_NON_FOLLOWER_BADGE
                    )
            );
        }
        if (SettingsStatus.resumeReelsAfterScrolling) {
            addPreference(helper.switchPreference(
                    str("piko_resume_reels_after_scrolling"),
                    str("piko_resume_reels_after_scrolling_desc"),
                    Settings.RESUME_REELS_AFTER_SCROLLING
            ));
        }
        // Ambient glow in the bars of a Reel that does not fill the screen (see ReelsAmbient). Drawn by the extension
        // alone, so it is always offered. The button copies what was found on the Reels screen, for a bug report.
        if (SettingsStatus.reelsAmbient()) {
            addPreference(helper.switchPreference(
                    str("piko_reels_ambient"),
                    str("piko_reels_ambient_desc"),
                    Settings.REELS_AMBIENT
            ));
            addPreference(
                    helper.availableWhen(
                            helper.buttonPreference(
                                    str("piko_copy_reels_ambient_info"),
                                    "",
                                    "piko_copy_reels_ambient_info"
                            ),
                            () -> Pref.reelsAmbient()
                    )
            );
        }
        if (SettingsStatus.improveImageViewing) {
            addPreference(
                    helper.switchPreference(
                            str("piko_improve_image_viewing"),
                            str("piko_improve_image_viewing_desc"),
                            Settings.IMPROVE_IMAGE_VIEWING
                    )
            );
        }
        if (SettingsStatus.copyCommentButton) {
            addPreference(
                    helper.switchPreference(
                            str("piko_copy_comment"),
                            str("piko_copy_comment_desc"),
                            Settings.COMMENT_COPY_BUTTON
                    )
            );
        }
        if (SettingsStatus.removeEmptyBottomSpace) {
            addPreference(
                    helper.switchPreference(
                            str("piko_remove_empty_bottom_space"),
                            "",
                            Settings.REMOVE_EMPTY_BOTTOM_SPACE
                    )
            );
        }
        if (SettingsStatus.unlockPlusBenefits) {
            addPreference(
                    helper.switchPreference(
                            str("piko_unlock_plus_benefits"),
                            str("piko_unlock_plus_benefits_desc"),
                            Settings.UNLOCK_PLUS_BENEFITS
                    )
            );
        }
    }

    public void buildInstantsSection() {
        if (SettingsStatus.instantsDownload) {
            addPreference(
                    helper.switchPreference(
                            str("piko_instants_download"),
                            str("piko_instants_download_desc"),
                            Settings.INSTANTS_DOWNLOAD
                    )
            );
            addPreference(
                    helper.buttonPreference(
                            str("piko_view_saved_instants"),
                            "",
                            "piko_view_saved_instants"
                    )
            );
        }
    }

    public void buildDownloadSection() {
        if (!SettingsStatus.downloadSection()) return;

        // PreferenceCategory category= addCategory(str("piko_category_download_media"));

        addPreference(
                helper.switchPreference(
                        str("piko_enable_download"),
                        "",
                        Settings.ENABLE_DOWNLOAD
                )
        );

        if (SettingsStatus.feedDownloadButton || SettingsStatus.reelDownloadButton
                || SettingsStatus.storyDownloadButton) {
            addPreference(
                    helper.availableWhen(
                            new DownloadButtonPreference(context),
                            () -> SharedPref.getBooleanPref(Settings.ENABLE_DOWNLOAD)
                    )
            );
        }
        if (SettingsStatus.saveMediaCommentButton) {
            addPreference(
                    helper.switchPreference(
                            str("piko_save_media_comment"),
                            str("piko_save_media_comment_desc"),
                            Settings.COMMENT_SAVE_MEDIA_BUTTON
                    )
            );
        }

        addPreference(
                helper.switchPreference(
                        str("piko_enable_direct_download"),
                        str("piko_enable_direct_download_desc"),
                        Settings.ENABLE_DIRECT_DOWNLOAD
                )
        );

        addPreference(
                helper.switchPreference(
                        str("piko_download_username_folder"),
                        str("piko_download_username_folder_desc"),
                        Settings.DOWNLOAD_USERNAME_FOLDER
                )
        );

        addPreference(
                helper.switchPreference(
                        str("piko_prefer_dash_format"),
                        str("piko_prefer_dash_format_desc"),
                        Settings.PREFER_DASH_FORMAT
                )
        );

        addPreference(
                helper.availableWhen(
                        helper.switchPreference(
                                str("piko_dash_audio_aac_lc"),
                                str("piko_dash_audio_aac_lc_desc"),
                                Settings.DASH_AUDIO_AAC_LC
                        ),
                        () -> SharedPref.getBooleanPref(Settings.PREFER_DASH_FORMAT)
                )
        );

        addPreference(
                helper.switchPreference(
                        str("piko_embed_download_metadata"),
                        str("piko_embed_download_metadata_desc"),
                        Settings.EMBED_DOWNLOAD_METADATA
                )
        );

        addPreference(
                helper.downloadFileNameTemplatePreference(
                        str("piko_download_file_name_template"),
                        Pref.downloadFileNameTemplate(),
                        Settings.DOWNLOAD_FILE_NAME_TEMPLATE
                )
        );

        addPreference(
                helper.buttonPreference(
                        str("piko_download_set_path"),
                        StorageUtils.getCustomPathForDisplay(),
                        "piko_download_set_path"
                )
        );

        if(SettingsStatus.downloadWithExternalDownloader) {
            addPreference(
                    helper.switchPreference(
                            str("piko_download_with_external_downloader"),
                            "",
                            Settings.DOWNLOAD_WITH_EXTERNAL_DOWNLOADER
                    )
            );

            addPreference(
                    helper.availableWhen(
                            helper.editTextPreference(
                                    str("piko_external_downloader_package_name"),
                                    Pref.externalDownloaderPackageName(),
                                    Settings.EXTERNAL_DOWNLOADER_PACKAGE_NAME
                            ),
                            () -> SharedPref.getBooleanPref(Settings.DOWNLOAD_WITH_EXTERNAL_DOWNLOADER)
                    )
            );
        }
    }

    public void buildActionBarSection() {

        addPreference(
                helper.multiSelectListPref(
                        str("piko_action_bar_main_feed"),
                        "",
                        Settings.ACTION_BAR_MAIN_FEED
                )
        );

        addPreference(
                helper.multiSelectListPref(
                        str("piko_action_bar_user_profile"),
                        "",
                        Settings.ACTION_BAR_USER_PROFILE
                )
        );

        addPreference(
                helper.multiSelectListPref(
                        str("piko_action_bar_inbox"),
                        "",
                        Settings.ACTION_BAR_INBOX
                )
        );

        addPreference(
                helper.multiSelectListPref(
                        str("piko_action_bar_chat"),
                        str("piko_action_bar_chat_desc"),
                        Settings.ACTION_BAR_CHAT
                )
        );

        addPreference(
                helper.switchPreference(
                        str("piko_action_bar_home_long_press_settings"),
                        str("piko_action_bar_home_long_press_settings_desc"),
                        Settings.HOME_LONG_PRESS_PIKO_SETTINGS
                )
        );
    }

    public void filterContentSection() {
        if(!SettingsStatus.filterContentSection()) return;

        if(SettingsStatus.storyFilters) {
            PreferenceCategory category = addCategory(str("piko_filter_story"));

            addPreference(
                    category,
                    helper.multiSelectListPref(
                            str("piko_filter_story_types_to_hide"),
                            "",
                            Settings.FILTER_STORY_BY_TYPE
                    )
            );

            addPreference(
                    category,
                    helper.multiSelectListPref(
                            str("piko_filter_story_user_types_to_hide"),
                            "",
                            Settings.FILTER_STORY_BY_USER_TYPE
                    )
            );

            addPreference(
                    category,
                    helper.editTextNumPreference(
                            str("piko_filter_story_minimum_item_count"),
                            str("piko_filter_story_minimum_item_count_desc"),
                            Settings.FILTER_STORY_MIN_STORY_ITEMS
                    )
            );

            addPreference(
                    category,
                    helper.editTextNumPreference(
                            str("piko_filter_story_maximum_item_count"),
                            str("piko_filter_story_maximum_item_count_desc"),
                            Settings.FILTER_STORY_MAX_STORY_ITEMS
                    )
            );
        }
    }

    /** The three pages of the Navigation bar settings, in the order of the buttons at the top of the page. */
    private static final int NAV_TAB_DEFAULT = 0;
    private static final int NAV_TAB_BLUR = 1;
    private static final int NAV_TAB_LIQUID = 2;
    private static final int NAV_TAB_COUNT = 3;

    /**
     * The page of the Navigation bar settings that is open. Kept while the app runs, so the page opens on the
     * button it was left on (handy when going back and forth to the app to look at a slider).
     */
    private static int navTab = NAV_TAB_DEFAULT;

    /** The rows of each page. Only the rows of the selected page are on the screen at a time. */
    private List<List<Preference>> navTabs;
    /** The page whose rows are on the screen now. */
    private int navTabShown = NAV_TAB_DEFAULT;

    private void addToNavTab(int tab, Preference preference) {
        navTabs.get(tab).add(preference);
    }

    /** Swaps the rows on the screen for the rows of {@code tab}. The buttons row stays where it is. */
    private void showNavTab(int tab) {
        for (Preference preference : navTabs.get(navTabShown)) {
            screen.removePreference(preference);
        }
        List<Preference> rows = navTabs.get(tab);
        for (int i = 0; i < rows.size(); i++) {
            Preference preference = rows.get(i);
            // The buttons row is 0, the rows under it follow in the order they were built in.
            preference.setOrder(i + 1);
            screen.addPreference(preference);
        }
        navTabShown = tab;
        // A row that was off the screen did not hear about switches turned on or off meanwhile.
        helper.updateDependencies(screen);
    }

    public void buildNavigationSection() {
        navTabs = new ArrayList<>();
        for (int i = 0; i < NAV_TAB_COUNT; i++) {
            navTabs.add(new ArrayList<Preference>());
        }

        // ---------------------------------------------------------------------------------------------------
        // Default: the floating navigation bar, Instagram's own floating bar (the switch only), the selected tab
        // pill, the gesture line and the tabs of the bar.
        // ---------------------------------------------------------------------------------------------------
        addToNavTab(NAV_TAB_DEFAULT,
                helper.switchPreference(
                        str("piko_floating_nav_bar"),
                        "",
                        Settings.FLOATING_NAV_BAR
                )
        );

        // Width and height of the floating bar with a live preview: of the pill, and of Instagram's own floating bar
        // (the switch below), which takes the same two sliders. Only usable while one of the two is on: it is dimmed
        // otherwise, and comes back as soon as one of the switches is turned on.
        addToNavTab(NAV_TAB_DEFAULT,
                helper.availableWhen(
                        helper.floatingNavSizePreference(
                                str("piko_floating_nav_size"),
                                ""
                        ),
                        () -> Pref.floatingNavBar() || Pref.nativeFloatingNav()
                )
        );

        // The highlight behind the selected tab of the floating bar, from a picture of the user's own. It has the size
        // of the selected tab, so it follows the width and height sliders above, and the preview shows it. It works on
        // the floating navigation bar and on Instagram's own floating bar, so these are dimmed while neither is on;
        // the two buttons are dimmed until the switch is on.
        addToNavTab(NAV_TAB_DEFAULT,
                helper.availableWhen(
                        helper.switchPreference(
                                str("piko_custom_tab_pill"),
                                "",
                                Settings.CUSTOM_TAB_PILL
                        ),
                        () -> Pref.floatingNavBar() || Pref.nativeFloatingNav()
                )
        );
        // Slide the highlight sideways (or hold it), move it to a tab and let go: dimmed until the highlight is on.
        addToNavTab(NAV_TAB_DEFAULT,
                helper.availableWhen(
                        helper.switchPreference(
                                str("piko_custom_tab_pill_drag"),
                                "",
                                Settings.CUSTOM_TAB_PILL_DRAG
                        ),
                        () -> (Pref.floatingNavBar() || Pref.nativeFloatingNav()) && Pref.customTabPill()
                )
        );
        addToNavTab(NAV_TAB_DEFAULT,
                helper.availableWhen(
                        helper.buttonPreference(
                                str("piko_tab_pill_pick_image"),
                                "",
                                "piko_tab_pill_pick_image"
                        ),
                        () -> (Pref.floatingNavBar() || Pref.nativeFloatingNav()) && Pref.customTabPill()
                )
        );
        addToNavTab(NAV_TAB_DEFAULT,
                helper.availableWhen(
                        helper.buttonPreference(
                                str("piko_tab_pill_reset_image"),
                                "",
                                "piko_tab_pill_reset_image"
                        ),
                        () -> (Pref.floatingNavBar() || Pref.nativeFloatingNav()) && Pref.customTabPill()
                )
        );

        // Instagram's own floating bar, as a second way to get a floating bar with the page running behind it. The
        // pill above steps aside while this is on, and the size sliders apply to Instagram's bar instead. Its blur and
        // its liquid glass have their own buttons at the top of the page.
        addToNavTab(NAV_TAB_DEFAULT,
                helper.switchPreference(
                        str("piko_native_floating_nav"),
                        "",
                        Settings.NATIVE_FLOATING_NAV
                )
        );

        // The system's gesture line under the floating bar. Only does something while one of the two floating bars
        // is on, so it is dimmed otherwise, like the size sliders.
        addToNavTab(NAV_TAB_DEFAULT,
                helper.availableWhen(
                        helper.switchPreference(
                                str("piko_hide_gesture_line"),
                                "",
                                Settings.HIDE_GESTURE_LINE
                        ),
                        () -> Pref.floatingNavBar() || Pref.nativeFloatingNav()
                )
        );

        // Tap to copy what Instagram's own floating bar looks like inside (sizes, layout, offsets), to paste in a bug
        // report. Dimmed unless Instagram's own floating bar is on, like the size sliders.
        addToNavTab(NAV_TAB_DEFAULT,
                helper.availableWhen(
                        helper.buttonPreference(
                                str("piko_copy_nav_bar_info"),
                                "",
                                "piko_copy_nav_bar_info"
                        ),
                        () -> Pref.nativeFloatingNav()
                )
        );

        // The rounded highlight behind the selected tab. Works on the stock bar and on the floating bar.
        addToNavTab(NAV_TAB_DEFAULT,
                helper.switchPreference(
                        str("piko_remove_selected_tab_pill"),
                        "",
                        Settings.REMOVE_SELECTED_TAB_PILL
                )
        );

        if (SettingsStatus.hideNavigationButtons) {
            addToNavTab(NAV_TAB_DEFAULT,
                    helper.navigationBarPreference(
                            str("piko_navigation_tabs_title"),
                            ""
                    )
            );

            addToNavTab(NAV_TAB_DEFAULT,
                    helper.navigationStartupPreference(
                            str("piko_navigation_startup_tab"),
                            ""
                    )
            );
        }

        // ---------------------------------------------------------------------------------------------------
        // Blur: only the blur behind Instagram's own floating bar.
        // ---------------------------------------------------------------------------------------------------

        // Live blur behind Instagram's own floating bar. Only does something while that bar is on, so it is dimmed
        // otherwise, like the size sliders.
        addToNavTab(NAV_TAB_BLUR,
                helper.availableWhen(
                        helper.switchPreference(
                                str("piko_native_floating_nav_blur"),
                                "",
                                Settings.NATIVE_FLOATING_NAV_BLUR
                        ),
                        () -> Pref.nativeFloatingNav()
                )
        );

        // How strong the blur is and how see-through the glass is. Both belong to the blur above, so they are dimmed
        // unless Instagram's own floating bar and its blur are on.
        addToNavTab(NAV_TAB_BLUR,
                helper.availableWhen(
                        helper.percentSliderPreference(
                                "piko_native_floating_nav_blur_level",
                                str("piko_native_floating_nav_blur_level"),
                                "",
                                new PercentSliderPreference.Access() {
                                    @Override public int get() { return Pref.nativeFloatingNavBlurLevel(); }
                                    @Override public void set(int percent) {
                                        Pref.setNativeFloatingNavBlurLevel(percent);
                                        FloatingNavSizePreference.glassSaved();
                                    }
                                    @Override public void live(int percent) { FloatingNavSizePreference.previewGlass(percent, -1); }
                                }
                        ),
                        () -> Pref.nativeFloatingNav() && Pref.nativeFloatingNavBlur()
                )
        );
        addToNavTab(NAV_TAB_BLUR,
                helper.availableWhen(
                        helper.percentSliderPreference(
                                "piko_native_floating_nav_transparency",
                                str("piko_native_floating_nav_transparency"),
                                "",
                                new PercentSliderPreference.Access() {
                                    @Override public int get() { return Pref.nativeFloatingNavTransparency(); }
                                    @Override public void set(int percent) {
                                        Pref.setNativeFloatingNavTransparency(percent);
                                        FloatingNavSizePreference.glassSaved();
                                    }
                                    @Override public void live(int percent) { FloatingNavSizePreference.previewGlass(-1, percent); }
                                }
                        ),
                        () -> Pref.nativeFloatingNav() && Pref.nativeFloatingNavBlur()
                )
        );

        // ---------------------------------------------------------------------------------------------------
        // Liquid glass: the switch and everything of the liquid glass look.
        // ---------------------------------------------------------------------------------------------------

        // Liquid glass on top of the blur: the rim bends what is behind the bar. Needs the blur, so it is dimmed
        // unless Instagram's own floating bar and its blur are on. The slider is dimmed until the switch is on.
        addToNavTab(NAV_TAB_LIQUID,
                helper.availableWhen(
                        helper.switchPreference(
                                str("piko_native_floating_nav_liquid"),
                                "",
                                Settings.NATIVE_FLOATING_NAV_LIQUID
                        ),
                        () -> Pref.nativeFloatingNav() && Pref.nativeFloatingNavBlur()
                )
        );
        // The rest of the liquid glass playground, one slider each (see LiquidGlassLook): dimmed until the switch above
        // is on.
        for (int optionIndex = 0;
             optionIndex < app.morphe.extension.instagram.patches.navigation.LiquidGlassLook.OPTIONS.length;
             optionIndex++) {
            final int index = optionIndex;
            final app.morphe.extension.instagram.patches.navigation.LiquidGlassLook.Option option =
                    app.morphe.extension.instagram.patches.navigation.LiquidGlassLook.OPTIONS[index];
            addToNavTab(NAV_TAB_LIQUID,
                    helper.availableWhen(
                            helper.percentSliderPreference(
                                    option.titleKey,
                                    str(option.titleKey),
                                    "",
                                    new PercentSliderPreference.Access() {
                                        @Override public int get() { return option.get(); }
                                        @Override public void set(int percent) {
                                            option.set(percent);
                                            FloatingNavSizePreference.glassSaved();
                                        }
                                        // The pinned preview shows the glass as the slider moves.
                                        @Override public void live(int percent) {
                                            FloatingNavSizePreference.previewLiquid(index, percent);
                                        }
                                        @Override public String format(int percent) { return option.format.show(percent); }
                                    }
                            ),
                            () -> Pref.nativeFloatingNav() && Pref.nativeFloatingNavBlur() && Pref.nativeFloatingNavLiquid()
                    )
            );
        }
        // Bevel mode: the pill (the rim bends the page) or a dome (a magnifier with a flat back).
        addToNavTab(NAV_TAB_LIQUID,
                helper.availableWhen(
                        helper.switchPreference(
                                str("piko_native_floating_nav_dome"),
                                "",
                                Settings.NATIVE_FLOATING_NAV_DOME
                        ),
                        () -> Pref.nativeFloatingNav() && Pref.nativeFloatingNavBlur() && Pref.nativeFloatingNavLiquid()
                )
        );
        // Puts every liquid glass slider (and the bevel mode) back to its default.
        addToNavTab(NAV_TAB_LIQUID,
                helper.availableWhen(
                        helper.buttonPreference(
                                str("piko_liquid_glass_reset"),
                                "",
                                "piko_liquid_glass_reset"
                        ),
                        () -> Pref.nativeFloatingNav() && Pref.nativeFloatingNavBlur() && Pref.nativeFloatingNavLiquid()
                )
        );

        // ---------------------------------------------------------------------------------------------------
        // Put the rows on the screen.
        // ---------------------------------------------------------------------------------------------------

        if (searchIndexing) {
            // Search has to find every row, wherever it lives, and has no use for the buttons.
            for (List<Preference> rows : navTabs) {
                for (Preference preference : rows) {
                    addPreference(preference);
                }
            }
            return;
        }

        // Coming from a search result: open the page that holds the row that was searched for.
        if (targetPreferenceKey != null && !targetPreferenceKey.isEmpty()) {
            for (int tab = 0; tab < NAV_TAB_COUNT; tab++) {
                for (Preference preference : navTabs.get(tab)) {
                    if (targetPreferenceKey.equals(preference.getKey())) {
                        navTab = tab;
                    }
                }
            }
        }

        TabSwitcherPref switcher = new TabSwitcherPref(
                context,
                new CharSequence[] {
                        str("piko_nav_tab_default"),
                        str("piko_nav_tab_blur"),
                        str("piko_nav_tab_liquid")
                },
                navTab,
                tab -> {
                    navTab = tab;
                    showNavTab(tab);
                }
        );
        switcher.setKey("piko_nav_tab_switcher");
        switcher.setOrder(0);
        addPreference(switcher);

        List<Preference> firstRows = navTabs.get(navTab);
        for (int i = 0; i < firstRows.size(); i++) {
            Preference preference = firstRows.get(i);
            preference.setOrder(i + 1);
            addPreference(preference);
        }
        navTabShown = navTab;
    }

    public void buildRecommendedFlagsSection() {
        buildRecommendedFlagsSection(true);
    }

    private void buildRecommendedFlagsSection(boolean notifyErrors) {
        long lastModified = RecommendedFlags.getLastModified();
        String lastModifiedAtString = "";
        if (lastModified > 0L) {
            Locale locale = context.getResources().getConfiguration().getLocales().get(0);
            String skeleton = DateFormat.is24HourFormat(context) ? "yMMMEdHm" : "yMMMEdhm";
            String pattern = DateFormat.getBestDateTimePattern(locale, skeleton);
            String formattedDate = new SimpleDateFormat(pattern, locale).format(new Date(lastModified));
            lastModifiedAtString = String.format(str("piko_rec_flags_last_modified_at"), formattedDate);
        }
        addPreference(
            helper.buttonPreference(
                    str("piko_rec_flags_refresh_file"),
                    lastModifiedAtString,
                    "piko_rec_flags_refresh_file"
            )
        );
        List<Flag> recFlags = RecommendedFlags.getFlags(notifyErrors);
        // The flag names will be English only,
        // as I want to keep it as a live service
        // rather than triggering new build
        // for every a new flag.
        for(Flag flag : recFlags) {
            if (flag.isLongType()) {
                addPreference(
                        helper.editTextNumPreference(
                                flag.getName(),
                                flag.getDesc(),
                                flag.getCode()
                        )
                );
            } else {
                addPreference(
                        helper.listPreference(
                                flag.getName(),
                                flag.getDesc(),
                                flag.getCode()
                        )
                );
            }
        }
    }

    public void aboutSection(TreeMap<String, Boolean> flags) {

        String appVersionText = String.format(str("piko_app_version"), Utils.getAppVersionName());
        String patchVersionText = String.format(str("piko_patch_version"), Utils.getPatchesReleaseVersion());

        addPreference(
                helper.buttonPreference(
                        appVersionText,
                        "",
                        Constants.PIKO_APP_VERSION_PREFERENCE
                )
        );

        addPreference(
                helper.buttonPreference(
                        patchVersionText,
                        "",
                        Constants.PIKO_PATCH_VERSION_PREFERENCE
                )
        );

        addPreference(
                helper.buttonPreference(
                        str("piko_export_pref"),
                        "",
                        "piko_export_pref"
                )
        );

        addPreference(
                helper.buttonPreference(
                        str("piko_import_pref"),
                        "",
                        "piko_import_pref"
                )
        );

        addPreference(
                helper.buttonPreference(
                        str("piko_reset_pref"),
                        "",
                        "piko_reset_pref"
                )
        );

        addPreference(
                helper.switchPreference(
                        str("piko_debug"),
                        str("piko_debug_desc"),
                        Settings.PIKO_DEBUG
                )
        );

        PreferenceCategory category = addCategory(str("piko_patch_info_title"));
        category.setKey(Constants.PIKO_PATCH_INFO_PREFERENCE_CATEGORY);
        String enabledStr = str("piko_patch_enabled");
        String disabledStr = str("piko_patch_disabled");

        for (Map.Entry<String, Boolean> entry : flags.entrySet()) {
            String resName = entry.getKey();
            boolean sts = (boolean) entry.getValue();
            String status = sts ? enabledStr : disabledStr;

            addPreference(category,
                    helper.buttonPreference(
                            resName,
                            status,
                            resName
                    )
            );
        }

    }

    public void storySection() {
        if (!SettingsStatus.storySection()) return;

        if (SettingsStatus.hideStoryFollowButton) {
            addPreference(
                    helper.switchPreference(
                            str("piko_hide_story_follow_button"),
                            str("piko_hide_story_follow_button_desc"),
                            Settings.HIDE_STORY_FOLLOW_BUTTON
                    )
            );
        }
        if (SettingsStatus.viewStoryMentions) {
            addPreference(
                    helper.switchPreference(
                            str("piko_view_story_mentions"),
                            "",
                            Settings.VIEW_STORY_MENTIONS
                    )
            );
        }
        if (SettingsStatus.disableStoryFlipping) {
            addPreference(
                    helper.switchPreference(
                            str("piko_disable_story_flipping"),
                            str("piko_disable_story_flipping_desc"),
                            Settings.DISABLE_STORY_FLIPPING
                    )
            );
        }
        if (SettingsStatus.loopStory) {
            addPreference(
                    helper.switchPreference(
                            str("piko_loop_story"),
                            str("piko_loop_story_desc"),
                            Settings.LOOP_STORY
                    )
            );
        }
        if (SettingsStatus.customiseStoryTimestamp) {
            addPreference(
                    helper.listPreference(
                            str("piko_customise_story_timestamp"),
                            str("piko_customise_story_timestamp_desc"),
                            Settings.CUSTOMISE_STORY_TIMESTAMP
                    )
            );
        }
        if (SettingsStatus.customiseStoryRingSize) {
            addPreference(
                    helper.editTextNumPreference(
                            str("piko_customise_story_ring_size"),
                            str("piko_customise_story_ring_size_desc"),
                            Settings.CUSTOMISE_STORY_RING_SIZE
                    )
            );
        }
    }

    /**
     * Builds the root page. With {@link #dashboard(boolean)} enabled the categories are shown as
     * a grid of tiles; otherwise they are plain rows, which is what the search index reads.
     */
    public void buildSettingsPage() {
        if (SettingsStatus.adsSection()) {
            rootCategory("piko_category_ads", Constants.PIKO_FRAGMENT_ADS);
        }

        if (SettingsStatus.filterContentSection()) {
            rootCategory("piko_category_filter_content", Constants.PIKO_FRAGMENT_FILTER_CONTENT);
        }

        if (SettingsStatus.ghostSection()) {
            rootCategory("piko_category_ghost", Constants.PIKO_FRAGMENT_GHOST);
        }

        if (SettingsStatus.dmSection()) {
            rootCategory("piko_category_dm", Constants.PIKO_FRAGMENT_DM);
        }

        if (SettingsStatus.storySection()) {
            rootCategory("piko_category_story", Constants.PIKO_FRAGMENT_STORY);
        }

        if (SettingsStatus.linksSection()) {
            rootCategory("piko_category_links", Constants.PIKO_FRAGMENT_LINKS);
        }

        if (SettingsStatus.distractionFreeSection()) {
            rootCategory("piko_category_distraction_free", Constants.PIKO_FRAGMENT_DISTRACTION_FREE);
        }

        if (SettingsStatus.miscSection()) {
            rootCategory("piko_category_misc", Constants.PIKO_FRAGMENT_MISC);
        }

        if (SettingsStatus.downloadSection()) {
            rootCategory("piko_category_downloads", Constants.PIKO_FRAGMENT_DOWNLOAD_MEDIA);
        }

        if (SettingsStatus.instantsDownload) {
            rootCategory("piko_instants_title", Constants.PIKO_FRAGMENT_INSTANTS);
        }

        rootCategory("piko_category_action_bar", Constants.PIKO_FRAGMENT_ACTION_BAR);

        rootCategory("piko_category_navigation_tabs", Constants.PIKO_FRAGMENT_NAV_BTNS);

        if (SettingsStatus.developerOptionsSection()) {
            rootCategory("piko_category_dev_options", Constants.PIKO_FRAGMENT_DEV_OPTIONS);
        }

        rootCategory("piko_category_about", Constants.PIKO_FRAGMENT_ABOUT);

        flushRootTiles();
    }

    private void rootCategory(String titleKey, String fragmentName) {
        String title = str(titleKey);
        if (dashboardLayout) {
            pendingTiles.add(new DashboardRowPref.Tile(
                    title,
                    fragmentName,
                    ButtonPref.iconResourceNameForKey(fragmentName)
            ));
            return;
        }
        addPreference(helper.categoryPreference(title, "", fragmentName));
    }

    private void flushRootTiles() {
        for (int index = 0; index < pendingTiles.size(); index += 2) {
            DashboardRowPref.Tile first = pendingTiles.get(index);
            DashboardRowPref.Tile second = index + 1 < pendingTiles.size()
                    ? pendingTiles.get(index + 1)
                    : null;
            addPreference(new DashboardRowPref(context, first, second));
        }
        pendingTiles.clear();
    }

    //end
}
