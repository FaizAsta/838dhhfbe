# Changelog

## 1.10.3

* **Fix: the blur now covers the whole of Instagram's own floating bar with "Liquid glass" on, including its edge.** From your picture (the bar circled): along the bottom and the right side of the bar, a band about 14 px wide (about 5 dp) did not show the blurred page. It showed the sharp page behind the bar, upside down, with a thin cyan line where the band starts (the caption line under the bar, flipped, with orange and blue edges), and the sharp end of the save icon showed through at the top right. The rest of the bar was blurred.
* **Cause** (worked out from the picture and the numbers; not tested on a phone). The glass shader bends the rim by reading the picture a little *outside* the pill (up to about 26 px at the default look, and a little further for the red channel of the colour fringe, which is the cyan line). But the blurred picture is only made for what is drawn, and the canvas is clipped to the pill before the node is drawn, so there is no blurred picture outside the pill. The reads that landed there got whatever the graphics layer had: the sharp page, mirrored. The numbers fit the picture: with the bar in the picture (133 px high pill, default look) the bend is 25.5 px and a read crosses the pill's edge 13.9 px inside it, which is where the line is. The 1.10.1 and 1.10.2 comments said the extra room around the recorded page covered this; it did not, because the room is not outside the clip.
* **What changed.** The shader (`LiquidGlassEffect.java`) now folds every read that would leave the pill back inside it (mirrored about a line 2 px inside the pill's edge) before it reads the picture, for the bend, the ripple of the distortion and the colour fringe alike. So every pixel of the pill reads blurred picture, the rim shows a soft mirrored copy of the blurred page right at its edge (the way a glass edge flips what is behind it), and nothing sharp or striped shows through any more. The extra room that was recorded around the pill for the bend is gone (the recorded area is the pill plus what the blur needs), since nothing reads it.
* **What stays the same.** The blur alone (Liquid glass off) is untouched, and so are the sliders, their defaults, the tint, the edge light, the shadow and the selected tab pill. The rim looks a little different than in 1.10.2 (it folds the blurred picture instead of reading outside it, so the very edge is a soft mirror of what is just inside it); the Glass refraction slider still sets how wide the folded band is.
* How it works in the code: `LiquidGlassEffect.java` has a new uniform `keepIn` (left, top, right, bottom of the pill in node pixels, 2 px in) and a function `keep()` used by the three reads; `create()` sets it; `reachPx()` is removed. `NativeBarBlur.drawBlur` no longer adds the reach to the recorded area. Version set to 1.10.3 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: `LiquidGlassEffect.java` compiles with javac (all warnings on, none shown) against hand-written stand-ins for the Android classes, and the shader text it builds was read through. The shader's arithmetic was ported to Python with the numbers of your picture: with the old reads, 22 % of the pill's reads fall outside the pill; with `keep()` none do, and the rendered rim is smooth and blurred. **Not checked:** the shader on a real phone (this sandbox has no Skia or Android), and the Gradle build. If the band is still there, use "Copy navigation bar info" and send it with a new picture; if the build fails, send the error text.

## 1.10.2

* **New: every option of the liquid-glass.ybouane.com playground for Instagram's own floating bar (Settings > Navigation bar, under the Liquid glass switch).** Sliders: **Glass refraction**, **Chromatic aberration**, **Edge highlight**, **Specular**, **Fresnel**, **Distortion**, **Corner radius**, **Z-radius**, **Opacity**, **Saturation**, **Brightness**, **Shadow opacity** and **Shadow spread**, and a **Bevel mode: dome** switch. Blur amount and Transparency are the sliders that were already there. **Reset liquid glass** puts all of the new ones back to their defaults (the screen is redrawn).
* **What each one does here.** Refraction bends the rim; chromatic aberration fringes it; edge highlight lights the whole rim, specular the part facing the upper left, fresnel adds a milky reflection at the very edge; distortion ripples the whole glass; corner radius runs from a full pill (100 %) to a rectangle (0 %); z-radius is how wide the curved rim is; opacity fades the whole glass with its shadow; saturation and brightness are centred (0 = unchanged); the shadow is a soft shadow around the bar with the bar itself cut out; bevel mode dome magnifies everything behind the bar, most towards the edge, instead of bending only the rim. Saturation, brightness, fresnel and the shadow spread show real units next to the slider instead of a percent.
* **Limits.** The shader needs Android 13; below that the blur is drawn, with the corner radius, opacity and shadow still applied. The shadow is only drawn inside the bar's own area, so a bar with little room around the pill cuts it off. The distortion is a slow static ripple of my own, not the playground's exact one. Small corner radii show faint diagonal seams in the corners of the bent rim. The settings preview does not show the liquid look. The solid pill of the Floating navigation bar is unchanged.
* **Defaults** keep the 1.10.1 look (refraction 60 %, aberration 20 %, edge highlight 20 %, specular 30 %, fresnel 1.00, z-radius 80 %, corner radius 100 %, opacity 100 %, saturation and brightness 0, no shadow) except saturation, which is now neutral (1.10.1 added 12 %), and the new fresnel edge, which is faint.
* How it works in the code: new `LiquidGlassLook.java` (the table of sliders and their real numbers, read once per half second; immutable with `equals` so the bar only rebuilds its effect when something changed). `LiquidGlassEffect.java` has the extended shader (16 uniforms). `NativeBarBlur.java` applies corner radius in `shape`, opacity and shadow in `draw`, and gives the recorded area room for the bend, the ripple and the fringe. `Settings.java`, `Pref.java` (generic `liquidPercent`), `ScreenBuilder.java` (one loop over the table), `PercentSliderPreference.Access.format` (value text), `ButtonPref.java` (reset), `strings.xml`.
* Checked: the embedded shader compiles with Skia and was rendered for the default, dome, distortion with aberration, a square bar, strong colour and light, and shadow; each looks as described. All edited Java files parse. Not built with Gradle and not run on a phone. If the build fails, send the error text.

## 1.10.1

* **New: "Liquid glass" for Instagram's own floating bar (Settings > Navigation bar, under the blur sliders).** On top of the blur, the rim of the bar bends what is behind it like the edge of thick glass, with a faint colour fringe and a light edge from the upper left, as in the frosted glass of liquid-glass.ybouane.com. The blur amount is the frosting (up for frosted glass, down for clear glass) and the new **Glass refraction** slider (0 to 100 %, default 60) is the bend.
* **Limits.** Needs Android 13 or newer (the shader is AGSL); on Android 12 the plain blur is drawn as before. It sits on top of the blur, so it needs "Instagram's own floating bar" and its blur switch on. The solid pill of the "Floating navigation bar" is unchanged. Applies as soon as you go back to the app, no restart. If the shader is refused on a phone, the plain blur is used and one line goes to the log.
* How it works in the code: new `LiquidGlassEffect.java` (one AGSL shader). `NativeBarBlur.java` chains it after the blur effect of the recorded page and gives the recorded area extra room for the bend. New settings `native_floating_nav_liquid` and `native_floating_nav_refraction` (`Settings.java`, `Pref.java`), read in `FloatingNavBar.java`, rows in `ScreenBuilder.java`, strings in `strings.xml`. Ported onto 1.10.0 (ambient glow) without touching it.
* Checked: the shader compiles with Skia and was rendered over a test page; the edited Java files parse. Not built with Gradle and not run on a phone. If the build fails, send the error text.

## 1.10.0

* **New: ambient glow on Reels, like ambient mode on YouTube.** When a Reel does not fill the screen (a wide or a square video leaves a bar above and a bar below it), the bars are filled with a soft glow in the colours of the video instead of plain black, and the glow follows the video as it plays. Switch: Settings > Misc > **Ambient glow on Reels** (off by default; applies as soon as you go back to the app). A Reel that fills the screen is not touched at all.
* **How it works.** No new patch and no search in Instagram's code, only the view tree, like the floating bar: a few times a second the main screen is searched for the video of a Reel (a `TextureView` or a `SurfaceView` at least half as wide as the screen, with a view around it whose id names Reels, which Instagram calls "clips"). The page that holds it (the nearest view around it that is about as big as the screen and is not a list or a pager) gets a glow as its *background*, so the video and all the buttons stay on top and nothing is covered. About ten times a second a tiny copy of the video is taken (96 px wide), the part of it that really shows the picture is found (the rest of a letterboxed video view is see-through), and if the picture leaves a bar of at least 12 dp, its colours are averaged into a 16 by 28 grid, softened, dimmed a little and stretched over the page. The glow follows the video smoothly instead of flickering. The page's own background (a plain colour or nothing) is drawn first and given back as soon as there are no bars, when the setting is off, or when the page goes away.
* **Limits.** Only bars that are *outside* the picture are filled (the empty part of a letterboxed video view, or the page around a smaller view). A video that has black bars baked into the file itself is left as it is (the report below says how many black rows the picture has). A page whose background is not a plain colour is left alone, and a page whose background Instagram keeps setting again is given up on. A `SurfaceView` video is copied with `PixelCopy` (a protected video shows no glow). Anything that goes wrong turns the glow off for a few seconds and goes into the log; it never reaches the app.
* **Copy Reels ambient info** (next to the switch) copies what the glow found on the Reels screen: the video views, the views around them, why a page was or was not taken, where the picture is on the page and whether it has bars. Paste it in a bug report if no glow shows. Open a Reel once first.
* Files: new `ReelsAmbient.java` (the view tree, the copies, the glow drawable) and `AmbientMath.java` (the pixel arithmetic, no Android) in `patches/`; `Settings.REELS_AMBIENT`, `Pref.reelsAmbient()`, `SettingsStatus.reelsAmbient()` (the Misc screen is now always there), the switch and the button in `ScreenBuilder.java`, the button in `ButtonPref.java`, `ReelsAmbient.start()` in `Constants.load()`, new strings. Version set to 1.10.0 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: both new classes compile with javac (all warnings on, none shown) against hand-written stand-ins for the Android classes. `AmbientMath` passes a test of the content rectangle (letterbox, pillarbox, empty, full), the colour grid (including holes), the blur, the smooth following, the bars rule and the id rules. `ReelsAmbient` passes a test on a fake view tree: a letterboxed Reel gets the glow and keeps the same drawable; a Reel that fills the page is never touched; see-through bars inside a full-size view get the glow; a video in a list, a video without a Reels id and a Stories id are left alone; a gradient background is left alone and the window root never gets the glow; switching the setting off, bars going away, the video leaving or being hidden all give the original background back; Instagram setting the background again puts the glow back, and a page that keeps doing it is given up on; an empty frame changes nothing; at most three pages at once. **Not checked:** that Instagram's Reels screen really has an id with "clips" or "reel" around the video, that its video is a `TextureView` or `SurfaceView` the picture of which can be copied, and what its pages look like with a bar. The Gradle build and the phone are not run here. If no glow shows, copy the info above and send it; if the build fails, send the error text.

## 1.9.1

* **Fix: the sliders in the settings now glide under your finger instead of moving "point by point".** Before, a slider had exactly as many positions as its setting has values, so the thumb hopped from one notch to the next: the Height slider (0 to 10) had only eleven positions, the Width slider 57, the Bottom gap slider 41, and the focus lock duration slider a handful. Now the thumb has 100 positions between every two values, so it follows the finger smoothly. This covers every slider in Piko's settings: Width, Height and Bottom gap (Floating bar size), the blur and transparency sliders of Instagram's own floating bar, and the focus lock duration slider.
* **What stays the same.** The settings still have whole values (whole dp, whole percent, the same duration notches), and the number next to the slider and the live preview change when the thumb passes the middle between two values. When you let go, the thumb eases onto the value it is nearest to (about 0.2 s), and that value is saved, as before. Tapping the track still moves the thumb there. The keyboard and accessibility steps still move one whole value at a time. "Reset" now glides the three size thumbs back to their default values instead of jumping.
* How it works in the code: new `SmoothSlider.java` (package `settings/preference/widgets`) gives a `SeekBar` `steps * 100` positions, turns the position into the nearest whole value and tells the row only when that value changes (`onStep`) and when the finger lets go (`onSettle`), and eases the thumb onto the value after a drag. `FloatingNavSizePreference.java`, `PercentSliderPreference.java` and `FocusLockDurationPreference.java` use it in place of their own `SeekBar` listeners; the saved values and the keys are unchanged. Version set to 1.9.1 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: `SmoothSlider.java` compiles with javac (all warnings on, none shown) against hand-written stand-ins for the Android classes, and a test passes for: a drag across several values (the thumb follows every position and the row is told once per value), letting go (the thumb eases onto the nearest value and the value is saved once), a row drawn again while the thumb settles (the glide is not cut short), a finger taking over from a settling thumb, a tap on the track, keyboard and accessibility steps in both directions and at both ends, the percent slider (100 values), and a slider that leaves the screen mid-glide. The three edited rows were checked by reading and for syntax errors only; the Gradle build and the phone are not run here. If the build fails, send the error text.

## 1.9.0

* **New: "Bottom gap" slider (Settings > Navigation bar > Floating bar size).** Sets how far the floating bar floats above the bottom of the screen, from 0 to 40 dp (default 0, so nothing changes until it is moved). It applies to the floating navigation bar and to Instagram's own floating bar, sits on top of the system inset under the tabs, and the page still runs down behind the bar. The live preview shows the pill rising over the page.
* How it works in the code: new `BarBottomGap.java` adds the chosen distance to the bar's own bottom margin (Instagram's margin is kept and the distance is added to it), remembers what it changed, gives it back when both floating bars are switched off, and gives up after repeated resets by Instagram. New setting `floating_nav_bottom_dp` (`Settings.java`, `Pref.java`, `FloatingNavSize.java`), wired into `FloatingNavBar.java` and `FloatingNavSizePreference.java`; new string `piko_floating_nav_bottom`.
* **Change: the height slider now goes up to 55 dp (was 48 dp).** `FloatingNavSize.FALLBACK_BAR_DP` is 55. It is the tallest bar Instagram's own floating bar can be made; the floating navigation bar's pill is still limited by the real height of Instagram's bar, which is measured.
* **Change: the settings of the Navigation bar screen no longer show a description under their title** (all rows, including the tabs and the startup tab). The texts are still in `strings.xml`.
* **Change: new look for the sliders.** A thick rounded track (accent colour up to the thumb, grey after it) and a pill-shaped thumb in the colour of the page with a white edge and a soft shadow, as in the picture sent. New `SliderStyle.java`, used by the width, height and bottom gap sliders, the blur and transparency sliders and the focus lock duration slider.
* Not built or run on a phone: the changes were checked by reading only. If the build fails, send the error text.

## 1.8.19

* **Fix: the icons of Instagram's own floating bar are now spread across the whole pill, like on the floating navigation bar.** From your picture (top: the floating navigation bar, bottom: Instagram's own bar): on Instagram's bar the five icons were bunched toward the middle, with a wide empty stretch before the first and after the last one, while on the floating navigation bar each icon sits in the middle of a fifth of the pill. Cause: Instagram's bar has a side padding (24 dp on the phone whose bar info was sent earlier: a 384 dp bar) and lays the tabs out in what is left, while the pill fills the whole bar. On those numbers the icons were 67 dp apart and the first one 58 dp from the pill's edge; now they are 77 dp apart and the first is 38 dp in, the same as the top bar.
* **What changed.** While the width of the slider is on the bar (so the pill fills it), the bar's left and right padding is taken off, so every tab is a fifth of the pill wide and its icon is in the middle of it. Only the left and right padding is touched: the bottom padding (the gesture area under the bar) and the top stay Instagram's. The tabs are also bigger to tap, and the "Custom selected tab pill" highlight is as wide as the cell, like on the other bar. Everything is given back when "Instagram's own floating bar" is switched off, or when the pill stops filling the bar (the width could not be applied), so the bar is then exactly as Instagram made it. If Instagram puts its padding back on seven frames in a row, the padding alone is given up on (the width and the height stay) and one line goes to the log; switching the setting off and on gives it another try.
* **"Copy navigation bar info"** now has a line "side padding: ..." under "Where the pill is drawn": the padding that was found on Instagram's bar and whether it was taken off. The "before" and "after" trees show the tabs' positions, so if the icons are still not where you want them, send that copy.
* How it works in the code: new `NativeBarPadding.java` (take off, give back, give up after repeated resets, debug line); `NativeBarSize.java` calls it right after the width (`apply`), gives the padding back in `restore`, when the width is given up on, and when the whole size is given up on, and prints its line in `debugReport`. Version set to 1.8.19 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: `NativeBarPadding.java` compiles with javac (all warnings on, none shown) against hand-written stand-ins for the Android classes and was run on a model of the bar from the numbers above (24 dp padding, 19 dp under the bar, 384 dp wide: cells 67.1 dp before, 76.8 dp after, first icon 57.7 dp before, 38.4 dp after; the bottom padding stays; given back exactly; a padding Instagram set since is left alone; one reset is taken off again; resets on every frame are given up on after a few; switching off and on tries again). The calls in `NativeBarSize.java` were checked by javac for errors on those lines and by reading; the whole class is not run here (it needs more of Android than the stand-ins have), and the Gradle build and the phone are not run. If the build fails, send the error text.

## 1.8.18

* **Change: the pill picks up as soon as you slide it, no holding needed.** Touch the pill (the highlight behind the selected tab) and move your finger sideways by the normal touch distance (about 8 dp, the same distance Android uses to tell a tap from a swipe): the pill is picked up at once, with a light tick, and follows your finger. Let go over a tab and that tab opens; let go over the tab you started on and nothing opens. The pill sits under your finger from the first moment, so it does not lag behind by the distance you moved before it caught on.
* **What stays the same.** A plain tap on the tab still works (a touch that stays inside that distance is passed on to the tab as before). A touch that moves up or down first is left alone, so it never starts a drag by accident. Holding your finger still on the pill for half a second picks it up too, with the stronger buzz, as in 1.8.16 and 1.8.17. The setting "Drag the selected tab pill" now describes both ways.
* How it works in the code: `TabPillDrag.java`: while a touch that began on the pill is waiting, a move is looked at: sideways past the touch slop (and more sideways than up or down) calls the new `pickUp(grabRawX, fingerRawX, haptic)`, which the hold timer calls as well, so there is one place that picks the pill up (it sends the tab the cancel, moves the pill under the finger, ticks, and swallows the move). The debug copy ("Copy navigation bar info") now counts the two ways separately: "picked up by sliding sideways" and "holds that picked it up". Version set to 1.8.18 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`; the setting text is in `strings.xml`.
* Checked: `SelectedTabPill.java` and `TabPillDrag.java` compile with javac (all warnings on, none shown) against hand-written stand-ins for the Android classes, and the gesture test passes: a slide of 30 px 30 ms after the touch picks the pill up at once (the app sees the down and a cancel, not the move), the pill is centred under the finger straight away and follows it, letting go over tab 2 taps tab 2; a move up or down, and a small shake inside the slop, are passed on and pick nothing up; the hold, the window and callback cases from 1.8.17 still pass. The Gradle build and the phone are not run here. If the build fails, send the error text.

## 1.8.17

* **Fix: press and hold the selected tab pill did nothing (1.8.16).** The touch handler never started. It looked for the app's window through the window's root view, but on a real phone that view's context is a wrapper around the application, which never leads back to the activity, so no window was found and the touches were never looked at. The window is now handed in by the code that already watches the app's main screen (it has the activity), and the bar's own context is only the fallback. The earlier test used a root view that pointed straight at the activity, which is why it passed there; it now uses a root view like the real one and has a test for exactly this.
* **Hardening.** If another part of the app sets its own callback on the window after this one (replacing it, or wrapping it), the touches are wrapped again, at most three times; when two wrappers of this one end up in the chain, a touch is looked at once, not twice (the cancel that is sent to the tab at the hold is not mistaken for the end of the drag).
* **Where it stops, when it still does not work: "Copy navigation bar info".** The copied text (Settings > Navigation bar, while "Instagram's own floating bar" is on) has a new section, "Press and hold the highlight": how many touches were looked at, how many started on the highlight, how many holds picked it up, how many drops, where the last touch landed against where the highlight was drawn, and the last event. Open the home screen, try the hold once, then copy it.
* How it works in the code: `TabPillDrag.sync` now takes the `Window` (kept in `FloatingNavBar.State.window`, set in `watch`); `TabPillDrag.status()` and `SelectedTabPill.Highlight.describeShown()` feed `NativeBarSize.debugReport()`. Version set to 1.8.17 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: `SelectedTabPill.java` and `TabPillDrag.java` compile with javac (all warnings on, none shown) against hand-written stand-ins for the Android classes, and the gesture test passes (a window root view with the real kind of context, no window handed in, a callback replaced later, two wrappers in one chain). The edited lines of `FloatingNavBar.java` and `NativeBarSize.java` were checked by javac for errors; the Gradle build and the phone are not run here. If the build fails, send the error text.

## 1.8.16

* **New: press and hold the selected tab pill, move it to another tab and let go to open that tab.** Works on the floating navigation bar and on Instagram's own floating bar, wherever "Custom selected tab pill" is on. Touch the pill (the highlight behind the selected tab) and keep the finger still for about half a second: you feel a short buzz and the pill is picked up. It then follows your finger along the bar, a little bigger than at rest and never outside the row of tabs. Let go over a tab and that tab opens; the pill slides onto it and stays there while Instagram opens it. Let go over the tab you started on (or move the finger away before the buzz) and nothing opens: a tap or a scroll on the selected tab works exactly as before.
* **New setting: Drag the selected tab pill** (Navigation bar, under "Custom selected tab pill"). On by default, dimmed until "Custom selected tab pill" is on. Applies as soon as you go back to the app, no restart.
* **Limits.** The hold is the system's long press minus 80 ms, so it comes before a long press of the tab itself; on a tab that has a long press of its own in Instagram, holding the selected tab's pill picks the pill up instead while this is on (switch it off to get the long press back). While the finger drags, the touch is not passed on, so the page behind does not scroll. If the touch is cancelled (a system gesture, another app) the pill goes back and nothing opens. A second finger is ignored during a drag.
* How it works in the code: `TabPillDrag.java` (new) wraps the window's callback, which is how the touch is seen before the tabs get it: a proxy that passes every call on to the real callback and looks at `dispatchTouchEvent` first. It is in the window only while the setting is on and a pill is on screen, and is taken off again after. At the hold the tab under the finger gets a cancel (so it does not click when the finger lets go), and at the end the tab under the finger gets a touch down and up in its middle, sent through the bar like a real tap (if nothing takes it, the tab is clicked directly). Errors are logged and the touch goes on to the app as if it were not there. `SelectedTabPill.Highlight` (see 1.8.15) learned to be dragged: where the finger took hold, the position along the bar, the drop on a tab, and holding the drop for up to 0.8 s until Instagram marks the new tab as selected. The floating navigation bar's `Pill` in `FloatingNavBar.java` now uses the same `Highlight` instead of its own copy of the slide code, so both bars behave the same; `FloatingNavBar.tabPillDrag` hands the bar and its highlight over once per frame. `NativeBarBlur.highlight` gives the highlight of Instagram's own bar. `Settings.CUSTOM_TAB_PILL_DRAG`, `Pref.tabPillDrag`, `ScreenBuilder.java` and `strings.xml` for the setting.
* Version set to 1.8.16 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: `SelectedTabPill.java`, `NativeBarBlur.java`, `TabPillDrag.java` and the `Pill` class of `FloatingNavBar.java` compile with javac (all warnings on, none shown) against hand-written stand-ins for the Android classes. The whole gesture was run on a fake window, bar and clock: a tap on the selected tab, a touch away from the pill and a move before the hold all reach the app untouched; after the hold the tab gets a cancel and a buzz, moves and the up are not passed on, the pill is drawn under the finger (a little bigger, inside the pill, never past the last tab); letting go over tab 2 sends a touch down and then up to its middle and the pill stays there until Instagram marks it, then goes back after 0.8 s if Instagram never does; letting go over the starting tab, past the end of the row, cancelling, losing the window's focus and a new touch in the middle of a drag all end cleanly; switching the setting off puts the app's own callback back. Not run on a phone: whether Instagram's tabs open from a touch sent through the bar (that is the one thing to try; it has a fallback to a direct click), how the buzz and the lift feel, and the rest of `FloatingNavBar.java` (checked by reading: braces balance and every call matches). If the build fails, send the error text.

## 1.8.15

* **New: "Custom selected tab pill" now works on Instagram's own floating bar too.** Before, it only worked on the floating navigation bar and stepped aside while "Instagram's own floating bar" was on. Now the highlight is drawn behind the selected tab of Instagram's own bar as well, with your picture or, until you pick one, the soft capsule.
* **Same as on the floating navigation bar.** The same picture (three slices, round ends kept), the same place (the selected tab's cell inside the pill, kept 11 % of the pill's height, at least 2 dp, from its edge) and the same slide to the new tab (about 0.2 s). So it follows the Width and Height sliders at once. It is drawn on top of the pill, blurred or not, and under the icons, so Blur amount and Transparency do not change it.
* **Settings.** The switch and the two picture buttons are usable while either floating bar is on (they were dimmed while Instagram's own bar was on), and the preview in the settings shows the highlight for both bars.
* **Limits.** Instagram's own bar only after the app has been restarted with its switch on (like its size and blur). The highlight is drawn by the same background that draws the pill and the blur, so it needs Android 12 or newer, like them; on older Android the bar is left as Instagram draws it. Instagram's own selected tab pill is kept off by the same flag as before (needs a restart if "Remove selected tab pill" was off). The selected tab is read from the tabs' selected state; if no single tab can be told apart, nothing is drawn and one line goes to the log ("Selected tab pill: no single selected tab ...").
* **If it does not show,** "Copy navigation bar info" now ends with one more line under "Where the pill is drawn": which tab was found as selected, and for the first 8 children of the bar whether each is marked selected or activated. Send that block.
* How it works in the code: `SelectedTabPill.java` (new `Highlight`: the selected tab, the slide and the drawing for a bar whose background is a drawable; `describeSelection`), `NativeBarBlur.java` (`apply` takes `tabPill` and `tabPillImage`; `Backdrop.updateTabPill` and `drawTabPill`; `debugShape` adds the selected-tab line), `FloatingNavBar.java` (`nativeBlur` passes the setting and the picture on), `ScreenBuilder.java` (availability), `FloatingNavSizePreference.java` (preview), `strings.xml` (the description). The pill of the floating navigation bar is untouched.
* Version set to 1.8.15 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: `SelectedTabPill.java` and `NativeBarBlur.java` compile with javac (all warnings on, none shown) against hand-written stand-ins for the Android classes they use. `Highlight` was run on a fake bar of five tabs: it finds tab 0, asks for a redraw only when something changed, puts the capsule in the tab's cell (31..109 of a 100 px bar at 2x), slides to another tab in 220 ms (half way it is between the two), jumps at once when a slider widens the cells, draws nothing and says so when two tabs look selected, and goes quiet when switched off. Not run on a phone: how Instagram marks the selected tab on its own bar, and how the highlight looks there, have to be tried. `FloatingNavBar.java`, `ScreenBuilder.java` and `FloatingNavSizePreference.java` were checked by reading only (the call's types match, braces balance). If the build fails, send the error text.

## 1.8.14

* **New: Custom selected tab pill for the floating navigation bar.** Settings > Navigation bar > Custom selected tab pill (off by default). Draws a pill behind the selected tab of the floating navigation bar, like the highlighted Home capsule in a glass-style bar. Until you pick a picture it is a soft translucent capsule; **Selected tab pill picture** lets you pick your own image, and **Remove selected tab pill picture** goes back to the capsule.
* **It resizes with the bar.** The pill is not a stored size: it is worked out from the selected tab's cell inside the floating bar, so the Width and Height sliders (Navigation bar > Floating bar size) change it at once, and the preview in the settings shows it too. A wider bar gives wider cells, a taller bar a taller pill. It sits a little inside the bar's edge on every side (11 % of the bar's height, at least 2 dp), so it is a smaller capsule nested in the bar's own ends. When you change tab it slides over to the new tab (about 0.2 s).
* **How the picture is resized.** The picture is cut into three slices from left to right: the two ends keep their round shape (scaled by the pill's height) and only the middle is stretched. A capsule-shaped PNG with transparent corners therefore stays a capsule at any width and height. The picture is scaled down to 512 px on its longest side when it is added and kept as a PNG in the app's private storage (transparency is kept).
* **Instagram's own pill.** While this is on, Instagram's own selected tab pill is kept off as well (the same flag as "Remove selected tab pill"), so the two never show at once. That flag is read when the bar is created, so it needs a restart if "Remove selected tab pill" was off before.
* **Limits.** Only for the floating navigation bar, not for Instagram's own floating bar (it steps aside, as the pill does). The selected tab is read from the tabs' selected state; if no single tab can be told apart, the pill is not drawn and one line goes to the log ("Selected tab pill: no single selected tab ...").
* How it works in the code: new `SelectedTabPill.java` (picture storage and import, the geometry, the three-slice drawing, finding the selected tab), `FloatingNavBar.java` (the pill draws the highlight behind the tabs and slides it; the selected tab is looked at on every frame), `FloatingNavSizePreference.java` (the preview draws the same highlight), `Settings.java` (`custom_tab_pill`), `Pref.java`, `HookFlags.java`, `ScreenBuilder.java` (the switch and two buttons), `ButtonPref.java`, `ActivityHook.java` and `RestorePrefFragment.java` (the picture picker, same way as "Add font"), `strings.xml` (English only).
* **Fix: the pill of Instagram's own floating bar did not match the icons, the width or the height of the sliders.** From the copied bar info and two screenshots (phone with density 2.8125, Instagram's bar 384 dp wide with 24 dp side padding and 19 dp of system inset under it, tabs 48 dp tall): the sliders were set to 100% and 48 dp, but the pill measured about 351 x 42 dp and its middle was about 6 dp below the middle of the icons. On the Reels tab the pill was the whole bar, gesture inset included, so the icons sat 9 dp above its middle. Cause: Instagram's background on the feed is an `InsetDrawable` that keeps fixed distances from the bar's edges (about 17 dp at the sides, 9 dp above, 16 dp below), so once `NativeBarSize` made the bar lower the pill shrank with it and no longer lay around the tabs, and `NativeBarBlur` copied that shape; on Reels the background is flat and fills the whole bar. The size sliders never reached the drawn pill at all, only the bar's layout.
* **What changed.** The pill is now laid out by `NativeBarBlur` instead of copied from Instagram's background: as wide as the bar when the width of the slider is on the bar (so 100% is edge to edge, as the preview shows), as tall as the height slider, and always centered on the tabs, so the icons are in the middle of it on every tab, Reels included. On the numbers above that is 384 x 48 dp with its middle at 24 dp, the same as the icons. Instagram's own pill shape is only used when the width could not be applied to the bar.
* **With the blur switched off the pill is fitted as well.** Instagram's own background is drawn (clipped to the rounded pill) at the fitted place, so the bar keeps Instagram's colours and gets the size of the sliders. Before, only the blur path had a pill of its own.
* **"Copy navigation bar info" now ends with where the pill is drawn:** its size and position in the bar, where the tabs' centre is, and the distances Instagram's own pill keeps from its edges. If the pill still looks off, send that block.
* How it works in the code: `NativeBarBlur.java` (`apply` takes `glass`, `fillWidth`, `pillHeightPx`; `Backdrop.shape`, `tabsCentre`, `drawOwn`), `FloatingNavBar.java` (`nativeBlur` runs while Instagram's own bar is on, with or without the blur switch), `NativeBarSize.java` (`widthApplied`, debug report).
* **This version puts the two together.** The unreleased fix to the pill of Instagram's own floating bar (sent as v1.8.13) and the new "Custom selected tab pill" (sent as v1.8.13pill, built on 1.8.12) are in one project now. They touch the same file, `FloatingNavBar.java`: the pill's changes there (the highlight, its slide, reading the selected tab) are all kept, and `nativeBlur` keeps the fixed version (the pill of Instagram's own bar laid out by `NativeBarBlur`). `NativeBarBlur.java` and `NativeBarSize.java` are exactly as in the fix.
* Version set to 1.8.14 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked, for the merge: every symbol that `FloatingNavBar.java` uses from `SelectedTabPill`, `Pref`, `NativeBarBlur`, `NativeBarSize` and `FloatingNavSize` exists with the signature it is called with, braces and parentheses balance in all changed Java files, and `strings.xml`, `patches-bundle.json` and `patches-list.json` parse. The merged project was **not compiled or run** (no Android SDK here). If the build fails, send the error text.
* Checked, before the merge (in the two projects it comes from): the changed Java was compiled with javac against the Android API 34 stubs (`SelectedTabPill` and `FloatingNavBar` with full analysis, no errors; the other changed files give exactly the same errors as before the change, all of them from classes that are not available here). Not run on a phone: how the selected tab is marked by Instagram, and how the pill looks, have to be tried there. If the pill does not show, send the log line above.
* Checked, before the merge (the pill fix): `NativeBarBlur.java` compiles against stand-ins for the Android classes it uses, and `Backdrop.shape` was run with the numbers above (pill 384 x 48 dp centered on the tabs at 24 dp; 40 dp slider and a bar whose height could not be changed also come out centered). Not run on a phone, and `FloatingNavBar.java` / `NativeBarSize.java` were checked by reading only. If the build fails, send the error text.

## 1.8.12

* **Fix: tabs in Instagram's own floating bar are now fitted more carefully (review of 1.8.11).** A tab that is too tall for the bar still shrinks to the bar's content, but a tab that fits now keeps its own 48 dp height and is centered in the bar instead of being stretched. Stretching moved what is drawn inside a tab (the badge / dot under an icon) when the bar was made taller. The tab's gravity is given back together with its height when the setting is switched off.
* **Fix: "Copy navigation bar info" now dims with the other floating-bar settings** (it was only added when the bar was already on at the moment the screen was built, so it did not follow the switch).
* How it works in the code: `NativeBarSize.java` (`fitTabs`, `giveTabsBack`, `Memory.tabHeights` now keeps height and gravity), `ScreenBuilder.java` (`availableWhen`).
* Version set to 1.8.12 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked by reading only: braces balance and every reference was cross-checked, but not compiled against Android classes or run (no Android SDK here). If the build fails, send the error text.

## 1.8.11

* **Fix: icons off-centre / cut off in Instagram's own floating bar.** From the copied bar info: Instagram's bar keeps its tabs at a fixed 48 dp height, sitting on the bottom padding. When the height slider made the bar's content shorter than that (44 dp in the report), the tabs stuck out 4 dp above the top and were cut off (the bar clips its children), so the icons sat above the middle of the capsule and the home highlight poked out. Now every tab is made exactly as tall as the bar's content, so its icon (centered in the tab) is centered in the bar, and the tab heights are given back when the setting is switched off.
* How it works in the code: `NativeBarSize.java` (`fitTabs`, `giveTabsBack`; `giveHeightBack` now takes the bar). This fix was made on 1.8.5 and is carried over onto 1.8.10.
* Version set to 1.8.11 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked by reading only: not compiled or run (no Android SDK here). If the build fails, send the error text.

## 1.8.10

* **Changed: lighter blur behind the sheet.** The page behind the Piko menu, "More profile options" and "Download options" is blurred 7 dp (was 16 dp), so it stays easier to recognise. Set by `BLUR_RADIUS_DP` in `PikoMenuSheet.java`.
* Version set to 1.8.10 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked by reading only: not compiled or run (no Android SDK here). If the build fails, send the error text.

## 1.8.9

* **Fix: the last card was cut off by the navigation bar.** The sheet used to stop above the bar with a hard edge, so a long list (like "Download options") was sliced there. Now the list runs down to the bottom of the screen and scrolls through the bar area, with the last card kept clear of the gesture handle. See `applyBodyPadding()` and the inset listener in `PikoMenuSheet.java`.
* **Changed: the sheet itself is more see-through.** 60% opaque (was 85%) when the page behind is blurred. Set by `SHEET_GLASS_ALPHA` in `PikoMenuSheet.java`.
* Version set to 1.8.9 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked by reading only: braces balance, but not compiled against Android classes or run (no Android SDK here). If the build fails, send the error text.

## 1.8.8

* **Changed: the card sheets are more see-through.** The cards of the Piko menu, "More profile options" and "Download options" are now 50% opaque (was 80%) when the page behind is blurred. Set by `CARD_GLASS_ALPHA` in `PikoMenuSheet.java`.
* **Changed: rounder top corners on the sheet.** 40 dp (was 24 dp). Set by `SHEET_TOP_RADIUS_DP` in `PikoMenuSheet.java`.
* **Fix: the navigation bar under the sheet had a colour of its own** (dark, or grey in light mode). It is now transparent, the sheet draws down to the bottom edge, and the gesture handle turns dark or light to match the sheet. See `makeNavigationBarTransparent()` in `PikoMenuSheet.java`. If a strip still shows, `Utils.setDialogWindowParameters` (outside this zip) may be setting a colour again.
* The sheet used by "Select media to download" (`DownloadSelectionSheet.java`) is not a card sheet and was not changed.
* Version set to 1.8.8 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked by reading only: braces balance, but not compiled against Android classes or run (no Android SDK here). If the build fails, send the error text.

## 1.8.7

* **Changed: "Download options" now opens as the same card sheet as "More profile options".** The plain dialog (a title, a list of text lines and a Close button) is gone. Pressing the download button on a post, reel or story slides up the sheet with the page behind it blurred, and one rounded card per option, each with a coloured round badge:
  * **Download current media**, **Download as image**, **Download audio** (only when the media has sound), **Copy media link**, **Image variants**, **Video variants** (videos only), **Open video / image externally**, and for carousels **Select media to download** and **Download all**.
  * Image variants, Video variants and Select media to download show an arrow, because they open another list.
  * Tapping a card closes the sheet and does what the old line did. Drag down or tap outside to close (there is no Close button, like the profile sheet).
  * If the sheet cannot be shown for any reason, the old dialog opens instead, so the options are never lost.
* How it works in the code: `PikoMenuSheet.java` (new `showOptions(context, title, options, onDismiss)` overload; the dismiss callback runs after the sheet has left the screen), `DownloadUtils.java` (`downloadDialogBox` builds the cards from the same option list and falls back to the old dialog; the click logic is one `optionHandler` used by both; stories still resume only when no follow-up list was opened). Version set to 1.8.7 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked by reading only: not compiled against Android classes or run (no Android SDK here). If the build fails, send the error text. The badge colours and icons are only seen on the phone.

## 1.8.6

* **Changed: "More profile options" now opens as the same card sheet as the Piko menu.** The plain dialog (a title, a list of text lines and a Close button) is gone. Pressing the profile's "More profile options" button (or the matching icon on the profile top bar) slides up the sheet with the page behind it blurred, and one rounded card per option, each with a coloured round badge:
  * **View profile picture**, **Copy username** (shows `@username`), **Copy full name** (shows the name), **Copy user id** (shows the id), **Copy bio** (shows the first line of the bio), **Copy links from bio**, and **Debug** when debug is on.
  * Tapping a card closes the sheet and does what the old line did (copy and toast, or open the picture viewer). Drag down or tap outside to close.
  * If the sheet cannot be shown for any reason, the old dialog opens instead, so the options are never lost.
* How it works in the code: `PikoMenuSheet.java` (new public `showOptions(context, title, options)` and `Option`; the Piko menu itself is unchanged; the cards can cut a second line to one line), `ProfileMoreOption.java` (`moreOptionsDailogueBox` builds the cards and falls back to `plainDialog`; the click logic moved to one `perform(key, ...)` used by both). Version set to 1.8.6 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked by reading only: the two changed files pass a javac syntax check, but were not compiled against Android classes or run (no Android SDK here). If the build fails, send the error text. How it looks (badge colours, the length of the subtitles) is only seen on the phone.

## 1.8.4

* **New: "Copy navigation bar info" button.** Settings > Navigation bar (shown while "Instagram's own floating bar" is on). Tap it to copy how Instagram's own floating bar is built (the bar and its children: sizes, layout parameters, gravity, padding, offsets, clipping), as it was first seen and again after the sliders' size was applied, so a bar whose icons sit off-centre can be fixed from real numbers. Open the home screen once first, otherwise it says there is nothing to copy yet.
* How it works in the code: `NativeBarSize.java` (now public; `debugReport()` and `describeTree`), `ButtonPref.java` (`piko_copy_nav_bar_info`), `ScreenBuilder.java` and `strings.xml` (English only). Version set to 1.8.4 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked by reading only: not compiled or run. If the build fails, send the error text.

* **Fix attempt: the Width and Height sliders on Instagram's own floating bar.** `NativeBarSize.java` used to give up for good, without a word, as soon as Instagram's tabs were taller than the height chosen (the tab highlight on the real bar is taller than the 28 dp minimum), or after one bad measurement (Instagram moves and resizes its bar by itself while you scroll). Now it keeps the height you chose even when the tabs are taller, and only gives up on a width or a height after three bad checks in a row. It also writes one log line, "Floating navigation bar: Instagram's own bar structure: ...", with the bar's size, layout parameters, parents and children, so a bar that still ignores the sliders can be fixed from real numbers. Not run on a phone.

## 1.8.1

* **The live preview now shows the blur and the transparency.** In Settings > Navigation bar > Floating bar size, the preview of the bar changes while you drag the "Blur amount" and "Transparency" sliders: the page behind the pill is blurred by the same amount as the real bar (0% sharp, 100% strongest) and the pill's tint gets the same transparency (0% solid, 100% no tint). It shows this only while "Instagram's own floating bar" and its blur switch are on and the phone is Android 12 or newer; otherwise the preview is the plain pill as before (the floating navigation bar's own pill has no blur).
* How it works in the code: `FloatingNavSizePreference.java` (the preview records the page into a `RenderNode` with a blur `RenderEffect`, draws it clipped to the pill, then the tint; new `previewGlass`), `PercentSliderPreference.java` (new `live` callback on every step) and `ScreenBuilder.java`. Version set to 1.8.1 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked by reading only: not compiled or run (no Java compiler or Android SDK here). If the build fails, send the error text.

## 1.8.0

* **New: two sliders for Instagram's own floating bar, from 0 to 100%.** Settings > Navigation bar, right under "Blur behind Instagram's own floating bar":
  * **Blur amount.** 0% = no blur (what is behind the bar shows sharp through the glass), 100% = the strongest blur (44 dp radius). The default, 50%, is the same 22 dp blur as before.
  * **Transparency.** 0% = a solid tint, 100% = no tint at all (the page behind shows through untouched, only the thin edge of the bar stays). The default, 50%, gives a tint alpha of about 50% (it was about 52% on dark and 62% on light before, so the light theme is a little more see-through by default).
  * Both are dimmed unless "Instagram's own floating bar" and its blur switch are on. They apply as soon as you go back to the app (no restart), like the size sliders.
* How it works in the code: new `PercentSliderPreference.java` (a 0 to 100% slider row); `Settings.java` (`native_floating_nav_blur_level`, `native_floating_nav_transparency`, both default 50, no restart), `Pref.java`, `Helper.java`, `ScreenBuilder.java`, `strings.xml` (English only), `FloatingNavBar.java` (reads the two values with the other settings) and `NativeBarBlur.java` (`apply` and `Backdrop.update` take the two numbers; the blur radius and the tint alpha are worked out from them, and at 0% blur the blur effect is left off instead of asking for a radius of 0). Version set to 1.8.0 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked by reading only: no Java compiler or Android SDK here, so this was not compiled, built or run on a phone. If the build fails, send the error text.

## 1.7.2

* **Fixed: crash with the blur on ("ending radius must be > 0").** From your crash report (Android 16): to read the shape of Instagram's pill, 1.7.1 drew Instagram's background once into a picture and then put the bounds it had before back on it. Those bounds were empty (the bar never draws that background while the blur is on), and Instagram's background (an inset around a drawable that builds a radial gradient) throws when it is given an empty size. It also happened in the middle of a bounds change. Now:
  * the old bounds are **not** put back (that drawable is never drawn by the bar while the blur is on), and anything Instagram's drawable throws is caught, so the shape then falls back to the bar's own size;
  * the shape is measured only from `draw()`, never while the bounds or the outline are being changed;
  * the colour of Instagram's bar is read from the middle of what it paints in that same picture (the old 8 px picture could be smaller than the drawable's insets and fail the same way).
* How it works in the code: `NativeBarBlur.java` (`measureBase`, `shape`, `colorUnder`). Version set to 1.7.2 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: the `patches/navigation` package compiles against the real Android 13 `android.jar` with no error or warning of its own. Not built as a whole and not run on a phone.

## 1.7.1

* **Fixed: the blur did not blur, and its shape did not match Instagram's bar** (from your two screenshots: with the blur on, the text behind the bar was still sharp, and the glass was about 20 px taller than Instagram's own pill, starting higher than it).
  * **The blur now records what is behind the bar, not a "page".** 1.7.0 looked for the page by the id of the screen container (or by where it is) and gave up, leaving only the tint, when that view was not there or contained the bar. Now every view that is drawn before the bar's branch in each of the bar's parents is recorded, wherever the page sits and whatever it is called. None of them contains the bar, so the bar can never be recorded into its own blur. It still points at the views' own display lists, so it stays live.
  * **The shape is read from Instagram's own background.** The bar view is taller than its visible pill (the system inset under it, the room around it), and 1.7.0 used the bar's bounds. Instagram's background is now drawn once into a small picture and the box of what it paints is the shape (done again only when the bar's size or background changes). The glass lies exactly on Instagram's pill, with its corner radius when it has one (a full pill otherwise). If the shape cannot be read, the old way is the fallback.
  * **The log tells what happened.** "Floating navigation bar: blur recorded N view(s) behind Instagram's own bar" is written once when the blur is drawn. If it is missing, or N is 0, send me the lines that start with "Floating navigation bar".
* How it works in the code: `NativeBarBlur.java` (`drawBlur`, new `measureBase`, `shape`; the page search is gone) and the call in `FloatingNavBar.java`. Version set to 1.7.1 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: the whole `patches/navigation` package was compiled with every javac lint warning on against the real Android 13 `android.jar`, with no error and no warning of its own. Not built as a whole and not run on a phone: the real result is only seen on your phone.

## 1.7.0

* **New: live blur behind Instagram's own floating bar (off by default).** Settings > Navigation bar > Blur behind Instagram's own floating bar. The bar gets a see-through glass look: the feed, Reels, search or profile that runs behind it shows through, blurred, and moves live as you scroll. **Only Instagram's own floating bar gets it.** The pill of the "Floating navigation bar" and the stock bar are never touched, and the switch is dimmed (and does nothing) unless "Instagram's own floating bar" is on and the app has been restarted since, so that bar really is Instagram's floating one.
  * **How it works.** The bar's background is swapped for a drawable (`NativeBarBlur.Backdrop`). Each time the bar is drawn, the drawable records the page behind it into a `RenderNode` with a blur `RenderEffect` (22 dp), and draws that clipped to the bar's rounded shape, with a translucent tint (taken from the colour of Instagram's own bar background, so it follows light, dark and AMOLED black) and a thin edge on top. The recording points at the page's own display lists, so the blur follows the page while it scrolls or plays. The page is the screen container (`layout_container_main`) or, failing that, the page found by where it is (the same finder the pill uses), and never a view that contains the bar (that would record the bar into its own blur). Instagram's own background is kept (not drawn) and given back when the switch is turned off.
  * **No timer, no extra frames while the screen is still.** The bar is drawn again only before a frame that is going to be drawn anyway, and the frame that this causes is left alone, so it cannot loop.
  * **No restart.** Applies as soon as you go back to the app, like the size sliders.
  * **Limits.** Needs Android 12 or newer (`RenderEffect`); on older versions the bar is left as Instagram draws it and the log says so. A video drawn on a `SurfaceView` cannot be recorded by any view and shows as a hole in the blur (a `TextureView` blurs normally). Instagram's bar was not seen when this was written: if its pill is drawn by a child view that is not see-through, the blur lies under it and cannot be seen. The log line "Floating navigation bar: blur put on Instagram's own bar. Background: ...; children: ..." tells what the bar's background and children are, so send it if the blur does not show. If the blur cannot be drawn, the tint stays, the blur is given up on for that bar and the reason goes to the log; if Instagram sets its background back on every frame, the blur is given up on too.
  * **Changed in the shape of the bar.** With the blur on, the bar casts no shadow (a shadow under a see-through bar looks muddy).
* How it works in the code: new `NativeBarBlur.java`; `FloatingNavBar.java` (new state, the setting read with the others, a new `nativeBlur` step next to the size step, reset for a new bar), `Settings.java` (`native_floating_nav_blur`, off, no restart), `Pref.java`, `ScreenBuilder.java` (new switch, dimmed unless Instagram's own bar is on) and `strings.xml` (English only). Nothing is searched for in Instagram's code, so no fingerprint can fail on any Instagram version. Version set to 1.7.0 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: `NativeBarBlur.java` and the whole `patches/navigation` package (with `FloatingNavBar.java` as changed) were compiled with every javac lint warning on against the real Android 13 (API 33) `android.jar`, with no error and no warning of their own (the one deprecation note for `Drawable.getOpacity` is the same one the pill has). The classes the files depend on (`Logger`, `Utils`, `Pref`, `HookFlags`) were replaced by stand-ins. **The rest of the project was not built (no Gradle or Morphe libraries here) and nothing was run on a phone**, so how the blur looks on Instagram's real bar has to be tried there. If the build fails or the blur does not show, send the error text or the log lines that start with "Floating navigation bar".

## 1.6.3

* **Fixed: "Hide the gesture line" could bring back the empty bottom space that "Remove empty bottom space" removes.** The two settings do not touch each other in code (the patch only changes how Instagram reads the size of the navigation bar, the floating bar only reads what is on the screen), but 1.6.2 moved the floating bar up by the whole inset of the hidden navigation bar, whatever Instagram had done with that inset. When Instagram reserves no room under the bar (which can be the case with the empty-space setting on), the tabs do not sink when the navigation bar is hidden, so the bar was moved up for nothing and floated one inset above the bottom edge: the strip was back.
  * **Now measured.** The place of the tabs (their distance from the bottom of the window) is read on every frame while the navigation bar is shown. While it is hidden, the bar is moved up by how far the tabs really sank from that place, and never by more than the inset the system took away. When the tabs did not sink, nothing is moved. When they sank by the whole inset (the usual case without the empty-space setting) the result is the same as in 1.6.2.
  * **Fallback.** If there is no earlier place (the window started with the navigation bar hidden) or the bar is not laid out yet, the whole inset is used, as in 1.6.2.
* **Checked, no change needed:** the pill (`FloatingNavBar`) and the size given to Instagram's own bar (`NativeBarSize`) read the bar's real bottom padding instead of assuming an inset, so they follow whatever Instagram reserves, with or without "Remove empty bottom space". `BarFrameRemover` looks at what is on the screen and does nothing when the page already runs down. No patch touches the same method (the empty-space patch uses the `config_showNavigationBar` fingerprint, the navigation bar patch other ones). "Remove empty bottom space" needs a restart of the app; the floating bar and the gesture line apply without one.
* How it works: `GestureLineHider.java` (`keepBarUp` measures the sink with the new `Memory.shownGap` and `tabsGapPx`; class comment updated). Nothing else changed. Version set to 1.6.3 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: `GestureLineHider.java` was compiled with every javac warning on against stand-ins for the Android classes, with no warning, and run on a small model of the window (27 checks: padding that follows the inset, nothing reserved under the bar, a container that shrinks by the inset, repeated frames stay stable, the bars coming back and hiding again, an animation of Instagram's on the bar, no earlier place, a bar not laid out, the cap at the inset, and the restore). The 1.6.2 version of the same file fails the "nothing reserved" cases in that model, which is the problem described above. The stand-ins are a model of Android, not Android. **The rest of the project was not built (no Gradle or Android SDK here) and nothing was run on a phone**: whether the empty-space patch really leaves the bar's padding alone on your Instagram build is not something that can be seen from the source, so this fix is written to be right either way.

## 1.6.2

* **New: Hide the gesture line (off by default).** Settings > Navigation bar > Hide the gesture line. The thin white line under the floating bar in your screenshot is not part of Instagram and not a bug of the bar: it is the gesture handle of Android's gesture navigation, which the system draws on top of every app. The screenshot shows the page running right down behind it, so no strip is left under the bar. With the stock bar the handle sits on the bar's solid background and goes unseen; with a floating bar it floats over the picture. An app cannot switch the handle off by itself, so the only way to remove it is to hide the system navigation bar of the app's main screen, and this switch does that while the floating navigation bar or Instagram's own floating bar is on (it is dimmed otherwise).
  * **The bar stays where it is.** With the navigation bar hidden, the system inset under the bar is 0 and Instagram would lay the bar lower, against the edge of the screen. The bar is moved up by the size of the inset it lost (read from the window's insets). Only its translation is changed, never its layout, and an animation Instagram runs on the bar is kept.
  * **The catch, which is why it is off by default.** With the navigation bar hidden, a swipe up from the bottom edge first shows the line for a moment (it hides again by itself) and only the next swipe goes Home or opens the recent apps. That is how Android treats any app that hides its navigation bar. If you would rather keep one-swipe gestures, leave the switch off; on some phones the line can also be turned off in the phone's own settings (for example Samsung: Settings > Display > Navigation bar > Gesture hint).
  * **When it applies.** As soon as you go back to the app, no restart. It is done again whenever the window gets the focus back (after a dialog, the keyboard or another app), because the system brings its bars back then. Switched off, the navigation bar and the bar's position are given back.
* **Changed: an error in the floating bar can no longer repeat on every frame.** The floating bar code (the pill and the size given to Instagram's own bar) runs before every frame. If something went wrong on one Instagram version it was caught, but tried again on the next frame with a log line each time. After five errors in a row the bar is now left alone for five seconds and then tried again, so a problem cannot slow the app down or fill the log, and nothing can reach the app.
* **Not changed, on purpose:** the size rules of Instagram's own floating bar (1.6.1). They were not touched because the look you have tuned with the sliders must not move under you.
* How it works: new `GestureLineHider.java` (hides the navigation bar with `WindowInsetsController` on Android 11 and later and with the system UI flags before that, remembers what the window had and gives it back, and moves the bar up by the missing inset). `FloatingNavBar.java` runs it from the same pre-draw check (new `gestureLine` step, a focus listener, and the error damping around the old `tick`, which is now `tickBar`). `Settings.java` (`hide_gesture_line`, off, no restart), `Pref.java`, `ScreenBuilder.java` and `strings.xml` (English only) got the switch. Nothing is searched for in Instagram's code, so no fingerprint can fail on any Instagram version. Version set to 1.6.2 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: the brackets of the changed files were counted and the changes were read through against the code around them. **Nothing was compiled here (no Java compiler was available) and nothing was run on a phone**, so the build and how the line and the bar behave on your phone have to be tried there. If the build fails, send the error text.

## 1.6.1

* **Fixed: the Width and Height sliders now change Instagram's own floating bar.** With Settings > Navigation bar > Instagram's own floating bar on, the sliders under Floating bar size did nothing: the pill steps aside while Instagram's bar is on, and the sliders only ever drove the pill. They now drive Instagram's bar as well:
  * **Width.** The bar is as wide as the preview and the percentage next to the slider say (the screen minus the distance to each side, the same number the pill uses). A bar that fills its row keeps doing so and gets margins on both sides; a bar with a width of its own gets that width and is centered in its row.
  * **Height.** The bar is as tall as the number of dp next to the slider says, measured above the system inset. Whatever padding Instagram gives the bar (the gesture area under it, for instance) is kept on top of that.
  * **The numbers are absolute.** Like for the pill, they are not "more or less than Instagram's size", they are the size. With the sliders left where they are by default (Reset), Instagram's bar is 40 dp tall and about 87 % wide on a 360 dp screen. Drag them to the size you want.
  * **The size row is available while either bar is on.** Before it was dimmed whenever only Instagram's own bar was on. The texts of both rows now say that the sliders apply to Instagram's bar too.
  * **When it applies.** Within half a second of going back to the app (no restart for the size). Instagram's bar itself still needs the restart that the switch asks for: a bar that is still the stock one (the switch was turned on a moment ago and the app was not restarted) is not touched, so the stock bar never ends up narrowed. The flags are looked at when the bar is found, once per bar. Switching the setting off gives the bar the size Instagram chose.
  * **It looks at the result.** Instagram's bar was not seen when this was written, so a few frames after a change the bar is measured. A width that is not the one asked for, or a bar that is not in the middle of its row, gives the width back and leaves it alone. A height that is not the one asked for, or one that would cut the tabs off because they have a height of their own, gives the height back and leaves alone that height and every smaller one (a taller bar is still tried). The two are judged apart. If Instagram sets its layout back on every frame, both are given up on. What was given up on is remembered until the setting is switched off or the app is restarted. Each case writes a line that starts with "Floating navigation bar: Instagram's own bar" (adb logcat, or the Morphe debug log), with the measured and the asked size. If the sliders still have no effect on your build, send me those lines.
* How it works: new `NativeBarSize.java` changes only the bar's own layout parameters (width, side margins, gravity, height), remembers what Instagram had and puts it back. `FloatingNavBar.java` runs it from the same pre-draw check as the pill, finds the bar by the same id (`tab_bar`), and starts it afresh for a new bar. Nothing is searched for in Instagram's code, so no fingerprint can fail on any Instagram version.
* Changed: new `NativeBarSize.java`; `FloatingNavBar.java` (the native step, the state for it and the reset for a new bar), `HookFlags.java` (new `nativeFloatingNavActive()`, which tells whether the two flags of Instagram's bar are on), `ScreenBuilder.java` (the size row is available while either bar is on), `FloatingNavSize.java` (comment only) and `strings.xml` (English only). Version set to 1.6.1 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: `NativeBarSize.java`, `FloatingNavBar.java` and `FloatingNavSize.java` were compiled with every javac warning on against stand-ins for the Android classes, with no warning. `NativeBarSize` was run on a small model of a bar in a frame (58 checks: a bar that fills its row, a bar with a width of its own with and without gravity, a bar that ignores the width, one that ignores the height, tabs with a height of their own and the retry with a taller bar, Instagram setting its layout back on every frame, a changed system inset, a value Instagram set after the change, a row narrower than the screen, and the restore). The way `FloatingNavBar` calls it was run as well (19 checks: Instagram's bar sized and given back, a stock bar left alone, a new bar looked at again, the pill's own path unchanged). The stand-ins are a model of Android, not Android. `HookFlags.java`, `ScreenBuilder.java` and `strings.xml` were only read through and were not built here, and nothing was run on a phone.

## 1.6.0

* **Fixed (second attempt): the floating bar no longer sits on a solid strip.** With the floating navigation bar on, the pill used to lie on a flat strip of Instagram's background above it, below it and beside it, with the page ending above that strip. The page is now meant to run down behind the pill and show around it, as in the App Store example. 1.2.1 only handled two causes and never said what it found. It could not be checked on a phone, so the cause on your build is not known; this release covers the other ways the strip can be kept, finds them by what is on the screen (not by Instagram's view names) and writes down what it finds. Each of these changes only a view that is really part of the strip, and every change is given back when the floating bar is turned off:
  * **A bottom container taller than the bar.** The bar can sit in a container that also holds the room for the system inset (gesture bar or three buttons) and has its own background. That used to be missed, because only containers no taller than the bar plus 6 dp counted. Containers up to the bar plus 72 dp that reach the bottom of the bar now lose their background.
  * **A view that only paints the strip, anywhere in the window.** For instance a view that colours the inset under the bar. It is found beside the bar and, every half second, anywhere in the window outside of the page and the bar. Only views with a background and nothing shown in them count; text, pictures, progress bars, anything thinner than 8 dp or narrower than the bar are left alone.
  * **A page that lies beside the bar instead of under it.** When the page stops short of the bar and no margin or padding is what holds it up, a page in a vertical column (taking the room that is left) gets a negative bottom margin, and a page in a relative layout that is placed "above the bar" loses that rule and goes to the bottom. Anything else is left alone. Both are given back.
  * **The screen container is found by where it is when its id is missing.** If `layout_container_main` is not in this Instagram version, the page is taken to be the biggest view beside the bar that is nearly as wide as the window and fills at least 40 % of its height. Before, a missing id meant nothing was done at all.
  * **The log tells what is there.** Lines that start with "Floating navigation bar:" (adb logcat, or the Morphe debug log) now list the views around the bar once (class, id name, size, layout, margin, padding, background), say which background, margin, padding or rule was taken, and, when the page still stops short and nothing could be done, name the views on the way. If the strip is still there after this release, send me those lines and the fix can be exact.
* **New: Instagram's own floating bar (experimental, off by default).** Settings > Navigation bar > Instagram's own floating bar. Instagram 452 has a floating bar of its own behind two MobileConfig flags of its "modern UI edge to edge" project: `ig_android_modern_ui_edge_to_edge::is_floating_tab_bar_enabled` (`126024::12`) and `::is_bottom_enabled_for_main_activity` (`126024::2`), both in `docs/mappings/452.1.0.53.64.json`. With this switch on, those two flags read as true and Instagram draws the bar and runs the page behind it itself, so no strip can be left around it. The Piko floating bar steps aside while this is on (its size sliders do not apply to Instagram's bar). It needs a restart of the app. Like the other flag settings, a flag set by hand in the developer options still wins. The look of Instagram's bar in this build was not seen, and whether 452 draws it fully is not known: if the bar looks wrong, turn the switch off.
* This is the floating-bar work (first made on top of 1.3.0) brought into the 1.5.x line, so it sits on top of the Piko menu, the settings animation and the removed tutorials, none of which it touches. (The archive you sent was named 1.5.2 but its files said 1.5.1, so this release is 1.6.0 and nothing clashes with either name.)
* Changed: `BarFrameRemover.java` (rewritten around the cases above) and `FloatingNavBar.java` (finds the page when the id is missing, hands the page to `BarFrameRemover`, steps aside when Instagram's own bar is on, and puts the frame's changes back before the container's margin). Both were unchanged between 1.3.0 and 1.5.2, so they replace the old files as a whole. `HookFlags.java` (new `nativeFloatingNavFlags()`, called in `load()` right after `selectedTabPillFlags()`), `Settings.java` (`native_floating_nav`, default off, restart required), `Pref.java`, `ScreenBuilder.java` and `strings.xml` (English only) got small additions next to the 1.5.x changes. Version set to 1.6.0 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: `FloatingNavBar.java`, `BarFrameRemover.java` and `FloatingNavSize.java` were compiled with every javac warning on against the Android API 23 classes (the one newer call, `Color.luminance`, was stood in for), using the 1.5.2 sources. The real `BarFrameRemover` was also run on a small stand-in for Android's views with a layout engine for a frame, a vertical column and a relative layout: 27 checks pass (the page reaches the bottom of the bar in each layout; the bar does not move; every margin, padding, rule and background goes back to what Instagram had; content, thin lines, progress bars and narrow views are not touched; nothing changes when the page already runs down). The stand-in is a model of Android, not Android. The other changed files are small additions in the pattern of 1.3.0 (checked to be balanced and to use only methods that exist in 1.5.2) and were not built here, and nothing was run on a phone.

## 1.5.1

* **Fixed: the build failed to compile.** `PikoMenuSheet.java` read the `body` field inside the menu's dismiss listener before the constructor had set it, and because the field was `final` the compiler stopped with "variable body might not have been initialized". The field is no longer `final` (it is still set once, in the constructor, before the listener can ever run), so behaviour is unchanged. Version set to 1.5.1 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.

## 1.5.0

* **New: the "Set up on new device" screens and the first-time tutorials are removed.** Always on, there is no switch (the same way Meta AI is always off). It needs a full restart of the app (swipe it away) to take effect.
  * **"Set up on new device" screens.** The screens that ask for your contacts and your location right after you log in never open. Before, this only worked while "Disable analytics" was switched on; now it does not depend on anything. All screens of Instagram's new-device family (`com.bloks.www.bloks.ig.ndx.`) are blocked, not only the two that were named before.
  * **Tutorials and tooltips for new users.** Instagram's "new user" tooltips, the tooltips that explain the account switcher (new linked account, new login, cross-app notifications), the Reels education screen and tooltip, the saved-reply tip in messages, the story viewer list and spotlight tips, and the "set up" reminder for encrypted chats are turned off.
* How it works: new `SkipFirstTimeTutorialsPatch.kt` (no name, so it is not listed and cannot be switched off; "Add settings" depends on it). The Bloks hook moved there from `DisableAnalyticsPatch.kt`, and calls the new `Tutorials.java`. The tooltips are server-controlled flags, so the new `HookFlags.tutorialFlags` answers them with "off" (and the "new user tooltip suppression" flag with "on"). Nothing new is searched for in Instagram's code, so no fingerprint can fail on any Instagram version except the one that was already used for the old hook.
* Changed: new `SkipFirstTimeTutorialsPatch.kt`, `Tutorials.java`; `DisableAnalyticsPatch.kt` (the Bloks hook and its fingerprint removed), `Links.java` (`shouldBlockOnboardingScreen` and its two screen ids removed), `SettingsPatch.kt` (depends on the new patch), `HookFlags.java` (`tutorialFlags`). Version set to 1.5.0 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: the edited files were read through and their brackets balance. Nothing was built or run here (no build tools, no Android classes and no Instagram app in this environment). What has to be tried on the phone: a fresh login or a cloned app, to see that no "Set up on new device" screen appears. The tooltip flags are the weak part: they are chosen by their names in `docs/mappings`, Instagram can rename or move them in a new version, and tutorials that are not behind one of these flags still show. If a tutorial still appears, tell me what it says and where, and it can be added.

## 1.4.3

* **New: the Piko menu and the Piko settings page open from the bottom with a blur-fade, and close the same way in reverse.** (The archive you sent was named 1.4.2 but its files still said 1.4.1, so this release is 1.4.3 and nothing clashes with that name.)
  * **Settings page, opening.** After you tap "Piko settings" the page rises from the bottom edge of the screen. While it rises it starts blurred and see-through, then fades in and sharpens as it settles at the top. The screen behind it is dimmed and blurred while the page is on its way, and goes back to normal when the page is in place.
  * **Settings page, closing.** The back arrow, the back button and the back gesture all play the opening in reverse: the page sinks to the bottom, blurs and fades out, and the screen behind comes back to normal as it goes. Back still closes search first, and still asks about the restart first when a setting needs one. The "Cancel" on that restart question closes the page the same way. Pressing back again while the page is sinking does nothing extra.
  * **Menu sheet.** The sheet already slid up from the bottom with the page behind it blurred. It now also rises out of a blur while fading in, and sinks into a blur while fading out (also when you drag it down). When you tap "Piko settings" the sheet stays where it is while the page rises over it, and is removed (without a slide) once the page covers it, so the two never cross each other. If the page does not open within 1.5 seconds the sheet slides away as before.
  * **Pages inside settings** (Navigation bar, DM, About and so on) keep Instagram's normal sideways transition. Only the main settings page and the menu use the new animation.
  * **Android 12 and newer:** the page itself is blurred, and the screen behind is blurred too when window blur is allowed on the phone (if it is off, the screen behind is only dimmed). **Android 11 and older:** no blur, only the rise, the fade and the dim.
  * Turning the phone's animations off makes it open and close at once. Rotating the phone or coming back to the page later does not replay the animation.
* How it works: the main settings page now opens in Instagram's see-through modal screen (`TransparentModalActivity`, the same one the launcher shortcut and the file pickers already use) instead of `ModalActivity`, so the app stays visible behind the page while it moves. Instagram's own open and close transitions are switched off for it, and the new `SettingsPageAnimator.java` moves, fades and blurs the page view itself. While the page is moving the status and navigation bars are see-through, and get the page colour back once it is in place.
* To tune it: in `SettingsPageAnimator.java`, `OPEN_MS` and `CLOSE_MS` set the speed, `PAGE_BLUR_DP` and `BEHIND_BLUR_DP` the blur strength, `BEHIND_DIM` the dimming; `ENABLED = false` brings back the 1.4.1 behaviour. For the sheet: `SHEET_BLUR_DP` and `SHEET_FADE_SPAN` in `PikoMenuSheet.java`.
* Changed: new `SettingsPageAnimator.java`; `SettingsActivity.java` (starts the animation, closes with it from every back path), `ActivityHook.java` (the main settings page launches in the see-through screen, with the system transition off), `SettingsRestart.java` (Cancel closes with the animation), `PikoMenuSheet.java` (sheet blur-fade, holds until the page covers it), `SheetBottomDialog.java` (shared; new `dismissInstantly()`, the download sheet does not use it). Version set to 1.4.3 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: all six changed files were parsed without a syntax error, and `SettingsPageAnimator.java` was compiled against stand-ins for the Android classes with no error and no warning. The other changed files could not be compiled here (the Android classes are not available in this environment), so they were checked by reading only. Nothing was run on a phone. What has to be tried there: that the page really shows the app behind it while it rises (this depends on Instagram's `TransparentModalActivity` theme), how the blur looks and feels, and the speed. If the page ever looks wrong at the top or bottom edge, or does not open, set `ENABLED = false` and tell me what you saw.

## 1.4.1

* **Changed: the Piko settings menu blurs the page behind it and is at least half a screen high.**
  * **Blur.** While the sheet is open, everything behind it is blurred and dimmed, and the sheet and its cards are slightly see-through with a thin edge, like a glass panel. The blur and the dim grow while the sheet slides up and fade while it slides away (also when you drag it down). On Android 12 and newer the phone's own window blur is used, which also blurs video that is playing behind the sheet. If window blur is switched off on the phone (battery saver, or a phone that does not support it), the screen under the sheet is blurred instead. From the launcher shortcut only the window blur can apply, because the screen behind is another app or the home screen. On Android 11 and older there is no blur: the page is only dimmed (a bit darker than before) and the sheet is solid, as in 1.4.0.
  * **Height.** The sheet is never lower than half of the screen. The three cards share the extra height equally, and are a little larger (bigger icon, bigger text). The Developers page keeps the same height, so the sheet does not jump when you open it.
* Changed: `PikoMenuSheet.java`; `SheetBottomDialog.java` (shared; the slide dialog can now report its slide progress to a listener, which the menu uses to fade the blur and the dim; the download sheet does not use it and works as before). Version set to 1.4.1 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: nothing was compiled or run here (no build tools or Android classes in this environment). The new code only uses calls that exist in Android 12+ for the blur and is kept in a separate class so older phones never load it. How strong the blur looks, and whether the cards fill the half screen evenly, has to be tried on the phone. If the blur is too strong or too weak, the radius is `BLUR_RADIUS_DP` at the top of `PikoMenuSheet.java`.

## 1.4.0

* **New: the Piko settings button opens a slide-up menu.** Pressing the Piko settings button (the gear in the action bar, or the "Piko settings" button on your profile) or the Piko shortcut on the Instagram launcher icon no longer jumps straight into the settings page. A sheet slides up from the bottom of the screen over the page you are on, with a dimmed background and a handle you can drag down (or tap outside, or press back) to close it. It holds three cards, top to bottom:
  1. **Piko settings**: opens the full settings page, exactly as the button did before.
  2. **Developers**: swaps the sheet to a short list (crimera for Piko, Morphe for the patcher and manager). A row with a link opens it. Back (the arrow, or the back button) returns to the menu.
  3. **Version info**: the patch version and the Instagram version, one under the other. It is not tappable.
* From the launcher shortcut the sheet is shown over a see-through screen, so the app or home screen you came from stays visible behind it, and the screen closes with the sheet. For this the shortcut now targets `com.instagram.modal.TransparentModalActivity` (the see-through modal screen Piko already uses for its file pickers) instead of `ModalActivity`.
* If there is no screen to put the sheet on, or showing it fails, the settings page opens directly as before, so the button can never end up doing nothing.
* The developers list is one array (`DEVELOPERS` in `PikoMenuSheet.java`); names are added there.
* Changed: new `PikoMenuSheet.java`; `FragmentHook.java` (`startSettings()` opens the menu), `ActivityHook.java` (the shortcut shows the menu), `SettingsResourcePatch.kt` (shortcut target) and `strings.xml` (English only; other languages fall back to English until they are translated). Version set to 1.4.0 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: nothing was compiled or run here (the build tools and the Android classes are not available in this environment); the new code only uses calls that the rest of the extension already uses (the same bottom-sheet helper as the download sheet). How the sheet looks, the slide animation, and the shortcut on a cold start have to be tried on a phone.

## 1.3.0

* **New: Remove selected tab pill (on/off).** Settings > Navigation bar > Remove selected tab pill. Instagram now draws a rounded pill behind the selected tab of the bottom bar (the grey capsule behind Home, and behind whichever tab is open). When this switch is on, that pill is gone and only the icon shows which tab is open. It works with the stock bar and with the floating navigation bar. **On by default**, since that is the look this release is for; turn it off to get Instagram's pill back. It needs a restart of the app after you change it (the app asks for it, like the other restart settings).
* How it works: Instagram turns the pill on from the server with a MobileConfig flag, `ig_android_modernization::enable_active_pills_on_tab_bar` (flag `126411::0` in `docs/mappings/452.1.0.53.64.json`; the same flag is in the 439 and 447 mappings). Piko already hooks every flag read, so the switch just makes that one flag read as false. The bar is built the way it is when Instagram has the pill off. Nothing is searched for in Instagram's code, so no fingerprint can fail on any Instagram version, and there is no new patch to select: it is part of the existing settings and flag hook.
* The flag is put in before the developer-options and recommended flags are loaded, so a flag you set by hand there still wins over this switch.
* Changed: `HookFlags.java` (new `selectedTabPillFlags()`, called first in `load()`), `Settings.java` (`remove_selected_tab_pill`, default on, restart required), `Pref.java`, `ScreenBuilder.java` (the switch, in the Navigation bar screen) and `strings.xml` (English only; other languages fall back to English until they are translated). Version set to 1.3.0 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: the changed Java was compiled against the rest of the extension sources; `HookFlags.java` and `Settings.java` give no error, and the only errors left in the project come from the Android classes that are not available here, none on a line this release changed. The rest of the project was not built here and nothing was run on a phone: whether the pill is really gone has to be tried there. If a pill is still there after a full restart (swipe the app away, or force stop it), the flag is not what draws it on your build; tell me which screen and whether the floating bar is on, and the view that draws it can be removed directly instead.

## 1.2.1

* **Fixed: the old bar frame is taken away completely.** With the floating navigation bar on, the solid strip the pill used to lie on (with the page ending right above it, so the feed, a Reel or a profile never ran down behind the pill) is gone. Until now the bar only stopped drawing Instagram's own background and took the bottom margin of the screen container (`layout_container_main`) to 0. That is the whole frame only when those two are everything that makes it; when the strip is kept by something else, it stayed. The bar now also looks at what is on the screen and takes away two more kinds of leftover, each only when it really is there:
  * **A view that only paints the strip.** A wrapper around the bar that is no taller than the bar and has a background, or a plain view beside the bar with a background that lies in the strip and has nothing shown in it, gets an empty background. Views with content and anything taller than the bar are never touched.
  * **Space kept free for the bar on some other view.** If the page still stops above the bottom edge of the bar, the page is followed from the point where it joins the bar's layout down through its single-child frames. The first one that stops short is held up either by its own bottom margin or by the bottom padding of the view around it. When that margin or padding is about the size of the bar (between 40 % of the bar and the bar plus 24 dp), it is taken to 0, so the page runs down behind the pill. Margins and paddings of any other size (the gesture inset, small gaps), and the padding of the layout that holds the bar itself, are left alone, and nothing is touched while the page already reaches the bottom.
* Everything is remembered per view and given back when the switch is turned off (backgrounds at once, margins and paddings once the bar is shown again, so a chat that hides the bar is not affected). It does not search for anything in Instagram's code, so it cannot fail a patch with a "fingerprint did not match" error.
* Written for Piko on its own: the new class looks at positions and sizes on the screen and shares no code with Prism's bar.
* Changed: new `BarFrameRemover.java`; `FloatingNavBar.java` (runs it before each frame, forgets it when the bar is replaced, gives everything back when the switch is off; a comment that said Instagram's background "stays under the pill" now says it is held, not drawn). Version set to 1.2.1 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: `BarFrameRemover.java` and `FloatingNavBar.java` were compiled against stand-ins for the Android classes with no error and no warning, and the new class was run on a simulated view tree in seven cases (margin on the container, a wrapper and a painted strip, padding on the container's parent, padding on the page's own frame, a page that already reaches the bottom, a small inset-size padding, a strip-sized view with content, and switching off while the bar is hidden); all pass. The rest of the project was not built here and nothing was run on a phone. If a strip is still there on some screen, the log lines that start with "Floating navigation bar:" (`adb logcat`) name the views that were changed, which says what else keeps it.

## 1.2.0

* **New: Floating bar size (width and height, with a live preview).** Settings > Navigation bar > Floating bar size, right under the Floating navigation bar switch. Two sliders, **Width** and **Height**, and a picture of the bottom of the screen above them that is redrawn on every step of a slider, so the pill grows and shrinks under your finger. The picture uses the same size, shade and proportions as the real bar (and follows the light, dark and AMOLED theme), with the page running behind the pill and the five tabs on it. A **Reset** button puts both back to the defaults. The sliders are dimmed while the floating bar is off.
* The sliders run the way you think of them: the right end is the widest and the tallest pill. Width is shown as a percentage of the screen (100% at the far right, down to about 70%), height in dp. The defaults are the same as in 1.1.0 (24 dp from each side, 4 dp of air above and below), so nothing changes until you move a slider.
* The pill cannot be taller than Instagram's own bar, because it is drawn inside it: the tallest setting fills the whole bar and the lowest is about 28 dp.
* The values are saved when you let go of a slider and the real bar picks them up as soon as you go back to the app (no restart). The preview takes the bar's real height once the bar has been shown in this session; before that it uses 48 dp, which is Instagram's usual bar height.
* Changed: new `FloatingNavSize.java` (limits, defaults, and the bar height the real bar reports) and `FloatingNavSizePreference.java` (the sliders and the preview); `FloatingNavBar.java` (reports its height, shares the pill's shade with the preview, and uses the shared defaults), `Settings.java` (`floating_nav_side_dp`, `floating_nav_gap_dp`, no restart needed), `Pref.java` (reads the two settings instead of the fixed 24 and 4, with a safe range), `Helper.java`, `ScreenBuilder.java` and `strings.xml` (English only; other languages fall back to English until they are translated). Version set to 1.2.0 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: `FloatingNavSize.java`, `FloatingNavBar.java` and `FloatingNavSizePreference.java` were compiled against stand-ins for the Android classes with no error (one `this-escape` warning, the same one the Focus Lock slider has). The size maths and the slider mapping were run and pass, and the preview's drawing code was run to pictures in dark and light for several sizes. The rest of the project was not built here and nothing was run on a phone: how the settings row sits in Instagram's settings screen, and how the bar looks and behaves with each size, has to be tried there.

## 1.1.0

* **New: Floating navigation bar (on/off).** Settings > Navigation bar > Floating navigation bar. When it is on, Instagram's bottom bar is replaced by a rounded floating pill that stands over the whole screen: the old bar background and the thin line above it are gone, and the page (feed, Reels, search, profile, inbox) runs all the way down behind the pill. When it is off, everything it changed is put back. It applies as soon as you go back to the app, with no restart. **Off by default.**
* How it works: nothing of Instagram's layout is replaced and nothing is searched for in its code, so no fingerprint can fail on a new Instagram version. The bar and the screen container are found by their ids; the bar's background, side padding, the line above it and the container's bottom margin are changed and remembered. If a version of Instagram does not keep the tabs inside the bar's padding, the pill takes itself off again until the app is restarted.
* The pill keeps 24 dp from each side of the screen and 4 dp of air above and below it. It follows the theme (light, dark, AMOLED) from the bar's own background.
* Taps on the empty parts of the bar are taken by the bar, so they never reach the Reel or post that now lies under it.
* Ported from Prism's floating navigation bar. Prism's width and height sliders are not included.
* Changed: new `FloatingNavBar.java`; `Settings.java`, `Pref.java`, `Constants.java` (starts it at app start), `ScreenBuilder.java` (the switch; the Navigation bar screen now always shows) and `strings.xml`. Version set to 1.1.0 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`.
* Checked: `FloatingNavBar.java` was compiled against stand-ins for the Android classes and gives no error or warning. The rest of the project was not built here and the bar was not run on a phone: how it looks and behaves has to be tried there.

## 1.0.0

* First Piko release in the Prism project format. Same patches as Piko dev 3.11.0-dev.5, no patch code changed.
* Packaging now matches Prism: the project folder is `piko-patches`, `gradle.properties` carries the Gradle memory settings for CI builds, `patches-bundle.json` is the short form, and `VERSIONING.md` and a short `README.md` were added.
* Version set to 1.0.0 in `gradle.properties`, `patches-bundle.json`, `patches-list.json`, `VERSIONING.md` and `README.md`. The archive is named `piko v1.0.0.zip`.

## Earlier history (upstream Piko)

## [3.11.0-dev.5](https://github.com/crimera/piko/compare/v3.11.0-dev.4...v3.11.0-dev.5) (2026-11-07)

### 🐛 Bug Fixes

* **Instagram - Disable analytics:** App data bloats when it is enabled ([#2243](https://github.com/crimera/piko/issues/2243)) ([c4d73df](https://github.com/crimera/piko/commit/c4d73df17dd50b64850e186aa2b1d47ad49d1a31))
* **Instagram:** Change the video placeholder icon ([40f1531](https://github.com/crimera/piko/commit/40f1531a5230879580b1158eaef850b7f4e1965b))
* **Instagram:** Correct saved video labels and copied media links ([6040b5b](https://github.com/crimera/piko/commit/6040b5b0bbcc0d7eddee29c864ea97954f2ffba9))
* **Instagram:** Load profile pictures immediately and refresh expired URLs ([ca28e82](https://github.com/crimera/piko/commit/ca28e82db79d8520fd250f923e1e9551f872bdd8))
* **Instagram:** Reuse localized save button labels ([094dea7](https://github.com/crimera/piko/commit/094dea7c01576d5821738d4afae0b2b49d8f764b))

### ✨ New Features

* **Instagram:** Add audio and video call buttons to chat action settings ([bc583e5](https://github.com/crimera/piko/commit/bc583e5d4353d0aa5b2099eff902eb29ea88a9f0))
* **Instagram:** Add bulk and selective story downloads ([2480ff3](https://github.com/crimera/piko/commit/2480ff3d326b5e424635002beaebb229083a476e))
* **Instagram:** Add long-press downloads ([6a97962](https://github.com/crimera/piko/commit/6a979620d83e419109f9170a557ad37ab80cce65))
* **Instagram:** Hide like buttons and counts ([e2bfdbd](https://github.com/crimera/piko/commit/e2bfdbd40dd9a3a4a21cd26af1e955f2468d96ab))
* **Instagram:** Preserve Reels playback position when scrolling ([0e728b5](https://github.com/crimera/piko/commit/0e728b57efc559b7614cd0fccf23165e188d3c95))
* **Instagram:** Refactor "Hide save buttons" patch with per-surface options ([#2256](https://github.com/crimera/piko/issues/2256)) ([803eeef](https://github.com/crimera/piko/commit/803eeefaae4499b5a4da3874c3e0e2dae115f6dd))

### 🔧 Improvements

* **Instagram:** Open saved media with compatible apps ([fd5e2d1](https://github.com/crimera/piko/commit/fd5e2d1d4462cba0a3eadc955c63d7a387174d8a))
* **Instagram:** Respect download settings when saving Instants ([ebb751b](https://github.com/crimera/piko/commit/ebb751b348b6dc83191edf72c9dba52c74984b8f))

## [3.11.0-dev.4](https://github.com/crimera/piko/compare/v3.11.0-dev.3...v3.11.0-dev.4) (2026-11-01)

### 🐛 Bug Fixes

* **Instagram:** Allow Clone to run without Add settings ([de8011b](https://github.com/crimera/piko/commit/de8011b0fa66067b24738c72fbd53b50905d63c2))
* **Instagram:** Replace theme overlays atomically to avoid SIGBUS ([#2213](https://github.com/crimera/piko/issues/2213)) ([2e45a89](https://github.com/crimera/piko/commit/2e45a8964732276652d4463f1c73dc1a896f996b)), closes [#2211](https://github.com/crimera/piko/issues/2211)
* **Instagram:** Resolve deleted message usernames and improve the UI ([c998eaf](https://github.com/crimera/piko/commit/c998eaf5514f066673832e7b087db946674bbf05))
* **Instagram:** Resume stories after closing custom dialogs ([a02dd7a](https://github.com/crimera/piko/commit/a02dd7a20c6d397ca297727cbf971be27295beae))
* **Instagram:** Save video covers at their real size ([#2226](https://github.com/crimera/piko/issues/2226)) ([f3d88b5](https://github.com/crimera/piko/commit/f3d88b5a964d42d8386bfb5fd081d3c91c8882c0))

### ✨ New Features

* **Instagram:** Add Disable disappearing messages swipe patch ([7bcaa56](https://github.com/crimera/piko/commit/7bcaa568fb79a0dc5bfcb2b0e2526fc5582f0885))
* **Instagram:** Add selective carousel downloads ([8562271](https://github.com/crimera/piko/commit/8562271f90c0c2fdf1bdbfcf357ffe6caa9b8523))
* **Instagram:** Hide share buttons on stories ([c955103](https://github.com/crimera/piko/commit/c955103d11b307872a7fa131cda8002b084ed82e))
* **Instagram:** Hide story comments when comments are disabled ([46978fa](https://github.com/crimera/piko/commit/46978fa9fbfb62bc5dee5244aac04751480bc056))
* **Instagram:** Inline download button on reels ([f24355e](https://github.com/crimera/piko/commit/f24355e68012ae74d423f0c6465455d4b275d07a))
* **Instagram:** Inline download button on stories ([d7846a6](https://github.com/crimera/piko/commit/d7846a6b8ad838b3a853a3285f591dd799c8180c))
* **Instagram:** Open downloaded media by tapping its notification ([#2194](https://github.com/crimera/piko/issues/2194)) ([0e70d77](https://github.com/crimera/piko/commit/0e70d771aa54c346bbcaf9caa434168467b1009c))

### 🔧 Improvements

* **Instagram:** Adjust checkbox and message spacing in selection mode ([5908b40](https://github.com/crimera/piko/commit/5908b408c0094fe734225d797b78a21948f31396))
* **Instagram:** Consolidate image resolution choices ([f92d43f](https://github.com/crimera/piko/commit/f92d43fde528ead0753281e61cd0c082aefd189d))
* **Instagram:** Consolidate patch information entries ([719cb0b](https://github.com/crimera/piko/commit/719cb0be85fab0b9bea4d2c70aeb6eafe6ad624e))
* **Instagram:** Consolidate video resolution choices ([61a2281](https://github.com/crimera/piko/commit/61a22819b9ae512a8d8010fef50f1caedfcc1c39))
* **Instagram:** Group download button visibility settings ([bbdc48e](https://github.com/crimera/piko/commit/bbdc48e55ce75e2dad44c17af601e40fc8053a11))
* **Instagram:** Improve profile picture dialog theming and cleanup ([7aa62ac](https://github.com/crimera/piko/commit/7aa62accae2272009077bc3915a4b05b358dd47f))
* **Instagram:** Improve saved instants selection and search UI ([5473bed](https://github.com/crimera/piko/commit/5473bed2062caee7e5fe429a6880ecc1fd63ab4c))
* **Instagram:** Load original post images and keep thumbnails small ([#2219](https://github.com/crimera/piko/issues/2219)) ([2e7079b](https://github.com/crimera/piko/commit/2e7079b191a1d65b1a399a65ea4caf122a3a8e23))
* **Instagram:** Save higher-resolution additional cover images ([5932ba2](https://github.com/crimera/piko/commit/5932ba2dd1544d85889d6ff2bf669cc68454bd5b))
* **Instagram:** Save higher-resolution covers from video frames ([ea6e157](https://github.com/crimera/piko/commit/ea6e1574cc4d7ff5d2aae03de18c396fca62e7ba))
* **Instagram:** Select the highest-resolution media for downloads ([0dc269b](https://github.com/crimera/piko/commit/0dc269b267fc65c106497c341c753b6e9febafe4))

## [3.11.0-dev.3](https://github.com/crimera/piko/compare/v3.11.0-dev.2...v3.11.0-dev.3) (2026-10-25)

### 🐛 Bug Fixes

* **Instagram:** Fix hide feed posts with Patcher 2.0.1 ([abfc1c7](https://github.com/crimera/piko/commit/abfc1c7c1310c40415729ef086feae818e8f4ccb))

### 🔧 Improvements

* **Instagram:** Respect settings dependencies ([a9f4ad0](https://github.com/crimera/piko/commit/a9f4ad065d2b5cb007233e6a9bf081a81de251b1))
* **Instagram:** Restore recommended patches and complete patch status reporting ([eb8b4db](https://github.com/crimera/piko/commit/eb8b4db0e1c6a6f0c5e18301859622fe14e0f15c))

## [3.11.0-dev.2](https://github.com/crimera/piko/compare/v3.11.0-dev.1...v3.11.0-dev.2) (2026-10-25)

### 🐛 Bug Fixes

* **Instagram:** Align recommended flag labels with their toggle states ([b49c06b](https://github.com/crimera/piko/commit/b49c06be84e6347bd3cc447f07f22c6e9b8d67ce))
* **Instagram:** Correct restart policies and clear disabled media captions ([aceb512](https://github.com/crimera/piko/commit/aceb5127b7f8cd9e6c61cf95cb38dfdc604e298a))
* **Instagram:** Keep home tray story system bars pure black ([20529a8](https://github.com/crimera/piko/commit/20529a8b4bd17211c57f7accefdc2c028bce4ab9))
* **Instagram:** Keep story backgrounds pure black across themes ([707c1a9](https://github.com/crimera/piko/commit/707c1a983b7ad41aa1009e89b46be015ce0fde02))
* **Instagram:** Localize story timestamps and remaining time ([e504c4d](https://github.com/crimera/piko/commit/e504c4d3475fea8b962e8355d1f4974c742bada5))
* **Instagram:** Preserve settings scroll position after theme changes ([fd6ec7e](https://github.com/crimera/piko/commit/fd6ec7e119b6a04da59fa1a84343677313b44502))
* **Instagram:** Preserve settings state across modal recreation ([0991518](https://github.com/crimera/piko/commit/099151895acba64fa42b08fc933ad34d7f9d5189))
* **Instagram:** Restore behavior after mount install changes ([0bc1c9f](https://github.com/crimera/piko/commit/0bc1c9fc019a8d07daddb8d458c8eac65f347d71))
* **Instagram:** Restore saved Instants empty-state layout ([52e56db](https://github.com/crimera/piko/commit/52e56dbb79dc501b8991c09beb3856728a2fcbc6))

### ✨ New Features

* **Instagram:** Add comment author username copying ([50a1427](https://github.com/crimera/piko/commit/50a142734c53a72cbb8d85a3576063fe90a16b37))
* **Instagram:** Add flags to disable selected Plus features ([4043e90](https://github.com/crimera/piko/commit/4043e901cdb701ea9abadae13a5c86ffae421670))
* **Instagram:** Add hide feed posts patch ([3578c4b](https://github.com/crimera/piko/commit/3578c4bfbc6ad4231960ab7b02f70b48e56136e6))
* **Instagram:** Add mark as read after reply option ([c043bbc](https://github.com/crimera/piko/commit/c043bbcd61c12d7611c8caa94b9d4e42b3686e51))
* **Instagram:** Add option to convert DASH audio to AAC-LC ([#2171](https://github.com/crimera/piko/issues/2171)) ([ebf7301](https://github.com/crimera/piko/commit/ebf7301ea5d4a63ccaaa47361d07713a783d0d4f))
* **Instagram:** Add option to hide story follow button ([de269b3](https://github.com/crimera/piko/commit/de269b3428090c9608d5273cd3b1b462cb5eba17))
* **Instagram:** Add recommended flags to hide Meta AI ([0c8eb70](https://github.com/crimera/piko/commit/0c8eb7077f6b8aa5283ee540bc896e0bb86e125b))
* **Instagram:** Add recommended flags to hide Plus upsells ([492adf5](https://github.com/crimera/piko/commit/492adf545fad3d4fee8598739ac13b1380f86426))
* **Instagram:** Add support for mount installation ([#2169](https://github.com/crimera/piko/issues/2169)) ([b628b64](https://github.com/crimera/piko/commit/b628b649ee8a43917a9557c8b6bda750428ccfb1))
* **Instagram:** Queue Download All requests by post ([6fac70b](https://github.com/crimera/piko/commit/6fac70bb8f9fdf6cb3aae83dcad076de8c5df3ff))

### 🔧 Improvements

* **Instagram:** Clarify file picker unavailable errors ([1e9ffbf](https://github.com/crimera/piko/commit/1e9ffbf4529c040b9cc01e57ba14a9f82c7e5ae1))
* **Instagram:** Consolidate telemetry patches ([6363dd8](https://github.com/crimera/piko/commit/6363dd8aa9590aa841fbc57e8cbed7949249b1e1))
* **Instagram:** Move Plus benefits below empty bottom space setting ([2d09e37](https://github.com/crimera/piko/commit/2d09e373fb8c58e696e55ccfe2904f398cc3f8d8))
* **Instagram:** Refine restart confirmation and require explicit restart policies ([1c39f36](https://github.com/crimera/piko/commit/1c39f369e077e6fc48fd35165f7cbe4ce834f53e))
* **Instagram:** Refine settings row spacing ([8c0be72](https://github.com/crimera/piko/commit/8c0be72f11a9ca7cf508de16c18b8fcaa6c014b7))
* **Instagram:** Use the native ads icon for ad settings ([4385aee](https://github.com/crimera/piko/commit/4385aee4121d13431e5fbc7e7a91b1b3588f8401))

## [3.11.0-dev.1](https://github.com/crimera/piko/compare/v3.10.0...v3.11.0-dev.1) (2026-10-22)

### 🐛 Bug Fixes

* **ci:** Normalize Gradle Windows wrapper line endings ([571b62c](https://github.com/crimera/piko/commit/571b62c209a97d50ca181341e87040b42dffcac7))
* **Instagram:** Add `obrf`, `vrfl`, `rpxt` to link sanitization list ([#2118](https://github.com/crimera/piko/issues/2118)) ([e76e726](https://github.com/crimera/piko/commit/e76e726af81bb8a52172a7b3ac3b0012257cd041))
* **Instagram:** Sanitize `cplk` tracking parameter ([#2117](https://github.com/crimera/piko/issues/2117)) ([404ad37](https://github.com/crimera/piko/commit/404ad3748f5ee899bca89a2eec587fc9e73ca61d))
* **Instagram:** Sanitize `mdxt` tracking parameter ([#2113](https://github.com/crimera/piko/issues/2113)) ([537d5bf](https://github.com/crimera/piko/commit/537d5bf988a6253abe2a735a3f946567ccda04a0))

### ✨ New Features

* **Instagram:** Add a setting to hide the hidden requests button ([#2126](https://github.com/crimera/piko/issues/2126)) ([e624f25](https://github.com/crimera/piko/commit/e624f25879ab2f3590a75a34160f944c1731a70f)), closes [#2123](https://github.com/crimera/piko/issues/2123)
* **Instagram:** Add better quality video downloads ([#2133](https://github.com/crimera/piko/issues/2133)) ([eb10d6a](https://github.com/crimera/piko/commit/eb10d6ac0df35106dcac40f2e04e889799fc5da4))
* **Instagram:** Add search Piko settings ([e0d9935](https://github.com/crimera/piko/commit/e0d9935263b78443de83c28617b39d829bf1bb45))
* **Instagram:** Disable background daemons, sync services, and telemetry ([#2145](https://github.com/crimera/piko/issues/2145)) ([0f44c77](https://github.com/crimera/piko/commit/0f44c7795fd0a0333ada8355b95e6043a8416be7))
* **Instagram:** Download photo stories with music at upload size ([#2159](https://github.com/crimera/piko/issues/2159)) ([15696ae](https://github.com/crimera/piko/commit/15696ae3995e3a3af0ccd001ad01dd006eaff454))
* **Instagram:** Hide chats in a private inbox ([#2108](https://github.com/crimera/piko/issues/2108)) ([39155fd](https://github.com/crimera/piko/commit/39155fd4950ae2cf48c6f1412f4a9413c89cce77))
* **Instagram:** Show how ephemeral media was received ([#2100](https://github.com/crimera/piko/issues/2100)) ([460267b](https://github.com/crimera/piko/commit/460267bd58fd0624e5f78e0ec57cbd0bc090d3e1))

### 🚀 Updated App Support

* **Instagram:** Add support for 452.1.0.53.64 ([761d795](https://github.com/crimera/piko/commit/761d79599d3114c06bf489a7e4368a43f3f608fb))

## [3.10.0](https://github.com/crimera/piko/compare/v3.9.0...v3.10.0) (2026-10-10)

### 🐛 Bug Fixes

* **ci:** Import Crowdin translations onto the latest dev ([#1890](https://github.com/crimera/piko/issues/1890)) ([385a8d1](https://github.com/crimera/piko/commit/385a8d1852434f0529d4a017f723ccc5cae4e0b8))
* **github:** use existing enhancement label and add missing twitter label ([6337845](https://github.com/crimera/piko/commit/63378453c020ce89f490e802356418816be6820a))
* **Instagram:** add auto-scroll persistence flag to recommended flags ([#1957](https://github.com/crimera/piko/issues/1957)) ([096ea87](https://github.com/crimera/piko/commit/096ea8738d2edae3bf1d47aa8404822e6d4ccc5d)), closes [#1746](https://github.com/crimera/piko/issues/1746)
* **Instagram:** Add missing entity dependencies ([#1833](https://github.com/crimera/piko/issues/1833)) ([a19b255](https://github.com/crimera/piko/commit/a19b255eccd3b2fed5474bc481ab7f3ae6640be9))
* **Instagram:** Align Instants settings and saved viewer styling ([#2017](https://github.com/crimera/piko/issues/2017)) ([a0a3360](https://github.com/crimera/piko/commit/a0a33601aa0c6cc99e990ea0f7f8dfd31c43640d))
* **Instagram:** Allow screenshots in protected DM windows ([45fee55](https://github.com/crimera/piko/commit/45fee5532102b27aa8a4e95ff5c00ac3cb75fd75))
* **Instagram:** Correct patch status mappings ([bf4a28c](https://github.com/crimera/piko/commit/bf4a28ca5387efd2c51453ef368d686cbf643f8b))
* **Instagram:** Correct the names of the HDR and auto-scroll recommended flags ([#2078](https://github.com/crimera/piko/issues/2078)) ([8917d71](https://github.com/crimera/piko/commit/8917d71e36356ed56e68154b7cf272cfa4dcf0c5))
* **Instagram:** Fill menu highlights above dialog buttons ([#2016](https://github.com/crimera/piko/issues/2016)) ([a326e42](https://github.com/crimera/piko/commit/a326e42fd87be1540aad23f7c8aab0e96dbb263d))
* **Instagram:** Find the expire field of ephemeral media by its own key ([#2046](https://github.com/crimera/piko/issues/2046)) ([ff2c809](https://github.com/crimera/piko/commit/ff2c809f1a89a5b9be8713a6fd987299d9397c63))
* **Instagram:** Fix deleted message handling ([4254162](https://github.com/crimera/piko/commit/425416276c0ae2df7a6cf53fab9b37708735f8be))
* **Instagram:** Hide ads in the Following feed ([7914a26](https://github.com/crimera/piko/commit/7914a2634e39738dd11318ea71491a5bf11493f4))
* **Instagram:** Hide non-follower badges for unknown friendship status ([f385660](https://github.com/crimera/piko/commit/f3856607144c2b2b825aec46f7cd3a5ee0490a8f))
* **Instagram:** Hide the reshare button in the home feed ([ae38467](https://github.com/crimera/piko/commit/ae38467035fbbeeba8e03824535f927cc635adea))
* **Instagram:** invoke reflected methods on the correct receiver ([#1960](https://github.com/crimera/piko/issues/1960)) ([e4a9464](https://github.com/crimera/piko/commit/e4a9464792f8990a003a9289fe75243f6a54fa48))
* **Instagram:** Isolate story filters and refresh highlight visibility ([2946e7e](https://github.com/crimera/piko/commit/2946e7ecabedd5da21075e56e9f10824cd1c94d3))
* **Instagram:** Keep settings switch animations consistent after shortcut launch ([#1883](https://github.com/crimera/piko/issues/1883)) ([6ffb046](https://github.com/crimera/piko/commit/6ffb046f68cf0d82c36d9c9837d695d259838331))
* **Instagram:** Move the story seen button to the bottom action row ([0d7fba0](https://github.com/crimera/piko/commit/0d7fba0feeb17c430af4292176be47036593bda3))
* **Instagram:** Preserve ephemeral media after refreshing chats ([d9ab7c7](https://github.com/crimera/piko/commit/d9ab7c7d3327481ea07e8a63f302590158c9fae5))
* **Instagram:** Preserve friendship status when metadata is missing ([6eeb0f0](https://github.com/crimera/piko/commit/6eeb0f08db63e99cfb102e1ddb653945a10e1780))
* **Instagram:** Preserve the startup tab while editing navigation ([#1880](https://github.com/crimera/piko/issues/1880)) ([cb1241f](https://github.com/crimera/piko/commit/cb1241f236801e8b5d58722e7db0b6d12680d08d))
* **Instagram:** Preserve unobserved theme state ([#1872](https://github.com/crimera/piko/issues/1872)) ([cf7cd66](https://github.com/crimera/piko/commit/cf7cd668dfe554a3a2de016524c88f92e7fb6303))
* **Instagram:** Prevent newlines in text preferences ([#1811](https://github.com/crimera/piko/issues/1811)) ([2cb1faa](https://github.com/crimera/piko/commit/2cb1faa3e18a7e99a5271957803cc5e6c278692e))
* **Instagram:** Recover settings after crash ([#1822](https://github.com/crimera/piko/issues/1822)) ([8391a5b](https://github.com/crimera/piko/commit/8391a5b6817289307eb2fef96837c2055eebea99))
* **Instagram:** Refine Focus Lock highlight and slider spacing ([#1982](https://github.com/crimera/piko/issues/1982)) ([c5b8ca5](https://github.com/crimera/piko/commit/c5b8ca5855b04706d86b20de89752780c36a7aa6))
* **Instagram:** Refresh profile friendship status and hide unknown states ([2418d65](https://github.com/crimera/piko/commit/2418d657c7cfb1db752980c2cc10b74bd3af4641))
* **Instagram:** remove forced HDR brightness on photos and Reels ([#1955](https://github.com/crimera/piko/issues/1955)) ([0084136](https://github.com/crimera/piko/commit/0084136b5ded2210e03d14dceabb09013be1cb3a)), closes [#1817](https://github.com/crimera/piko/issues/1817)
* **Instagram:** Remove recommended flags unavailable in 447 ([46e9074](https://github.com/crimera/piko/commit/46e90748db5825c916c9ac8cefb8d4ba50936d6c))
* **Instagram:** Restore the activity context for like animation previews ([#2014](https://github.com/crimera/piko/issues/2014)) ([1f08d91](https://github.com/crimera/piko/commit/1f08d91edf63d2a31ce49d52a5af3acf6ed04c98))
* **Instagram:** Sanitize shared links before changing domains ([b1d0eb4](https://github.com/crimera/piko/commit/b1d0eb481e748a33110a5f5fd51ade221fe1ecef))
* **Instagram:** Skip event dispatch when analytics are disabled ([#1877](https://github.com/crimera/piko/issues/1877)) ([7a44c6d](https://github.com/crimera/piko/commit/7a44c6d8306a1c2ca32502b3497308af8e1677b0))
* **Instagram:** Skip the remind me notification action when the link has no x ([#2101](https://github.com/crimera/piko/issues/2101)) ([c4a6479](https://github.com/crimera/piko/commit/c4a64794d5d0f8a30327a38986ff84f5b8b4cdf4))
* **Instagram:** Stop Open links externally from crashing on 447 ([#2047](https://github.com/crimera/piko/issues/2047)) ([4c15083](https://github.com/crimera/piko/commit/4c15083cf3a1b65f874c0bc59f68b51055bdaff2))
* **Instagram:** Sync ghost mode icons when settings change ([#1875](https://github.com/crimera/piko/issues/1875)) ([dc12da8](https://github.com/crimera/piko/commit/dc12da8f03703fb6fa50ce11d009e32754c0761b))
* **Instagram:** Use an adaptive settings shortcut icon ([454f283](https://github.com/crimera/piko/commit/454f283baf3f7d444cb7d8b13eb3728e6a081a36))
* Revert "fix(twitter - `Bring Back Twitter`): support to new versions" ([df9b407](https://github.com/crimera/piko/commit/df9b4079d33aea17dcda5e4ebacd7bc4307421b9))
* **twitter - `Bring Back Twitter`:** support to new versions ([ff97563](https://github.com/crimera/piko/commit/ff975634c0e30b87fbb06cdcae556ff00f351a7a))
* **Twitter - Show changelogs:** Error message is shown with changelog dialog ([e1238c3](https://github.com/crimera/piko/commit/e1238c3ffd38b1573a11a411000080f825f79583))
* **Twitter:** Apply dynamic color to Dim and Lights out themes ([#2027](https://github.com/crimera/piko/issues/2027)) ([5842cb7](https://github.com/crimera/piko/commit/5842cb7b3589bba0669cc78a34cb3c27f1749a2d)), closes [#15202](https://github.com/crimera/piko/issues/15202) [#bf15202](https://github.com/crimera/piko/issues/bf15202)
* **Twitter:** avoid copying editor spans in custom font hook ([c6deb8d](https://github.com/crimera/piko/commit/c6deb8daa5cd1f41a3a368802cf87c6f5dbf2749))
* **Twitter:** guard null ShareTarget in modern share sheet link hook ([5066035](https://github.com/crimera/piko/commit/5066035bc43b7c27f7e13248f0edec5afa7be85a))
* **Twitter:** Preserve links when applying custom fonts ([#1889](https://github.com/crimera/piko/issues/1889)) ([f5d1db8](https://github.com/crimera/piko/commit/f5d1db88cb2e1782436604168903347b43d3743c))
* **Twitter:** restore relationship actions in user lists ([854f5e2](https://github.com/crimera/piko/commit/854f5e26831c997e376a7b68094a7fbde89fc790))
* **Twitter:** Restore timeline position on startup ([ae231c5](https://github.com/crimera/piko/commit/ae231c596bf9b7d3b1f2a1cff9ef5e74151cd6b9))

### ✨ New Features

* **Instagram:** Add `Focus Lock` patch ([#1928](https://github.com/crimera/piko/issues/1928)) ([2b6b5ac](https://github.com/crimera/piko/commit/2b6b5ac21cb199f40a4e6dfc0dc76c36992fe31f))
* **Instagram:** Add an option to enable inline download button on feed and profile posts ([#1997](https://github.com/crimera/piko/issues/1997)) ([a074bb9](https://github.com/crimera/piko/commit/a074bb97485f79dcd239675be44403e8b3dbbf80))
* **Instagram:** add custom font support ([#1920](https://github.com/crimera/piko/issues/1920)) ([065bb95](https://github.com/crimera/piko/commit/065bb95ad626b05c1d11e7ba64698e4e313ce81b))
* **Instagram:** Add Hide save buttons patch ([ac89a04](https://github.com/crimera/piko/commit/ac89a04d6f75dbc5e5c80dc95a80bec539e8f167))
* **Instagram:** Add Hide share button patch ([15b8856](https://github.com/crimera/piko/commit/15b88567abb2433ca930da264709f5c2b37f7037))
* **Instagram:** Add Inbox lock to ask for your biometrics before messages ([#2020](https://github.com/crimera/piko/issues/2020)) ([d2c5f0a](https://github.com/crimera/piko/commit/d2c5f0a6b843a4aabf08bf7aeb2c25b51e62e9e7)), closes [#2018](https://github.com/crimera/piko/issues/2018)
* **Instagram:** Add recommended flags for the Reels seekbar ([e558f88](https://github.com/crimera/piko/commit/e558f8848f983802a9063c45996b3275ccdb0b0a))
* **Instagram:** Add startup tab selection ([#1869](https://github.com/crimera/piko/issues/1869)) ([d284f62](https://github.com/crimera/piko/commit/d284f629056344bec9351fe86afd73f07ef25818))
* **Instagram:** Add Story category ([#1948](https://github.com/crimera/piko/issues/1948)) ([ec55052](https://github.com/crimera/piko/commit/ec55052596689de7996ed8fb78ea907977158269))
* **Instagram:** Add story seen button ([#1884](https://github.com/crimera/piko/issues/1884)) ([c39e122](https://github.com/crimera/piko/commit/c39e122dbce23d9d603bc73010e0aeaccdfe88bd))
* **Instagram:** Add visibility controls for create and notification buttons ([#1870](https://github.com/crimera/piko/issues/1870)) ([a1c0866](https://github.com/crimera/piko/commit/a1c0866824ef72cd40b5d03d3ec2a46bf5f8cdaf))
* **Instagram:** Customize download filenames ([#1923](https://github.com/crimera/piko/issues/1923)) ([8507022](https://github.com/crimera/piko/commit/850702242069fab700d6382ec4287d95f4e1f722))
* **Instagram:** Customize navigation bar ([#1867](https://github.com/crimera/piko/issues/1867)) ([bbd335c](https://github.com/crimera/piko/commit/bbd335ca7764ec99c3c9936e0ffd71723699e627))
* **Instagram:** Embed metadata in downloaded videos ([#1828](https://github.com/crimera/piko/issues/1828)) ([9493252](https://github.com/crimera/piko/commit/949325266af15c51477101be81ad8692bb439557))
* **Instagram:** Hide Reels follow button ([#1911](https://github.com/crimera/piko/issues/1911)) ([f180a7b](https://github.com/crimera/piko/commit/f180a7b4c628f1f23d9e78fc8ed3715e652b0a03))
* **Instagram:** Integrate `Disable onboarding permission prompts` patch into `Disable analytics` ([#1771](https://github.com/crimera/piko/issues/1771)) ([a7974cd](https://github.com/crimera/piko/commit/a7974cd4c66dff557c2905ea92ad73741b46fa44))
* **Instagram:** Lock any distraction free setting with Focus Lock ([#1953](https://github.com/crimera/piko/issues/1953)) ([97ea429](https://github.com/crimera/piko/commit/97ea42941f25a68e8fd1080852a576b0b80cd134))
* **Instagram:** Restore classic search recents (up to 25) ([#1741](https://github.com/crimera/piko/issues/1741)) ([bb98bcb](https://github.com/crimera/piko/commit/bb98bcb219ca0a30ee672db4361dc70abbfe06df))
* **Instagram:** Save and view received Instants ([#1538](https://github.com/crimera/piko/issues/1538)) ([40e1327](https://github.com/crimera/piko/commit/40e1327b265565e19074bf699091dcde77f581dc))
* **Instagram:** Show non-followers in the Following list ([#1978](https://github.com/crimera/piko/issues/1978)) ([f2395c9](https://github.com/crimera/piko/commit/f2395c9c84ccc989771701d6b27bd556c949274c)), closes [#1899](https://github.com/crimera/piko/issues/1899)
* **Instagram:** Update the Direct icon in settings and in the navigation customization window. ([#1888](https://github.com/crimera/piko/issues/1888)) ([7e50716](https://github.com/crimera/piko/commit/7e507162e87e8ac586216fa7562add6bac355d28))
* **Twitter:** Add bulk feature flag selection and validation ([#1846](https://github.com/crimera/piko/issues/1846)) ([7b92ac8](https://github.com/crimera/piko/commit/7b92ac8626b2ff907769503ae85b688fd2471c36))

### 🚀 Updated App Support

* **Instagram:** Add support for 447.0.0.55.81 ([3e15b92](https://github.com/crimera/piko/commit/3e15b928c85449e21b3e6a34a2ac419d272885bb))

### 🔧 Improvements

* **Instagram:** Add a close button to resolution dialogs ([9383ab3](https://github.com/crimera/piko/commit/9383ab3ce00462d3f3ce174ef51bba6699fee137))
* **Instagram:** Add feedback to the unlock button ([44fcefb](https://github.com/crimera/piko/commit/44fcefb539dce3640fc2e88eb20c72ef9ccec101))
* **Instagram:** Add flags to Suggested users in search ([4dbc376](https://github.com/crimera/piko/commit/4dbc3764bf9bda3c10546d8e112328a4310cf48a))
* **Instagram:** Add random like animations and previews ([#1980](https://github.com/crimera/piko/issues/1980)) ([f544987](https://github.com/crimera/piko/commit/f54498748f8ddf9051b443c396ce46235cd047e0))
* **Instagram:** Always apply link and build expiration fixes ([476cf62](https://github.com/crimera/piko/commit/476cf6220c4b59b85b812829e77f9135f3c73cdb))
* **Instagram:** Clarify settings row highlight behavior ([#1989](https://github.com/crimera/piko/issues/1989)) ([40e1086](https://github.com/crimera/piko/commit/40e108645d273402c0964e6b83b9f32ae9127cf5))
* **Instagram:** fix N+1 query when opening Deleted Messages ([#1965](https://github.com/crimera/piko/issues/1965)) ([bdc8d10](https://github.com/crimera/piko/commit/bdc8d10fb11c3809fd9a87aed2ab1269c2ce40ca))
* **Instagram:** Hide comment buttons and counts ([2cbd8b2](https://github.com/crimera/piko/commit/2cbd8b268b8ba21c5321b58be861c1402b46e6d8))
* **Instagram:** Hide suggested profiles ([#1917](https://github.com/crimera/piko/issues/1917)) ([c6ea8c4](https://github.com/crimera/piko/commit/c6ea8c4013cb22fa52f661acb7a83d88b6e54a18))
* **Instagram:** Improve settings category names and icons ([#1876](https://github.com/crimera/piko/issues/1876)) ([4cb58f7](https://github.com/crimera/piko/commit/4cb58f73419cbbf7cebc51ef9d66387bf515d92b))
* **Instagram:** Match Inbox lock styling and reorder DM settings ([8dbcb52](https://github.com/crimera/piko/commit/8dbcb52bdb0bf34a74d3c6bf1be578fab27e517e))
* **Instagram:** Organization options ([#2073](https://github.com/crimera/piko/issues/2073)) ([e3039f9](https://github.com/crimera/piko/commit/e3039f97cd247659d9f853146e2393f57ce662c1))
* **Instagram:** Refine anonymous DM handling ([#1781](https://github.com/crimera/piko/issues/1781)) ([679b62b](https://github.com/crimera/piko/commit/679b62bb589b49ccabd94ec0b245960c31136f64))
* **Instagram:** Refine deleted message handling ([#1775](https://github.com/crimera/piko/issues/1775)) ([f6360dc](https://github.com/crimera/piko/commit/f6360dc0e767d613bda1abcf4dcef476fd5562a8))
* **Instagram:** Refine profile button styles and spacing ([#1990](https://github.com/crimera/piko/issues/1990)) ([e2dafdc](https://github.com/crimera/piko/commit/e2dafdc02367cd66def5b5096aae587ed567c327))
* **Instagram:** Reorder DM settings ([40f8c14](https://github.com/crimera/piko/commit/40f8c148a21f4963800c281c961e668e3fbcb6d2))
* **Instagram:** Replace the Ghost category icon ([#1878](https://github.com/crimera/piko/issues/1878)) ([eac2651](https://github.com/crimera/piko/commit/eac26515554cea5f6f8ae42cda1d087d06a94233))
* **Instagram:** Simplify option dialogs and add close buttons ([#1954](https://github.com/crimera/piko/issues/1954)) ([1560f8e](https://github.com/crimera/piko/commit/1560f8e1024bf613276589d2897574d1c82856f3))
* **Instagram:** Use avatar badges in follow lists ([#1986](https://github.com/crimera/piko/issues/1986)) ([51e334c](https://github.com/crimera/piko/commit/51e334cd6d430c445cb59944729fe20695acf97e))
* **Instagram:** Use settings in export and import labels ([#1847](https://github.com/crimera/piko/issues/1847)) ([de6d165](https://github.com/crimera/piko/commit/de6d16597393f10fa6a37b8761b45c08ccffc469))
* **Instagram:** Use the native story mentions dialog ([#2030](https://github.com/crimera/piko/issues/2030)) ([14faf0a](https://github.com/crimera/piko/commit/14faf0a00a46bd46361f0d6153375f2451bf20f7))
* **Twitter:** fail with a clear error in share menu button hook ([#1958](https://github.com/crimera/piko/issues/1958)) ([9a2ac39](https://github.com/crimera/piko/commit/9a2ac39cde6e61042c9fd270ad872a8f77c7d755))
* **utils:** fail with a clear error when string sentinel/index lookups miss ([#1959](https://github.com/crimera/piko/issues/1959)) ([22cb283](https://github.com/crimera/piko/commit/22cb283751a467aa241edb7de368350f1f24095e))

## [3.10.0-dev.14](https://github.com/crimera/piko/compare/v3.10.0-dev.13...v3.10.0-dev.14) (2026-10-10)

### 🐛 Bug Fixes

* **Instagram:** Skip the remind me notification action when the link has no x ([#2101](https://github.com/crimera/piko/issues/2101)) ([c4a6479](https://github.com/crimera/piko/commit/c4a64794d5d0f8a30327a38986ff84f5b8b4cdf4))

### 🔧 Improvements

* **Instagram:** Always apply link and build expiration fixes ([476cf62](https://github.com/crimera/piko/commit/476cf6220c4b59b85b812829e77f9135f3c73cdb))

## [3.10.0-dev.13](https://github.com/crimera/piko/compare/v3.10.0-dev.12...v3.10.0-dev.13) (2026-10-09)

### 🐛 Bug Fixes

* **Instagram:** Fix deleted message handling ([4254162](https://github.com/crimera/piko/commit/425416276c0ae2df7a6cf53fab9b37708735f8be))
* **Instagram:** Preserve friendship status when metadata is missing ([6eeb0f0](https://github.com/crimera/piko/commit/6eeb0f08db63e99cfb102e1ddb653945a10e1780))
* **Instagram:** Sanitize shared links before changing domains ([b1d0eb4](https://github.com/crimera/piko/commit/b1d0eb481e748a33110a5f5fd51ade221fe1ecef))
* **Instagram:** Use an adaptive settings shortcut icon ([454f283](https://github.com/crimera/piko/commit/454f283baf3f7d444cb7d8b13eb3728e6a081a36))

### 🔧 Improvements

* **Instagram:** Add flags to Suggested users in search ([4dbc376](https://github.com/crimera/piko/commit/4dbc3764bf9bda3c10546d8e112328a4310cf48a))

## [3.10.0-dev.12](https://github.com/crimera/piko/compare/v3.10.0-dev.11...v3.10.0-dev.12) (2026-10-07)

### 🐛 Bug Fixes

* **Instagram:** Allow screenshots in protected DM windows ([45fee55](https://github.com/crimera/piko/commit/45fee5532102b27aa8a4e95ff5c00ac3cb75fd75))
* **Instagram:** Correct patch status mappings ([bf4a28c](https://github.com/crimera/piko/commit/bf4a28ca5387efd2c51453ef368d686cbf643f8b))
* **Instagram:** Correct the names of the HDR and auto-scroll recommended flags ([#2078](https://github.com/crimera/piko/issues/2078)) ([8917d71](https://github.com/crimera/piko/commit/8917d71e36356ed56e68154b7cf272cfa4dcf0c5))
* **Instagram:** Hide ads in the Following feed ([7914a26](https://github.com/crimera/piko/commit/7914a2634e39738dd11318ea71491a5bf11493f4))
* **Instagram:** Hide the reshare button in the home feed ([ae38467](https://github.com/crimera/piko/commit/ae38467035fbbeeba8e03824535f927cc635adea))
* **Instagram:** Isolate story filters and refresh highlight visibility ([2946e7e](https://github.com/crimera/piko/commit/2946e7ecabedd5da21075e56e9f10824cd1c94d3))
* **Instagram:** Move the story seen button to the bottom action row ([0d7fba0](https://github.com/crimera/piko/commit/0d7fba0feeb17c430af4292176be47036593bda3))
* **Instagram:** Preserve ephemeral media after refreshing chats ([d9ab7c7](https://github.com/crimera/piko/commit/d9ab7c7d3327481ea07e8a63f302590158c9fae5))
* **Instagram:** Refresh profile friendship status and hide unknown states ([2418d65](https://github.com/crimera/piko/commit/2418d657c7cfb1db752980c2cc10b74bd3af4641))

### ✨ New Features

* **Instagram:** Add Hide save buttons patch ([ac89a04](https://github.com/crimera/piko/commit/ac89a04d6f75dbc5e5c80dc95a80bec539e8f167))
* **Instagram:** Add Hide share button patch ([15b8856](https://github.com/crimera/piko/commit/15b88567abb2433ca930da264709f5c2b37f7037))
* **Instagram:** Add recommended flags for the Reels seekbar ([e558f88](https://github.com/crimera/piko/commit/e558f8848f983802a9063c45996b3275ccdb0b0a))
* **Instagram:** Add Story category ([#1948](https://github.com/crimera/piko/issues/1948)) ([ec55052](https://github.com/crimera/piko/commit/ec55052596689de7996ed8fb78ea907977158269))

### 🔧 Improvements

* **Instagram:** Hide comment buttons and counts ([2cbd8b2](https://github.com/crimera/piko/commit/2cbd8b268b8ba21c5321b58be861c1402b46e6d8))
* **Instagram:** Organization options ([#2073](https://github.com/crimera/piko/issues/2073)) ([e3039f9](https://github.com/crimera/piko/commit/e3039f97cd247659d9f853146e2393f57ce662c1))

## [3.10.0-dev.11](https://github.com/crimera/piko/compare/v3.10.0-dev.10...v3.10.0-dev.11) (2026-10-05)

### 🐛 Bug Fixes

* **Instagram:** Find the expire field of ephemeral media by its own key ([#2046](https://github.com/crimera/piko/issues/2046)) ([ff2c809](https://github.com/crimera/piko/commit/ff2c809f1a89a5b9be8713a6fd987299d9397c63))
* **Instagram:** Stop Open links externally from crashing on 447 ([#2047](https://github.com/crimera/piko/issues/2047)) ([4c15083](https://github.com/crimera/piko/commit/4c15083cf3a1b65f874c0bc59f68b51055bdaff2))

## [3.10.0-dev.10](https://github.com/crimera/piko/compare/v3.10.0-dev.9...v3.10.0-dev.10) (2026-10-04)

### 🐛 Bug Fixes

* **Instagram:** Align Instants settings and saved viewer styling ([#2017](https://github.com/crimera/piko/issues/2017)) ([a0a3360](https://github.com/crimera/piko/commit/a0a33601aa0c6cc99e990ea0f7f8dfd31c43640d))
* **Instagram:** Fill menu highlights above dialog buttons ([#2016](https://github.com/crimera/piko/issues/2016)) ([a326e42](https://github.com/crimera/piko/commit/a326e42fd87be1540aad23f7c8aab0e96dbb263d))
* **Instagram:** Hide non-follower badges for unknown friendship status ([f385660](https://github.com/crimera/piko/commit/f3856607144c2b2b825aec46f7cd3a5ee0490a8f))
* **Instagram:** Restore the activity context for like animation previews ([#2014](https://github.com/crimera/piko/issues/2014)) ([1f08d91](https://github.com/crimera/piko/commit/1f08d91edf63d2a31ce49d52a5af3acf6ed04c98))
* **Instagram:** Validate the picked file before restoring settings ([#1985](https://github.com/crimera/piko/issues/1985)) ([1f1f3f7](https://github.com/crimera/piko/commit/1f1f3f7d25ca1159823c55580194c62b1af882ea))
* **Twitter:** Apply dynamic color to Dim and Lights out themes ([#2027](https://github.com/crimera/piko/issues/2027)) ([5842cb7](https://github.com/crimera/piko/commit/5842cb7b3589bba0669cc78a34cb3c27f1749a2d)), closes [#15202](https://github.com/crimera/piko/issues/15202) [#bf15202](https://github.com/crimera/piko/issues/bf15202)

### ✨ New Features

* **Instagram:** Add an option to enable inline download button on feed and profile posts ([#1997](https://github.com/crimera/piko/issues/1997)) ([a074bb9](https://github.com/crimera/piko/commit/a074bb97485f79dcd239675be44403e8b3dbbf80))
* **Instagram:** Add Inbox lock to ask for your biometrics before messages ([#2020](https://github.com/crimera/piko/issues/2020)) ([d2c5f0a](https://github.com/crimera/piko/commit/d2c5f0a6b843a4aabf08bf7aeb2c25b51e62e9e7)), closes [#2018](https://github.com/crimera/piko/issues/2018)
* **Instagram:** Save and view received Instants ([#1538](https://github.com/crimera/piko/issues/1538)) ([40e1327](https://github.com/crimera/piko/commit/40e1327b265565e19074bf699091dcde77f581dc))

### 🚀 Updated App Support

* **Instagram:** Add support for 447.0.0.55.81 ([3e15b92](https://github.com/crimera/piko/commit/3e15b928c85449e21b3e6a34a2ac419d272885bb))

### 🔧 Improvements

* **Instagram:** Add a close button to resolution dialogs ([9383ab3](https://github.com/crimera/piko/commit/9383ab3ce00462d3f3ce174ef51bba6699fee137))
* **Instagram:** Add feedback to the unlock button ([44fcefb](https://github.com/crimera/piko/commit/44fcefb539dce3640fc2e88eb20c72ef9ccec101))
* **Instagram:** Match Inbox lock styling and reorder DM settings ([8dbcb52](https://github.com/crimera/piko/commit/8dbcb52bdb0bf34a74d3c6bf1be578fab27e517e))
* **Instagram:** Reorder DM settings ([40f8c14](https://github.com/crimera/piko/commit/40f8c148a21f4963800c281c961e668e3fbcb6d2))
* **Instagram:** Use the native story mentions dialog ([#2030](https://github.com/crimera/piko/issues/2030)) ([14faf0a](https://github.com/crimera/piko/commit/14faf0a00a46bd46361f0d6153375f2451bf20f7))

## [3.10.0-dev.9](https://github.com/crimera/piko/compare/v3.10.0-dev.8...v3.10.0-dev.9) (2026-09-29)

### 🐛 Bug Fixes

* **Instagram:** add auto-scroll persistence flag to recommended flags ([#1957](https://github.com/crimera/piko/issues/1957)) ([096ea87](https://github.com/crimera/piko/commit/096ea8738d2edae3bf1d47aa8404822e6d4ccc5d)), closes [#1746](https://github.com/crimera/piko/issues/1746)
* **Instagram:** invoke reflected methods on the correct receiver ([#1960](https://github.com/crimera/piko/issues/1960)) ([e4a9464](https://github.com/crimera/piko/commit/e4a9464792f8990a003a9289fe75243f6a54fa48))
* **Instagram:** Refine Focus Lock highlight and slider spacing ([#1982](https://github.com/crimera/piko/issues/1982)) ([c5b8ca5](https://github.com/crimera/piko/commit/c5b8ca5855b04706d86b20de89752780c36a7aa6))
* **Instagram:** remove forced HDR brightness on photos and Reels ([#1955](https://github.com/crimera/piko/issues/1955)) ([0084136](https://github.com/crimera/piko/commit/0084136b5ded2210e03d14dceabb09013be1cb3a)), closes [#1817](https://github.com/crimera/piko/issues/1817)

### ✨ New Features

* **Instagram:** Add `Focus Lock` patch ([#1928](https://github.com/crimera/piko/issues/1928)) ([2b6b5ac](https://github.com/crimera/piko/commit/2b6b5ac21cb199f40a4e6dfc0dc76c36992fe31f))
* **Instagram:** add custom font support ([#1920](https://github.com/crimera/piko/issues/1920)) ([065bb95](https://github.com/crimera/piko/commit/065bb95ad626b05c1d11e7ba64698e4e313ce81b))
* **Instagram:** Customize download filenames ([#1923](https://github.com/crimera/piko/issues/1923)) ([8507022](https://github.com/crimera/piko/commit/850702242069fab700d6382ec4287d95f4e1f722))
* **Instagram:** Hide Reels follow button ([#1911](https://github.com/crimera/piko/issues/1911)) ([f180a7b](https://github.com/crimera/piko/commit/f180a7b4c628f1f23d9e78fc8ed3715e652b0a03))
* **Instagram:** Lock any distraction free setting with Focus Lock ([#1953](https://github.com/crimera/piko/issues/1953)) ([97ea429](https://github.com/crimera/piko/commit/97ea42941f25a68e8fd1080852a576b0b80cd134))
* **Instagram:** Restore classic search recents (up to 25) ([#1741](https://github.com/crimera/piko/issues/1741)) ([bb98bcb](https://github.com/crimera/piko/commit/bb98bcb219ca0a30ee672db4361dc70abbfe06df))
* **Instagram:** Show non-followers in the Following list ([#1978](https://github.com/crimera/piko/issues/1978)) ([f2395c9](https://github.com/crimera/piko/commit/f2395c9c84ccc989771701d6b27bd556c949274c)), closes [#1899](https://github.com/crimera/piko/issues/1899)

### 🔧 Improvements

* **Instagram:** Cache extended media data lookups per MediaData instance ([#1967](https://github.com/crimera/piko/issues/1967)) ([b2800b7](https://github.com/crimera/piko/commit/b2800b7adb96b93bada54e745342d9a4add27c17))
* **Instagram:** Cache reflective Field/Method lookups in Entity ([#1966](https://github.com/crimera/piko/issues/1966)) ([5fdc28f](https://github.com/crimera/piko/commit/5fdc28fbaa731f66bc5aaa93133c27a1b1b16796))
* **Instagram:** Cache resolved classes in DirectItem instead of calling Class.forName repeatedly ([#1969](https://github.com/crimera/piko/issues/1969)) ([e91f754](https://github.com/crimera/piko/commit/e91f7540724d8c9f9d5bef50cff9ede582c7fb85))
* **Instagram:** Cache the resolved helper class in DeveloperOptionsItem ([#1973](https://github.com/crimera/piko/issues/1973)) ([e252d0b](https://github.com/crimera/piko/commit/e252d0b3e24f5a75edd21d7d242f13422cfde01a))
* **Instagram:** Cache track data mappings per TrackDataIntf instance ([#1970](https://github.com/crimera/piko/issues/1970)) ([0cc09e0](https://github.com/crimera/piko/commit/0cc09e09799b506375f04aee66b0c53112f518a0))
* **Instagram:** Skip redundant fill-in updates for freshly inserted messages ([#1971](https://github.com/crimera/piko/issues/1971)) ([1bcc99d](https://github.com/crimera/piko/commit/1bcc99d57f7bccd61187666a745bfd4804ef7a09))
* **Instagram:** Use a HashSet instead of a List for the feed JSON key filter ([#1972](https://github.com/crimera/piko/issues/1972)) ([daf0a63](https://github.com/crimera/piko/commit/daf0a63f3176a3272aeb846257f295cc233e6850))
* **Twitter:** Use a Set for the feature-flag search-string membership check ([#1974](https://github.com/crimera/piko/issues/1974)) ([6622be4](https://github.com/crimera/piko/commit/6622be4d5c7b3634e09c0f569259d69c72cabdfe))

## [3.10.0-dev.8](https://github.com/crimera/piko/compare/v3.10.0-dev.7...v3.10.0-dev.8) (2026-09-14)

### 🐛 Bug Fixes

* **ci:** Import Crowdin translations onto the latest dev ([#1890](https://github.com/crimera/piko/issues/1890)) ([385a8d1](https://github.com/crimera/piko/commit/385a8d1852434f0529d4a017f723ccc5cae4e0b8))
* **Twitter:** Preserve links when applying custom fonts ([#1889](https://github.com/crimera/piko/issues/1889)) ([f5d1db8](https://github.com/crimera/piko/commit/f5d1db88cb2e1782436604168903347b43d3743c))

### ✨ New Features

* **Instagram:** Update the Direct icon in settings and in the navigation customization window. ([#1888](https://github.com/crimera/piko/issues/1888)) ([7e50716](https://github.com/crimera/piko/commit/7e507162e87e8ac586216fa7562add6bac355d28))

## [3.10.0-dev.7](https://github.com/crimera/piko/compare/v3.10.0-dev.6...v3.10.0-dev.7) (2026-09-13)

### 🐛 Bug Fixes

* **Instagram:** Keep settings switch animations consistent after shortcut launch ([#1883](https://github.com/crimera/piko/issues/1883)) ([6ffb046](https://github.com/crimera/piko/commit/6ffb046f68cf0d82c36d9c9837d695d259838331))
* **Instagram:** Preserve the startup tab while editing navigation ([#1880](https://github.com/crimera/piko/issues/1880)) ([cb1241f](https://github.com/crimera/piko/commit/cb1241f236801e8b5d58722e7db0b6d12680d08d))
* **Instagram:** Preserve unobserved theme state ([#1872](https://github.com/crimera/piko/issues/1872)) ([cf7cd66](https://github.com/crimera/piko/commit/cf7cd668dfe554a3a2de016524c88f92e7fb6303))
* **Instagram:** Skip event dispatch when analytics are disabled ([#1877](https://github.com/crimera/piko/issues/1877)) ([7a44c6d](https://github.com/crimera/piko/commit/7a44c6d8306a1c2ca32502b3497308af8e1677b0))
* **Instagram:** Sync ghost mode icons when settings change ([#1875](https://github.com/crimera/piko/issues/1875)) ([dc12da8](https://github.com/crimera/piko/commit/dc12da8f03703fb6fa50ce11d009e32754c0761b))
* **Twitter:** avoid copying editor spans in custom font hook ([c6deb8d](https://github.com/crimera/piko/commit/c6deb8daa5cd1f41a3a368802cf87c6f5dbf2749))

### ✨ New Features

* **Instagram:** Add startup tab selection ([#1869](https://github.com/crimera/piko/issues/1869)) ([d284f62](https://github.com/crimera/piko/commit/d284f629056344bec9351fe86afd73f07ef25818))
* **Instagram:** Add story seen button ([#1884](https://github.com/crimera/piko/issues/1884)) ([c39e122](https://github.com/crimera/piko/commit/c39e122dbce23d9d603bc73010e0aeaccdfe88bd))
* **Instagram:** Add visibility controls for create and notification buttons ([#1870](https://github.com/crimera/piko/issues/1870)) ([a1c0866](https://github.com/crimera/piko/commit/a1c0866824ef72cd40b5d03d3ec2a46bf5f8cdaf))
* **Instagram:** Customize navigation bar ([#1867](https://github.com/crimera/piko/issues/1867)) ([bbd335c](https://github.com/crimera/piko/commit/bbd335ca7764ec99c3c9936e0ffd71723699e627))

## [3.10.0-dev.6](https://github.com/crimera/piko/compare/v3.10.0-dev.5...v3.10.0-dev.6) (2026-09-10)

### 🐛 Bug Fixes

* **Twitter - Show changelogs:** Error message is shown with changelog dialog ([e1238c3](https://github.com/crimera/piko/commit/e1238c3ffd38b1573a11a411000080f825f79583))
* **Twitter:** Restore timeline position on startup ([ae231c5](https://github.com/crimera/piko/commit/ae231c596bf9b7d3b1f2a1cff9ef5e74151cd6b9))

### ✨ New Features

* **Twitter:** Add bulk feature flag selection and validation ([#1846](https://github.com/crimera/piko/issues/1846)) ([7b92ac8](https://github.com/crimera/piko/commit/7b92ac8626b2ff907769503ae85b688fd2471c36))

## [3.10.0-dev.5](https://github.com/crimera/piko/compare/v3.10.0-dev.4...v3.10.0-dev.5) (2026-09-07)

### 🐛 Bug Fixes

* **Twitter:** restore relationship actions in user lists ([854f5e2](https://github.com/crimera/piko/commit/854f5e26831c997e376a7b68094a7fbde89fc790))

## [3.10.0-dev.4](https://github.com/crimera/piko/compare/v3.10.0-dev.3...v3.10.0-dev.4) (2026-09-04)

### 🐛 Bug Fixes

* **Instagram:** Add missing entity dependencies ([#1833](https://github.com/crimera/piko/issues/1833)) ([a19b255](https://github.com/crimera/piko/commit/a19b255eccd3b2fed5474bc481ab7f3ae6640be9))

## [3.10.0-dev.3](https://github.com/crimera/piko/compare/v3.10.0-dev.2...v3.10.0-dev.3) (2026-09-04)

### 🐛 Bug Fixes

* Revert "fix(twitter - `Bring Back Twitter`): support to new versions" ([df9b407](https://github.com/crimera/piko/commit/df9b4079d33aea17dcda5e4ebacd7bc4307421b9))

## [3.10.0-dev.2](https://github.com/crimera/piko/compare/v3.10.0-dev.1...v3.10.0-dev.2) (2026-09-04)

### 🐛 Bug Fixes

* **github:** use existing enhancement label and add missing twitter label ([6337845](https://github.com/crimera/piko/commit/63378453c020ce89f490e802356418816be6820a))
* **twitter - `Bring Back Twitter`:** support to new versions ([ff97563](https://github.com/crimera/piko/commit/ff975634c0e30b87fbb06cdcae556ff00f351a7a))

### ✨ New Features

* **Instagram:** Embed metadata in downloaded videos ([#1828](https://github.com/crimera/piko/issues/1828)) ([9493252](https://github.com/crimera/piko/commit/949325266af15c51477101be81ad8692bb439557))

## [3.10.0-dev.1](https://github.com/crimera/piko/compare/v3.9.0...v3.10.0-dev.1) (2026-09-03)

### 🐛 Bug Fixes

* **Instagram:** Prevent newlines in text preferences ([#1811](https://github.com/crimera/piko/issues/1811)) ([2cb1faa](https://github.com/crimera/piko/commit/2cb1faa3e18a7e99a5271957803cc5e6c278692e))
* **Instagram:** Recover settings after crash ([#1822](https://github.com/crimera/piko/issues/1822)) ([8391a5b](https://github.com/crimera/piko/commit/8391a5b6817289307eb2fef96837c2055eebea99))
* **Twitter:** guard null ShareTarget in modern share sheet link hook ([5066035](https://github.com/crimera/piko/commit/5066035bc43b7c27f7e13248f0edec5afa7be85a))

### ✨ New Features

* **Instagram:** Integrate `Disable onboarding permission prompts` patch into `Disable analytics` ([#1771](https://github.com/crimera/piko/issues/1771)) ([a7974cd](https://github.com/crimera/piko/commit/a7974cd4c66dff557c2905ea92ad73741b46fa44))

## [3.9.0](https://github.com/crimera/piko/compare/v3.8.0...v3.9.0) (2026-08-31)

### 🐛 Bug Fixes

* **Bring back Twitter:** restore omitted Twitter 9.98 terminology ([a435e35](https://github.com/crimera/piko/commit/a435e35f9bb5008b39d2f9e2a08bd2c27450913f))
* **instagram:** add dialog entity dependency for media downloads ([5987d0b](https://github.com/crimera/piko/commit/5987d0be5704abdf1da15a8609924aa8a1118dbb))
* **Instagram:** block permission onboarding screens ([#1686](https://github.com/crimera/piko/issues/1686)) ([de6bcea](https://github.com/crimera/piko/commit/de6bceaa0ceace832a63f8c116c8efc562a5c488))
* **Instagram:** Check and add external downloader options in settings ([c6651df](https://github.com/crimera/piko/commit/c6651df52aab328755ea4138f87ab079cad25cf1))
* **Instagram:** Correct shared link sanitization ([#1698](https://github.com/crimera/piko/issues/1698)) ([cbb5577](https://github.com/crimera/piko/commit/cbb55775f3448e0d50322ebde636bfbf4e8db2fd))
* **Instagram:** don't record an unsend we never captured ([#1728](https://github.com/crimera/piko/issues/1728)) ([e38bc52](https://github.com/crimera/piko/commit/e38bc52c246992cb5ada60c826b27a2d89163e52))
* **Instagram:** Fix default flag state while extracting recommended flags map ([82785a8](https://github.com/crimera/piko/commit/82785a858bae02ee11bd8ff07f06fa260bcceea2))
* **Instagram:** Fix more profile options ([#1708](https://github.com/crimera/piko/issues/1708)) ([ebf8ff1](https://github.com/crimera/piko/commit/ebf8ff1d9031c7e3a974a646d8dc4fde4419e1e8))
* **Instagram:** Fix reels current media logic ([40836e8](https://github.com/crimera/piko/commit/40836e83e10b1f023e7ec4c1dca4f1407ba6d638))
* **Instagram:** Fix register issue while hooking reel overflow menu ([83786a8](https://github.com/crimera/piko/commit/83786a8d379b7ae05bfaa73ab07c94172ba9d9d3))
* **Instagram:** Fix user data entity fingerprints ([5d83613](https://github.com/crimera/piko/commit/5d8361334805470b2cc94fcfd0f2e4623a4d6be0))
* **Instagram:** follow app theme in deleted messages screen ([36b21b2](https://github.com/crimera/piko/commit/36b21b28d5f5ff5aad85a7329b39d50e7f490375))
* **Instagram:** handle missing context for comment media downloads ([#1677](https://github.com/crimera/piko/issues/1677)) ([4588900](https://github.com/crimera/piko/commit/45889000685d29e07bdf223050ebaa0eadc38eb2))
* **instagram:** pass current carousel index to reel overflow buttons ([#1586](https://github.com/crimera/piko/issues/1586)) ([a80bf4a](https://github.com/crimera/piko/commit/a80bf4af5bdc1ff402793dbe0209a642c015b3fa))
* **instagram:** patch GRAY_1600 to fix Compose surfaces staying gray in AMOLED mode ([#1596](https://github.com/crimera/piko/issues/1596)) ([07d08d4](https://github.com/crimera/piko/commit/07d08d4ba4a291bb3f454ec3e92ca9cb6f07975d))
* **instagram:** preserve material you surface contrast ([0c1fff3](https://github.com/crimera/piko/commit/0c1fff3f8510cfa818e237bf36f74a7ac35a0080))
* **Instagram:** preserve pill button contrast ([#1722](https://github.com/crimera/piko/issues/1722)) ([8e08ffc](https://github.com/crimera/piko/commit/8e08ffcccc675f8f995fe950e71091c9a46eca9b))
* **Instagram:** preserve reels media control colors ([#1681](https://github.com/crimera/piko/issues/1681)) ([3befb48](https://github.com/crimera/piko/commit/3befb4800a92a2a3046b394a4e6c230083fc8bb2))
* **instagram:** prevent inbox action bar verifier crash ([b65cdb2](https://github.com/crimera/piko/commit/b65cdb26c195891a12e2b7ad64c90cb21e56b042))
* **Instagram:** Prevent notification registration crash ([#1678](https://github.com/crimera/piko/issues/1678)) ([4f67a78](https://github.com/crimera/piko/commit/4f67a78430871afa0eff393d9127f78fd11a85e0))
* **instagram:** restore amoled after dark mode returns ([#1679](https://github.com/crimera/piko/issues/1679)) ([96536bb](https://github.com/crimera/piko/commit/96536bbf24544219e0bd279ed6bba357e2b3da28))
* **instagram:** restore profile action bar hooks ([5cf2a42](https://github.com/crimera/piko/commit/5cf2a427c2f8b3831276fe8cbc6a12178aa3dbe4))
* **Instagram:** use xml mime type for settings export ([#1720](https://github.com/crimera/piko/issues/1720)) ([accfdc8](https://github.com/crimera/piko/commit/accfdc8066862cc8a80cf022cf8463d951fd9b27))
* **resources:** support plural overrides for bundled resources ([3acd3aa](https://github.com/crimera/piko/commit/3acd3aa4f7326e606f0bd81e978b735ef0fdc9e9))
* **Twitter:** "Change app icon" is broken on recent X versions ([#1624](https://github.com/crimera/piko/issues/1624)) ([350779d](https://github.com/crimera/piko/commit/350779d06bdf8c86992332387062bb42a6e236bc))
* **Twitter:** `Block redirecting to X Lite` patch failed on X 12.6.0-release.0 ([01d4452](https://github.com/crimera/piko/commit/01d445211b68f43cd4dd56f962854f3df20d1f5e))
* **Twitter:** Add `Block update screen` patch ([9f257f7](https://github.com/crimera/piko/commit/9f257f71f927d03b09c1dd1212ccd74d1e5d8413))
* **Twitter:** Don't rely on obfuscated names in `Show sensitive media` fingerprint ([d70c4d0](https://github.com/crimera/piko/commit/d70c4d008402547055a03777664702e65f2c18eb))
* **Twitter:** Fix `More information on profile` fingerprint on 12.11 ([3b5c945](https://github.com/crimera/piko/commit/3b5c94596dc45af901c0c6efbd72af0e03a12e9e))
* **Twitter:** Fix `Show sensitive media` on the Compose timeline ([aeeb178](https://github.com/crimera/piko/commit/aeeb178390a8a52ecec1897dd278b6ac38f8f371))
* **Twitter:** Fix `Show sensitive media` patch ([#1723](https://github.com/crimera/piko/issues/1723)) ([84919ef](https://github.com/crimera/piko/commit/84919ef416924643ec75c6834cb867ec1506a8bc))
* **Twitter:** Fix check and add `more info on profile` preference ([97f9dca](https://github.com/crimera/piko/commit/97f9dcaad76e6bd61f5a3347ced7e778155f47b1))
* **Twitter:** Fix inverted upsell flag boolean ([8a8b9e1](https://github.com/crimera/piko/commit/8a8b9e1a92da7d80419679ab0c900647bffed44a))
* **twitter:** replace ic_vector_x logo in Bring back twitter patch ([7b6c7e9](https://github.com/crimera/piko/commit/7b6c7e9949422a470563a50cb1efd36d0416fa50))
* **twitter:** rewrite repost share links with original author ([11e7222](https://github.com/crimera/piko/commit/11e72222b5b6a974535991e34cf0e9daefb2b537))

### ✨ New Features

* **Instagram:** Add custom sharing domain ([#1712](https://github.com/crimera/piko/issues/1712)) ([879f269](https://github.com/crimera/piko/commit/879f269cc6f3e69e489b6b574961da9c9d2096b2))
* **Instagram:** Add in-app profile picture viewer ([#1721](https://github.com/crimera/piko/issues/1721)) ([7d34500](https://github.com/crimera/piko/commit/7d34500c7553ed8baf61816ab0bf6ad0ca7f18d8))
* **Instagram:** Add loop story ([#1713](https://github.com/crimera/piko/issues/1713)) ([4b75ec7](https://github.com/crimera/piko/commit/4b75ec78428836bb5fd8bedf65a34f52f42a7315))
* **instagram:** add material you and amoled theme controls ([#1631](https://github.com/crimera/piko/issues/1631)) ([840492a](https://github.com/crimera/piko/commit/840492a46c603fb99e55ec03fb1ec47c735c169a))
* **Instagram:** Added `Recommended flags` section ([ff31eda](https://github.com/crimera/piko/commit/ff31eda2ea878c77820c455088b4d23c561e049a))
* **Instagram:** Added mappings for `439.0.0.37.89` ([b335af3](https://github.com/crimera/piko/commit/b335af3f20cefe15d6f5342fd5cc41d692eb9fac))
* **Instagram:** Added more options in profile options menu ([#1638](https://github.com/crimera/piko/issues/1638)) ([ad61869](https://github.com/crimera/piko/commit/ad61869cc0711670f83fea67c2bd959b95a0ad62))
* **Instagram:** Added some recommended flags ([40ddc7e](https://github.com/crimera/piko/commit/40ddc7ee525e351ae57e71055a81d995207e9917))
* **Instagram:** Added some recommended flags ([#1651](https://github.com/crimera/piko/issues/1651)) ([1cb0687](https://github.com/crimera/piko/commit/1cb068703fc101903272bea21fc93fe12ddde662))
* **Instagram:** Made `Recommended flags` into patch ([f81fc79](https://github.com/crimera/piko/commit/f81fc7992792a72ecfc7d006590db9a506c86caa))
* **Instagram:** New patch to block onboarding permission prompts ([9b6e569](https://github.com/crimera/piko/commit/9b6e56956ecb6df916afc1743a6cbb3b8e463b33))
* **Instagram:** save deleted messages ([#1531](https://github.com/crimera/piko/issues/1531)) ([6c120d6](https://github.com/crimera/piko/commit/6c120d603cb830c0ccc8c4a99acc9eab089f70bd))
* **Twitter:** Add Dynamic color switch toggle ([#1582](https://github.com/crimera/piko/issues/1582)) ([c3de8d8](https://github.com/crimera/piko/commit/c3de8d8df101203139ff3171bf8f600ef3eef028))

### 🚀 Updated App Support

* **Instagram:** Add support for `439.0.0.37.89` ([3e38d22](https://github.com/crimera/piko/commit/3e38d22c56b37ded2861be7d24f0afea0f0c7034))
* **Twitter:** Add support for `12.11.0-release.0` ([cdca6a8](https://github.com/crimera/piko/commit/cdca6a84f94366aa91c1c2fcb533056413a95d61))
* **Twitter:** bump support to `12.17.0-release.0` ([9d08cd3](https://github.com/crimera/piko/commit/9d08cd33d4bdba67cd86d441747a8e3300522aa2))
* **Twitter:** bump support to `12.19.1-release.0` ([4350e4d](https://github.com/crimera/piko/commit/4350e4d8c073c59f79535f8e3fc63dbeb0d21b81))

### 🔧 Improvements

* **Instagram:** Improve piko settings ([#1684](https://github.com/crimera/piko/issues/1684)) ([17662c3](https://github.com/crimera/piko/commit/17662c3d311a093b4f35545db5ba73d4c8547a6d))
* **Instagram:** refresh recommended flags after download ([#1685](https://github.com/crimera/piko/issues/1685)) ([85057c0](https://github.com/crimera/piko/commit/85057c09a76f2efbd481f0ffb6454c40d067cfb7))
* **Instagram:** Turn off `Disable analytics` by default ([#1674](https://github.com/crimera/piko/issues/1674)) ([753a70b](https://github.com/crimera/piko/commit/753a70be81449c27f0a8e056f7f0e938a11e964e))
* **Twitter:** improve more profile info ([#1687](https://github.com/crimera/piko/issues/1687)) ([46cb754](https://github.com/crimera/piko/commit/46cb754e48b66606f19804b610cd085d54f5d173))

## [3.9.0-dev.10](https://github.com/crimera/piko/compare/v3.9.0-dev.9...v3.9.0-dev.10) (2026-08-28)

### 🐛 Bug Fixes

* **Bring back Twitter:** restore omitted Twitter 9.98 terminology ([a435e35](https://github.com/crimera/piko/commit/a435e35f9bb5008b39d2f9e2a08bd2c27450913f))
* **instagram:** add dialog entity dependency for media downloads ([5987d0b](https://github.com/crimera/piko/commit/5987d0be5704abdf1da15a8609924aa8a1118dbb))
* **Instagram:** follow app theme in deleted messages screen ([36b21b2](https://github.com/crimera/piko/commit/36b21b28d5f5ff5aad85a7329b39d50e7f490375))
* **instagram:** preserve material you surface contrast ([0c1fff3](https://github.com/crimera/piko/commit/0c1fff3f8510cfa818e237bf36f74a7ac35a0080))
* **resources:** support plural overrides for bundled resources ([3acd3aa](https://github.com/crimera/piko/commit/3acd3aa4f7326e606f0bd81e978b735ef0fdc9e9))
* **Twitter:** Don't rely on obfuscated names in `Show sensitive media` fingerprint ([d70c4d0](https://github.com/crimera/piko/commit/d70c4d008402547055a03777664702e65f2c18eb))
* **Twitter:** Fix `Show sensitive media` on the Compose timeline ([aeeb178](https://github.com/crimera/piko/commit/aeeb178390a8a52ecec1897dd278b6ac38f8f371))
* **twitter:** rewrite repost share links with original author ([11e7222](https://github.com/crimera/piko/commit/11e72222b5b6a974535991e34cf0e9daefb2b537))

## [3.9.0-dev.9](https://github.com/crimera/piko/compare/v3.9.0-dev.8...v3.9.0-dev.9) (2026-08-17)

### 🐛 Bug Fixes

* **Instagram:** don't record an unsend we never captured ([#1728](https://github.com/crimera/piko/issues/1728)) ([e38bc52](https://github.com/crimera/piko/commit/e38bc52c246992cb5ada60c826b27a2d89163e52))
* **Twitter:** `Block redirecting to X Lite` patch failed on X 12.6.0-release.0 ([01d4452](https://github.com/crimera/piko/commit/01d445211b68f43cd4dd56f962854f3df20d1f5e))
* **Twitter:** Add `Block update screen` patch ([9f257f7](https://github.com/crimera/piko/commit/9f257f71f927d03b09c1dd1212ccd74d1e5d8413))

## [3.9.0-dev.8](https://github.com/crimera/piko/compare/v3.9.0-dev.7...v3.9.0-dev.8) (2026-08-16)

### 🐛 Bug Fixes

* **Instagram:** block permission onboarding screens ([#1686](https://github.com/crimera/piko/issues/1686)) ([de6bcea](https://github.com/crimera/piko/commit/de6bceaa0ceace832a63f8c116c8efc562a5c488))
* **Instagram:** Correct shared link sanitization ([#1698](https://github.com/crimera/piko/issues/1698)) ([cbb5577](https://github.com/crimera/piko/commit/cbb55775f3448e0d50322ebde636bfbf4e8db2fd))
* **Instagram:** Fix more profile options ([#1708](https://github.com/crimera/piko/issues/1708)) ([ebf8ff1](https://github.com/crimera/piko/commit/ebf8ff1d9031c7e3a974a646d8dc4fde4419e1e8))
* **Instagram:** handle missing context for comment media downloads ([#1677](https://github.com/crimera/piko/issues/1677)) ([4588900](https://github.com/crimera/piko/commit/45889000685d29e07bdf223050ebaa0eadc38eb2))
* **Instagram:** preserve pill button contrast ([#1722](https://github.com/crimera/piko/issues/1722)) ([8e08ffc](https://github.com/crimera/piko/commit/8e08ffcccc675f8f995fe950e71091c9a46eca9b))
* **Instagram:** preserve reels media control colors ([#1681](https://github.com/crimera/piko/issues/1681)) ([3befb48](https://github.com/crimera/piko/commit/3befb4800a92a2a3046b394a4e6c230083fc8bb2))
* **Instagram:** Prevent notification registration crash ([#1678](https://github.com/crimera/piko/issues/1678)) ([4f67a78](https://github.com/crimera/piko/commit/4f67a78430871afa0eff393d9127f78fd11a85e0))
* **instagram:** restore amoled after dark mode returns ([#1679](https://github.com/crimera/piko/issues/1679)) ([96536bb](https://github.com/crimera/piko/commit/96536bbf24544219e0bd279ed6bba357e2b3da28))
* **Instagram:** use xml mime type for settings export ([#1720](https://github.com/crimera/piko/issues/1720)) ([accfdc8](https://github.com/crimera/piko/commit/accfdc8066862cc8a80cf022cf8463d951fd9b27))
* **Twitter:** Fix `Show sensitive media` patch ([#1723](https://github.com/crimera/piko/issues/1723)) ([84919ef](https://github.com/crimera/piko/commit/84919ef416924643ec75c6834cb867ec1506a8bc))

### ✨ New Features

* **Instagram:** Add custom sharing domain ([#1712](https://github.com/crimera/piko/issues/1712)) ([879f269](https://github.com/crimera/piko/commit/879f269cc6f3e69e489b6b574961da9c9d2096b2))
* **Instagram:** Add in-app profile picture viewer ([#1721](https://github.com/crimera/piko/issues/1721)) ([7d34500](https://github.com/crimera/piko/commit/7d34500c7553ed8baf61816ab0bf6ad0ca7f18d8))
* **Instagram:** Add loop story ([#1713](https://github.com/crimera/piko/issues/1713)) ([4b75ec7](https://github.com/crimera/piko/commit/4b75ec78428836bb5fd8bedf65a34f52f42a7315))
* **Instagram:** save deleted messages ([#1531](https://github.com/crimera/piko/issues/1531)) ([6c120d6](https://github.com/crimera/piko/commit/6c120d603cb830c0ccc8c4a99acc9eab089f70bd))

### 🚀 Updated App Support

* **Twitter:** bump support to `12.17.0-release.0` ([9d08cd3](https://github.com/crimera/piko/commit/9d08cd33d4bdba67cd86d441747a8e3300522aa2))

### 🔧 Improvements

* **Instagram:** Improve piko settings ([#1684](https://github.com/crimera/piko/issues/1684)) ([17662c3](https://github.com/crimera/piko/commit/17662c3d311a093b4f35545db5ba73d4c8547a6d))
* **Instagram:** refresh recommended flags after download ([#1685](https://github.com/crimera/piko/issues/1685)) ([85057c0](https://github.com/crimera/piko/commit/85057c09a76f2efbd481f0ffb6454c40d067cfb7))
* **Twitter:** improve more profile info ([#1687](https://github.com/crimera/piko/issues/1687)) ([46cb754](https://github.com/crimera/piko/commit/46cb754e48b66606f19804b610cd085d54f5d173))

## [3.9.0-dev.7](https://github.com/crimera/piko/compare/v3.9.0-dev.6...v3.9.0-dev.7) (2026-08-10)

### 🔧 Improvements

* **Instagram:** Turn off `Disable analytics` by default ([#1674](https://github.com/crimera/piko/issues/1674)) ([753a70b](https://github.com/crimera/piko/commit/753a70be81449c27f0a8e056f7f0e938a11e964e))

## [3.9.0-dev.6](https://github.com/crimera/piko/compare/v3.9.0-dev.5...v3.9.0-dev.6) (2026-08-09)

### 🐛 Bug Fixes

* **Instagram:** Fix default flag state while extracting recommended flags map ([82785a8](https://github.com/crimera/piko/commit/82785a858bae02ee11bd8ff07f06fa260bcceea2))

## [3.9.0-dev.5](https://github.com/crimera/piko/compare/v3.9.0-dev.4...v3.9.0-dev.5) (2026-08-09)

### ✨ New Features

* **Instagram:** Added some recommended flags ([#1651](https://github.com/crimera/piko/issues/1651)) ([1cb0687](https://github.com/crimera/piko/commit/1cb068703fc101903272bea21fc93fe12ddde662))
* **Instagram:** Made `Recommended flags` into patch ([f81fc79](https://github.com/crimera/piko/commit/f81fc7992792a72ecfc7d006590db9a506c86caa))

## [3.9.0-dev.4](https://github.com/crimera/piko/compare/v3.9.0-dev.3...v3.9.0-dev.4) (2026-08-03)

### 🐛 Bug Fixes

* **Instagram:** Fix user data entity fingerprints ([5d83613](https://github.com/crimera/piko/commit/5d8361334805470b2cc94fcfd0f2e4623a4d6be0))
* **Twitter:** Fix inverted upsell flag boolean ([8a8b9e1](https://github.com/crimera/piko/commit/8a8b9e1a92da7d80419679ab0c900647bffed44a))

### ✨ New Features

* **Instagram:** Added some recommended flags ([40ddc7e](https://github.com/crimera/piko/commit/40ddc7ee525e351ae57e71055a81d995207e9917))

## [3.9.0-dev.3](https://github.com/crimera/piko/compare/v3.9.0-dev.2...v3.9.0-dev.3) (2026-08-03)

### 🐛 Bug Fixes

* **Instagram:** Check and add external downloader options in settings ([c6651df](https://github.com/crimera/piko/commit/c6651df52aab328755ea4138f87ab079cad25cf1))
* **instagram:** patch GRAY_1600 to fix Compose surfaces staying gray in AMOLED mode ([#1596](https://github.com/crimera/piko/issues/1596)) ([07d08d4](https://github.com/crimera/piko/commit/07d08d4ba4a291bb3f454ec3e92ca9cb6f07975d))
* **Twitter:** "Change app icon" is broken on recent X versions ([#1624](https://github.com/crimera/piko/issues/1624)) ([350779d](https://github.com/crimera/piko/commit/350779d06bdf8c86992332387062bb42a6e236bc))
* **Twitter:** Fix check and add `more info on profile` preference ([97f9dca](https://github.com/crimera/piko/commit/97f9dcaad76e6bd61f5a3347ced7e778155f47b1))
* **twitter:** replace ic_vector_x logo in Bring back twitter patch ([7b6c7e9](https://github.com/crimera/piko/commit/7b6c7e9949422a470563a50cb1efd36d0416fa50))

### ✨ New Features

* **instagram:** add material you and amoled theme controls ([#1631](https://github.com/crimera/piko/issues/1631)) ([840492a](https://github.com/crimera/piko/commit/840492a46c603fb99e55ec03fb1ec47c735c169a))
* **Instagram:** Added `Recommended flags` section ([ff31eda](https://github.com/crimera/piko/commit/ff31eda2ea878c77820c455088b4d23c561e049a))
* **Instagram:** Added more options in profile options menu ([#1638](https://github.com/crimera/piko/issues/1638)) ([ad61869](https://github.com/crimera/piko/commit/ad61869cc0711670f83fea67c2bd959b95a0ad62))
* **Twitter:** Add Dynamic color switch toggle ([#1582](https://github.com/crimera/piko/issues/1582)) ([c3de8d8](https://github.com/crimera/piko/commit/c3de8d8df101203139ff3171bf8f600ef3eef028))

## [3.9.0-dev.2](https://github.com/crimera/piko/compare/v3.9.0-dev.1...v3.9.0-dev.2) (2026-07-27)

### 🐛 Bug Fixes

* **instagram:** prevent inbox action bar verifier crash ([b65cdb2](https://github.com/crimera/piko/commit/b65cdb26c195891a12e2b7ad64c90cb21e56b042))
* **instagram:** restore profile action bar hooks ([5cf2a42](https://github.com/crimera/piko/commit/5cf2a427c2f8b3831276fe8cbc6a12178aa3dbe4))

### ✨ New Features

* **Instagram:** Added mappings for `439.0.0.37.89` ([b335af3](https://github.com/crimera/piko/commit/b335af3f20cefe15d6f5342fd5cc41d692eb9fac))

## [3.9.0-dev.1](https://github.com/crimera/piko/compare/v3.8.0...v3.9.0-dev.1) (2026-07-26)

### 🐛 Bug Fixes

* **Instagram:** Fix reels current media logic ([40836e8](https://github.com/crimera/piko/commit/40836e83e10b1f023e7ec4c1dca4f1407ba6d638))
* **Instagram:** Fix register issue while hooking reel overflow menu ([83786a8](https://github.com/crimera/piko/commit/83786a8d379b7ae05bfaa73ab07c94172ba9d9d3))
* **instagram:** pass current carousel index to reel overflow buttons ([#1586](https://github.com/crimera/piko/issues/1586)) ([a80bf4a](https://github.com/crimera/piko/commit/a80bf4af5bdc1ff402793dbe0209a642c015b3fa))
* **Twitter:** Fix `More information on profile` fingerprint on 12.11 ([3b5c945](https://github.com/crimera/piko/commit/3b5c94596dc45af901c0c6efbd72af0e03a12e9e))

### ✨ New Features

* **Instagram:** New patch to block onboarding permission prompts ([9b6e569](https://github.com/crimera/piko/commit/9b6e56956ecb6df916afc1743a6cbb3b8e463b33))

### 🚀 Updated App Support

* **Instagram:** Add support for `439.0.0.37.89` ([3e38d22](https://github.com/crimera/piko/commit/3e38d22c56b37ded2861be7d24f0afea0f0c7034))
* **Twitter:** Add support for `12.11.0-release.0` ([cdca6a8](https://github.com/crimera/piko/commit/cdca6a84f94366aa91c1c2fcb533056413a95d61))

## [3.8.0](https://github.com/crimera/piko/compare/v3.7.0...v3.8.0) (2026-07-24)

### 🐛 Bug Fixes

* **Instagram:** Fix app crash on comment media download([#1568](https://github.com/crimera/piko/issues/1568)) ([b3b01f7](https://github.com/crimera/piko/commit/b3b01f7f5a9f8f01b66a32299cec06a3748e23b3))
* **Instagram:** Fix chat action bar function name ([1401808](https://github.com/crimera/piko/commit/140180878895841fc8437dc21a39ab7941f79540))
* **Instagram:** Fix opening links ([ba9b4c4](https://github.com/crimera/piko/commit/ba9b4c43af6e4a42ce0654d11aa26a3d28496247))
* **Instagram:** Fix Piko settings color issues ([f1f278a](https://github.com/crimera/piko/commit/f1f278a87665be59218dcc54af983b411802fe0f))
* **Instagram:** match piko settings background to amoled patch ([#1543](https://github.com/crimera/piko/issues/1543)) ([56003dc](https://github.com/crimera/piko/commit/56003dc4b68e6969e208570c45b583bcf709ceb3))
* **Instagram:** Match piko settings highlight to theme ([#1548](https://github.com/crimera/piko/issues/1548)) ([c428e7e](https://github.com/crimera/piko/commit/c428e7ea762cf2ec94e5e9a9f17ea207a976176f))
* **Instagram:** Match story mention dialog to Instagram theme ([#1554](https://github.com/crimera/piko/issues/1554)) ([08563ca](https://github.com/crimera/piko/commit/08563ca54d486585e5fc4bc7c432d6f5f19e6d28))
* **instagram:** preserve settings fragment on recreation ([#1546](https://github.com/crimera/piko/issues/1546)) ([f57ddcc](https://github.com/crimera/piko/commit/f57ddcc555dd487f57d959e5adc625f0f15ed80c))
* **instagram:** Refine piko settings title styling ([#1534](https://github.com/crimera/piko/issues/1534)) ([ce69be6](https://github.com/crimera/piko/commit/ce69be69e8aea7aee04bdf00db5a413bbb849b2f))
* **Instagram:** Refresh localized download folder path ([#1537](https://github.com/crimera/piko/issues/1537)) ([72ce666](https://github.com/crimera/piko/commit/72ce66602c601a2e1b600367bd04430419dadc59))
* **Instagram:** Restore and sync ghost action bar icons ([#1545](https://github.com/crimera/piko/issues/1545)) ([1240faf](https://github.com/crimera/piko/commit/1240faf55fa68867e9517bbd017e1cd1978cfa72))
* **instagram:** restore native off switch colors ([#1533](https://github.com/crimera/piko/issues/1533)) ([71b0b00](https://github.com/crimera/piko/commit/71b0b007096756e1c801c14a1e8c21e2f7cada4a))
* **Twitter - Native Downloader:** Add missing downloadAll method and fix null checks ([ba9d036](https://github.com/crimera/piko/commit/ba9d036e7e01a2455e291504ec4984c9b94cda94))
* **Twitter - Native Downloader:** Clean stale temp file before download and auto-retry legacy resolution if orig fails ([a9d9bd1](https://github.com/crimera/piko/commit/a9d9bd15f9895d723a3bb9eea1ea2d56cd6aa3e4))
* **Twitter - Settings:** Guard native downloader preferences and category by patch status ([d2ac7a0](https://github.com/crimera/piko/commit/d2ac7a08f9ac2679e7b3a1cb999f79e11fae2e76))
* **Twitter:** Apply custom sharing domain to copied links ([#1555](https://github.com/crimera/piko/issues/1555)) ([8e9bec8](https://github.com/crimera/piko/commit/8e9bec895638b5de3c585647496676915b610040))
* **Twitter:** Create category only if the patch is patched ([f3538a3](https://github.com/crimera/piko/commit/f3538a30d2c1d98a3c56e1fe0a7b5222b1ba35ae))
* **Twitter:** Fix `Custom share menu` crash on image view ([f4d2e53](https://github.com/crimera/piko/commit/f4d2e53171621d02f2b04c0a0d4ff220e2e4c799))
* **Twitter:** Fix high resolution image url ([5d07767](https://github.com/crimera/piko/commit/5d07767458b387c85448801851ab4d2de01caf12))
* **Twitter:** Fix inverted number round off ([c0a04aa](https://github.com/crimera/piko/commit/c0a04aac74604e690cacd8925c8bd9f4d13a4664))
* **Twitter:** Fix open supported links activity ([8a1db76](https://github.com/crimera/piko/commit/8a1db76b9c9109db02ee4278b5a6891e5cc2b246))
* **twitter:** Handle bad response during tweet info API ([#1410](https://github.com/crimera/piko/issues/1410)) ([522f7d1](https://github.com/crimera/piko/commit/522f7d13e9f29bae854073a74c1d82cfe1874950))
* **Twitter:** Tweet link pattern ([d2500ea](https://github.com/crimera/piko/commit/d2500ead98dd5bd77ba97f1ef2ac8388f7b559f0))

### ✨ New Features

* **Instagram:** Added `Filter stories` patch ([c62d02a](https://github.com/crimera/piko/commit/c62d02adf1f0160f8bc72c4eb4e521e06b89c0be))
* **Instagram:** Added `Mark chat as read manually` patch ([1d267c8](https://github.com/crimera/piko/commit/1d267c8f67d1f7153e50a0166d327056e1643603))
* **Instagram:** Added ability to remove Piko preference ([3e29d69](https://github.com/crimera/piko/commit/3e29d69e0af53df4c0814bbd5e057ced196633c6))
* **instagram:** Disable swipe to create ([#1539](https://github.com/crimera/piko/issues/1539)) ([eaea2e9](https://github.com/crimera/piko/commit/eaea2e9db2db929409247c4a8b0ec865f13e087b))
* **Instagram:** Include debug option on thread long press ([c9df942](https://github.com/crimera/piko/commit/c9df9426377f62225c8ee63e0872563f99fd7d50))
* **instagram:** Material You theme ([#1509](https://github.com/crimera/piko/issues/1509)) ([9d97f59](https://github.com/crimera/piko/commit/9d97f590cd17e79c66a39deeedcb12a2f9f510f8))
* **Twitter - Native Downloader:** Add long-press to download all inline button ([f3d11e6](https://github.com/crimera/piko/commit/f3d11e653fd90176cdb2edc21d375447f63a4c39))
* **Twitter:** Add piko settings to the app icon long-press shortcut ([#1412](https://github.com/crimera/piko/issues/1412)) ([2eb970b](https://github.com/crimera/piko/commit/2eb970bfc7160256438fa854e5be0a0513c86877))
* **Twitter:** Add Search Piko settings ([#1516](https://github.com/crimera/piko/issues/1516)) ([fed4f51](https://github.com/crimera/piko/commit/fed4f51e3b88b4f7349af8c13a3ea61ecebb4c7c))
* **Twitter:** Added `Custom share menu` patch ([23f0a32](https://github.com/crimera/piko/commit/23f0a3237b57eea75443062ade78fc3be093fb33))
* **Twitter:** Added `External downloader` patch ([0e9a9f7](https://github.com/crimera/piko/commit/0e9a9f743364d1132d18d289a21e7e86c929f998))
* **Twitter:** Added `More information on profile` patch ([1167728](https://github.com/crimera/piko/commit/116772873059fe2b66b0708524a89cd90acac6e1))
* **Twitter:** Added new download dialog box ([9fca347](https://github.com/crimera/piko/commit/9fca347fc14da4d95c8c8a1a74fc691f1481077a))

### 🚀 Updated App Support

* **Twitter:** Bump support to `12.7.1-release.0` ([1d31338](https://github.com/crimera/piko/commit/1d313381d08afb0ba2f40f9f01673fa5cf5b6cce))

### 🔧 Improvements

* **Instagram:** Added inbox action bar customization ([7f0a219](https://github.com/crimera/piko/commit/7f0a219676976a8832744d889fe563129ea479bb))
* **Instagram:** Added more flags to improve the user experience ([#1443](https://github.com/crimera/piko/issues/1443)) ([d4835d2](https://github.com/crimera/piko/commit/d4835d26a358136777c6beccf299ab2268ecf709))
* **Instagram:** Added more story filters ([bab0fc6](https://github.com/crimera/piko/commit/bab0fc653d2ec9642ee608a0d57cd76380af944b))
* **Instagram:** Adjust DM section position on piko settings ([4646c7d](https://github.com/crimera/piko/commit/4646c7d24823f31ab530d2b2b85bfe74bae41db3))
* **Instagram:** Enhance story mention dialog box ([8d77056](https://github.com/crimera/piko/commit/8d7705684809cfa279ca0b517cecfc0911bcc54a))
* **Instagram:** Handle edge cases of comment button interaction ([fe847cb](https://github.com/crimera/piko/commit/fe847cbce8bc1fac1b324af9ac494b6d17a3ca19))
* **Instagram:** Improve action bar icon selection options ([a3b2b73](https://github.com/crimera/piko/commit/a3b2b7338659a978adba480595f9e96fc2b0d21f))
* **Instagram:** Include color friendship indicator ([48f5850](https://github.com/crimera/piko/commit/48f5850322a04c7dce982a1b4c61a9869d3635a2))
* **Instagram:** Include verification tick on story mention ([92b043b](https://github.com/crimera/piko/commit/92b043bb9a5d708f375bbaf4fe897407311d5bb5))
* **Instagram:** Move DM long press button check to java ([b2e4e71](https://github.com/crimera/piko/commit/b2e4e71e1e64fdeb06e0130271e8366d2fc4d200))
* **Instagram:** Remove unused preference ([232b4d6](https://github.com/crimera/piko/commit/232b4d6584750510088e4fe4e216534b8ce1ed86))
* **Instagram:** Story mention dialog width ([68b3c94](https://github.com/crimera/piko/commit/68b3c94f9efa7d6a7868dd63357e5c5a579d11c5))
* **Instagram:** Update download path handling and permissions ([#1500](https://github.com/crimera/piko/issues/1500)) ([76cdcb3](https://github.com/crimera/piko/commit/76cdcb3cfd62fa19cd79cdead1a3a2dd082585b2))
* **Twitter:** Introduce debug option and streamline About section buttons ([e64a7e0](https://github.com/crimera/piko/commit/e64a7e0a1978757b8c949971f3b0da1e5e4879ed))
* **Twitter:** Make the tweet-shots have rounded edges ([020589e](https://github.com/crimera/piko/commit/020589e5b1c3681396c7654f9d34604fbbc8f391))
* **Twitter:** Standardise share menu on click handling ([9aecb6b](https://github.com/crimera/piko/commit/9aecb6b68e71c70d3e4075afe2d311efd254f22c))

## [3.8.0-dev.6](https://github.com/crimera/piko/compare/v3.8.0-dev.5...v3.8.0-dev.6) (2026-07-23)

### 🐛 Bug Fixes

* **Instagram:** Match piko settings highlight to theme ([#1548](https://github.com/crimera/piko/issues/1548)) ([c428e7e](https://github.com/crimera/piko/commit/c428e7ea762cf2ec94e5e9a9f17ea207a976176f))
* **Instagram:** Match story mention dialog to Instagram theme ([#1554](https://github.com/crimera/piko/issues/1554)) ([08563ca](https://github.com/crimera/piko/commit/08563ca54d486585e5fc4bc7c432d6f5f19e6d28))
* **Instagram:** Restore and sync ghost action bar icons ([#1545](https://github.com/crimera/piko/issues/1545)) ([1240faf](https://github.com/crimera/piko/commit/1240faf55fa68867e9517bbd017e1cd1978cfa72))
* **Twitter - Native Downloader:** Add missing downloadAll method and fix null checks ([ba9d036](https://github.com/crimera/piko/commit/ba9d036e7e01a2455e291504ec4984c9b94cda94))
* **Twitter - Native Downloader:** Clean stale temp file before download and auto-retry legacy resolution if orig fails ([a9d9bd1](https://github.com/crimera/piko/commit/a9d9bd15f9895d723a3bb9eea1ea2d56cd6aa3e4))
* **Twitter - Settings:** Guard native downloader preferences and category by patch status ([d2ac7a0](https://github.com/crimera/piko/commit/d2ac7a08f9ac2679e7b3a1cb999f79e11fae2e76))
* **Twitter:** Apply custom sharing domain to copied links ([#1555](https://github.com/crimera/piko/issues/1555)) ([8e9bec8](https://github.com/crimera/piko/commit/8e9bec895638b5de3c585647496676915b610040))
* **Twitter:** Create category only if the patch is patched ([f3538a3](https://github.com/crimera/piko/commit/f3538a30d2c1d98a3c56e1fe0a7b5222b1ba35ae))

### ✨ New Features

* **instagram:** Material You theme ([#1509](https://github.com/crimera/piko/issues/1509)) ([9d97f59](https://github.com/crimera/piko/commit/9d97f590cd17e79c66a39deeedcb12a2f9f510f8))
* **Twitter - Native Downloader:** Add long-press to download all inline button ([f3d11e6](https://github.com/crimera/piko/commit/f3d11e653fd90176cdb2edc21d375447f63a4c39))

## [3.8.0-dev.5](https://github.com/crimera/piko/compare/v3.8.0-dev.4...v3.8.0-dev.5) (2026-07-19)

### 🐛 Bug Fixes

* **Instagram:** match piko settings background to amoled patch ([#1543](https://github.com/crimera/piko/issues/1543)) ([56003dc](https://github.com/crimera/piko/commit/56003dc4b68e6969e208570c45b583bcf709ceb3))
* **instagram:** preserve settings fragment on recreation ([#1546](https://github.com/crimera/piko/issues/1546)) ([f57ddcc](https://github.com/crimera/piko/commit/f57ddcc555dd487f57d959e5adc625f0f15ed80c))
* **instagram:** Refine piko settings title styling ([#1534](https://github.com/crimera/piko/issues/1534)) ([ce69be6](https://github.com/crimera/piko/commit/ce69be69e8aea7aee04bdf00db5a413bbb849b2f))
* **Instagram:** Refresh localized download folder path ([#1537](https://github.com/crimera/piko/issues/1537)) ([72ce666](https://github.com/crimera/piko/commit/72ce66602c601a2e1b600367bd04430419dadc59))
* **instagram:** restore native off switch colors ([#1533](https://github.com/crimera/piko/issues/1533)) ([71b0b00](https://github.com/crimera/piko/commit/71b0b007096756e1c801c14a1e8c21e2f7cada4a))
* **Twitter:** Fix high resolution image url ([5d07767](https://github.com/crimera/piko/commit/5d07767458b387c85448801851ab4d2de01caf12))
* **Twitter:** Fix inverted number round off ([c0a04aa](https://github.com/crimera/piko/commit/c0a04aac74604e690cacd8925c8bd9f4d13a4664))
* **Twitter:** Fix open supported links activity ([8a1db76](https://github.com/crimera/piko/commit/8a1db76b9c9109db02ee4278b5a6891e5cc2b246))

### ✨ New Features

* **instagram:** Disable swipe to create ([#1539](https://github.com/crimera/piko/issues/1539)) ([eaea2e9](https://github.com/crimera/piko/commit/eaea2e9db2db929409247c4a8b0ec865f13e087b))
* **Twitter:** Add Search Piko settings ([#1516](https://github.com/crimera/piko/issues/1516)) ([fed4f51](https://github.com/crimera/piko/commit/fed4f51e3b88b4f7349af8c13a3ea61ecebb4c7c))
* **Twitter:** Added new download dialog box ([9fca347](https://github.com/crimera/piko/commit/9fca347fc14da4d95c8c8a1a74fc691f1481077a))

## [3.8.0-dev.4](https://github.com/crimera/piko/compare/v3.8.0-dev.3...v3.8.0-dev.4) (2026-07-12)

### 🐛 Bug Fixes

* **Instagram:** Fix Piko settings color issues ([f1f278a](https://github.com/crimera/piko/commit/f1f278a87665be59218dcc54af983b411802fe0f))

### ✨ New Features

* **Instagram:** Added `Filter stories` patch ([c62d02a](https://github.com/crimera/piko/commit/c62d02adf1f0160f8bc72c4eb4e521e06b89c0be))
* **Instagram:** Added `Mark chat as read manually` patch ([1d267c8](https://github.com/crimera/piko/commit/1d267c8f67d1f7153e50a0166d327056e1643603))
* **Instagram:** Added ability to remove Piko preference ([3e29d69](https://github.com/crimera/piko/commit/3e29d69e0af53df4c0814bbd5e057ced196633c6))
* **Instagram:** Include debug option on thread long press ([c9df942](https://github.com/crimera/piko/commit/c9df9426377f62225c8ee63e0872563f99fd7d50))

### 🚀 Updated App Support

* **Twitter:** Bump support to `12.7.1-release.0` ([1d31338](https://github.com/crimera/piko/commit/1d313381d08afb0ba2f40f9f01673fa5cf5b6cce))

### 🔧 Improvements

* **Instagram:** Added more story filters ([bab0fc6](https://github.com/crimera/piko/commit/bab0fc653d2ec9642ee608a0d57cd76380af944b))
* **Instagram:** Adjust DM section position on piko settings ([4646c7d](https://github.com/crimera/piko/commit/4646c7d24823f31ab530d2b2b85bfe74bae41db3))
* **Instagram:** Move DM long press button check to java ([b2e4e71](https://github.com/crimera/piko/commit/b2e4e71e1e64fdeb06e0130271e8366d2fc4d200))
* **Instagram:** Remove unused preference ([232b4d6](https://github.com/crimera/piko/commit/232b4d6584750510088e4fe4e216534b8ce1ed86))
* **Instagram:** Update download path handling and permissions ([#1500](https://github.com/crimera/piko/issues/1500)) ([76cdcb3](https://github.com/crimera/piko/commit/76cdcb3cfd62fa19cd79cdead1a3a2dd082585b2))
* **Twitter:** Introduce debug option and streamline About section buttons ([e64a7e0](https://github.com/crimera/piko/commit/e64a7e0a1978757b8c949971f3b0da1e5e4879ed))
* **Twitter:** Make the tweet-shots have rounded edges ([020589e](https://github.com/crimera/piko/commit/020589e5b1c3681396c7654f9d34604fbbc8f391))

## [3.8.0-dev.3](https://github.com/crimera/piko/compare/v3.8.0-dev.2...v3.8.0-dev.3) (2026-07-05)

### 🐛 Bug Fixes

* **Instagram:** Fix chat action bar function name ([1401808](https://github.com/crimera/piko/commit/140180878895841fc8437dc21a39ab7941f79540))
* **Instagram:** Fix opening links ([ba9b4c4](https://github.com/crimera/piko/commit/ba9b4c43af6e4a42ce0654d11aa26a3d28496247))
* **twitter:** Handle bad response during tweet info API ([#1410](https://github.com/crimera/piko/issues/1410)) ([522f7d1](https://github.com/crimera/piko/commit/522f7d13e9f29bae854073a74c1d82cfe1874950))

### ✨ New Features

* **Twitter:** Add piko settings to the app icon long-press shortcut ([#1412](https://github.com/crimera/piko/issues/1412)) ([2eb970b](https://github.com/crimera/piko/commit/2eb970bfc7160256438fa854e5be0a0513c86877))
* **Twitter:** Added `More information on profile` patch ([1167728](https://github.com/crimera/piko/commit/116772873059fe2b66b0708524a89cd90acac6e1))

### 🔧 Improvements

* **Instagram:** Added inbox action bar customization ([7f0a219](https://github.com/crimera/piko/commit/7f0a219676976a8832744d889fe563129ea479bb))
* **Instagram:** Added more flags to improve the user experience ([#1443](https://github.com/crimera/piko/issues/1443)) ([d4835d2](https://github.com/crimera/piko/commit/d4835d26a358136777c6beccf299ab2268ecf709))
* **Instagram:** Enhance story mention dialog box ([8d77056](https://github.com/crimera/piko/commit/8d7705684809cfa279ca0b517cecfc0911bcc54a))
* **Instagram:** Handle edge cases of comment button interaction ([fe847cb](https://github.com/crimera/piko/commit/fe847cbce8bc1fac1b324af9ac494b6d17a3ca19))
* **Instagram:** Improve action bar icon selection options ([a3b2b73](https://github.com/crimera/piko/commit/a3b2b7338659a978adba480595f9e96fc2b0d21f))
* **Instagram:** Include color friendship indicator ([48f5850](https://github.com/crimera/piko/commit/48f5850322a04c7dce982a1b4c61a9869d3635a2))
* **Instagram:** Include verification tick on story mention ([92b043b](https://github.com/crimera/piko/commit/92b043bb9a5d708f375bbaf4fe897407311d5bb5))
* **Instagram:** Story mention dialog width ([68b3c94](https://github.com/crimera/piko/commit/68b3c94f9efa7d6a7868dd63357e5c5a579d11c5))

## [3.8.0-dev.2](https://github.com/crimera/piko/compare/v3.8.0-dev.1...v3.8.0-dev.2) (2026-06-28)

### 🐛 Bug Fixes

* **Twitter:** Tweet link pattern ([d2500ea](https://github.com/crimera/piko/commit/d2500ead98dd5bd77ba97f1ef2ac8388f7b559f0))

## [3.8.0-dev.1](https://github.com/crimera/piko/compare/v3.7.0...v3.8.0-dev.1) (2026-06-28)

### 🐛 Bug Fixes

* **Twitter:** Fix `Custom share menu` crash on image view ([f4d2e53](https://github.com/crimera/piko/commit/f4d2e53171621d02f2b04c0a0d4ff220e2e4c799))

### ✨ New Features

* **Twitter:** Added `Custom share menu` patch ([23f0a32](https://github.com/crimera/piko/commit/23f0a3237b57eea75443062ade78fc3be093fb33))
* **Twitter:** Added `External downloader` patch ([0e9a9f7](https://github.com/crimera/piko/commit/0e9a9f743364d1132d18d289a21e7e86c929f998))

### 🔧 Improvements

* **Twitter:** Standardise share menu on click handling ([9aecb6b](https://github.com/crimera/piko/commit/9aecb6b68e71c70d3e4075afe2d311efd254f22c))

## [3.7.0](https://github.com/crimera/piko/compare/v3.6.0...v3.7.0) (2026-06-27)

### 🐛 Bug Fixes

* **Instagram:** Fix `Allow user network certificate` being shown on Settings even without including ([2dc73cc](https://github.com/crimera/piko/commit/2dc73cc88caf6e44ddeff529a80c35d3e619e38b))
* **Instagram:** Fix `Change like animation` enum class injection issue ([626d556](https://github.com/crimera/piko/commit/626d556911295562f86d396851159738ab5c065b))
* **Instagram:** Fix `Disable typing status` on v435 ([e2a5693](https://github.com/crimera/piko/commit/e2a569363eec6dbf1180b8287ebbff4bfecde29e))
* **Instagram:** Fix `User profile action bar` logic ([252797f](https://github.com/crimera/piko/commit/252797fd30b3b7aac7e1ad03bee14c42ca2ed475))
* **Instagram:** Fix button press key check ([70862d4](https://github.com/crimera/piko/commit/70862d4b50ff4e0b159cadd8ba34dde97929326c))
* **Instagram:** Fix button press key check (again) ([d0e9933](https://github.com/crimera/piko/commit/d0e9933d96f519c5f4a3c96ea9bc628878c0024b))
* **Instagram:** Fix ghost eye icon position on DM action bar ([83661ff](https://github.com/crimera/piko/commit/83661ffc7760a98cd0d6e7e900392cf300b7156f))
* **Instagram:** Fix inverse issue of `Hide reshare button` ([85ad73f](https://github.com/crimera/piko/commit/85ad73fe1bc8b0c2968ec3a36e63d537e9bf2636))
* **Instagram:** Native comment buttons not working ([ea145d7](https://github.com/crimera/piko/commit/ea145d7759d3b7bf8af78cbab064fe76c6760cd5))
* **Instagram:** Remove blocking blok fixing your activity page issue ([6d4ce78](https://github.com/crimera/piko/commit/6d4ce78ae0d279bf4570a968258962a3ab47e714))
* **Instagram:** Show downloader package error on launch failure ([#1377](https://github.com/crimera/piko/issues/1377)) ([c39915e](https://github.com/crimera/piko/commit/c39915e7a2febc409f10227a729f72ff66cd7c6d))
* **Instagram:** Update chirp font patch string ([5b23848](https://github.com/crimera/piko/commit/5b23848d40286690b215f6923da6a45c1f4c5038))
* **Instagram:** Update eye icon ([e5b6e3d](https://github.com/crimera/piko/commit/e5b6e3dd78f838279e62e75572b774ca05562a72))

### ✨ New Features

* **Instagram:** Add Crowdin support ([#1327](https://github.com/crimera/piko/issues/1327)) ([f03659b](https://github.com/crimera/piko/commit/f03659b9ee459640bc6df04504dd085544196a52))
* **Instagram:** Added "friendship status" along with followback indicator ([6561341](https://github.com/crimera/piko/commit/656134104098ee2b1afc9530416629cc32ea6e8e))
* **Instagram:** Added support for downloading Image comments ([18c71da](https://github.com/crimera/piko/commit/18c71daae234a3c4353fa848a6c4c6a3ce1ddcb6))

### 🚀 Updated App Support

* **Instagram:** Bump support for `435.0.0.37.76` ([d53a75a](https://github.com/crimera/piko/commit/d53a75a22ab99e2dbeb647bbe428face2037b16b))
* **Twitter:** Bump support for `12.2.0-release.0` ([70865fe](https://github.com/crimera/piko/commit/70865fee9c1b10a1fef078e449e44f28aa55f2fb))

### 🔧 Improvements

* **Instagram:** added flags to improve the experience and more stable ([#1348](https://github.com/crimera/piko/issues/1348)) ([a585d21](https://github.com/crimera/piko/commit/a585d21cdc811030c55a8c00c5053d33543a2916))
* **Instagram:** Added icons to Piko settings ([4f4a070](https://github.com/crimera/piko/commit/4f4a07064fdaed0f29c0d3a8aef193783c48a411))
* **Instagram:** Added missing dependencies ([8cced1e](https://github.com/crimera/piko/commit/8cced1e3f04ac880d44149a5f71aae97696a4017))
* **Instagram:** Added patch info section on about ([a0394e8](https://github.com/crimera/piko/commit/a0394e863c6348bff7d7e3e84aef30cf554d122f))
* **Instagram:** Improve discover user blocking ([6c99846](https://github.com/crimera/piko/commit/6c99846d0f5cd4231f915185e0e526b1f9b1b678))
* **Instagram:** Improve flags to block `location consent` blok ([a4cf9b7](https://github.com/crimera/piko/commit/a4cf9b7aa1fc0466a645324a77b3e17fe0aadf2c))
* **Instagram:** Improve hook flags logic ([9a1f1cd](https://github.com/crimera/piko/commit/9a1f1cd177f008a8872742354e48daa27d828709))
* **Instagram:** invert ghost mode icons ([0af81ad](https://github.com/crimera/piko/commit/0af81ada0f252762e1cd774cec3a4fa71eaae54b))
* **Instagram:** Make Piko settings multi page ([cb5ef6a](https://github.com/crimera/piko/commit/cb5ef6a1710316a33c0c35db27c037154d8f6372))
* **Instagram:** Move debug export experiment list into Developer option section ([2567ed5](https://github.com/crimera/piko/commit/2567ed5060f86236f3b883d5930083b15bc31cc0))
* **Instagram:** Remove debug code ([7646088](https://github.com/crimera/piko/commit/764608824d033f8ab23cc35c19d25872c233d466))
* **Instagram:** Remove user action bar support temporarily ([8173c82](https://github.com/crimera/piko/commit/8173c82a9af0d935a7838922dab7eab67a0a576f))
* **Instagram:** Rename `Follow back indicator` to `Friendship status indicator` patch ([3a5e1ff](https://github.com/crimera/piko/commit/3a5e1ff53a3eaaba7cfa987d741a573970692e55))
* **Instagram:** Update "Friendship status" dialog ([b5b727a](https://github.com/crimera/piko/commit/b5b727a21211930182a4293f61288eea5b5ae655))
* **Instagram:** Update About section action bar title ([bed3146](https://github.com/crimera/piko/commit/bed31460256901c70ce7b89b0f4426f425f1872f))
* **Instagram:** Update fingerprints to support v423 ([56d73f6](https://github.com/crimera/piko/commit/56d73f6f1a66b4eb91baabe093562c85c8a6781c))
* **Instagram:** Update more fingerprints to support v423 ([1ef7d91](https://github.com/crimera/piko/commit/1ef7d912e51d2eeb617d4421caac9ccf4a653cc5))
* **Twitter:** Add version check for `Block redirecting to X Lite` ([b011267](https://github.com/crimera/piko/commit/b011267781e219c6b641e7dd6bf26a5e9225b331))
* **Twitter:** Added missing patch on patch info ([221fccb](https://github.com/crimera/piko/commit/221fccbf97dfbe62b80faaab2abe0162dc6bcbb8))
* **Twitter:** Update `Customize Navigation Bar items` fingerprint ([4b77b3d](https://github.com/crimera/piko/commit/4b77b3dc0e919d483d3754f350c88f8bbd6f5fd2))
* **Twitter:** Update Tweet user id extraction fingerprint ([2f573d2](https://github.com/crimera/piko/commit/2f573d2025e44728d95332b6e1bb0fea40a06aa4))

## [3.7.0-dev.9](https://github.com/crimera/piko/compare/v3.7.0-dev.8...v3.7.0-dev.9) (2026-06-26)

### 🐛 Bug Fixes

* **Instagram:** Native comment buttons not working ([ea145d7](https://github.com/crimera/piko/commit/ea145d7759d3b7bf8af78cbab064fe76c6760cd5))

## [3.7.0-dev.8](https://github.com/crimera/piko/compare/v3.7.0-dev.7...v3.7.0-dev.8) (2026-06-26)

### ✨ New Features

* **Instagram:** Added support for downloading Image comments ([18c71da](https://github.com/crimera/piko/commit/18c71daae234a3c4353fa848a6c4c6a3ce1ddcb6))

### 🔧 Improvements

* **Instagram:** Added missing dependencies ([8cced1e](https://github.com/crimera/piko/commit/8cced1e3f04ac880d44149a5f71aae97696a4017))
* **Instagram:** Update About section action bar title ([bed3146](https://github.com/crimera/piko/commit/bed31460256901c70ce7b89b0f4426f425f1872f))

## [3.7.0-dev.7](https://github.com/crimera/piko/compare/v3.7.0-dev.6...v3.7.0-dev.7) (2026-06-25)

### 🔧 Improvements

* **Instagram:** Remove debug code ([7646088](https://github.com/crimera/piko/commit/764608824d033f8ab23cc35c19d25872c233d466))

## [3.7.0-dev.6](https://github.com/crimera/piko/compare/v3.7.0-dev.5...v3.7.0-dev.6) (2026-06-25)

### 🐛 Bug Fixes

* **Instagram:** Fix `Allow user network certificate` being shown on Settings even without including ([2dc73cc](https://github.com/crimera/piko/commit/2dc73cc88caf6e44ddeff529a80c35d3e619e38b))
* **Instagram:** Fix `Disable typing status` on v435 ([e2a5693](https://github.com/crimera/piko/commit/e2a569363eec6dbf1180b8287ebbff4bfecde29e))
* **Instagram:** Fix `User profile action bar` logic ([252797f](https://github.com/crimera/piko/commit/252797fd30b3b7aac7e1ad03bee14c42ca2ed475))
* **Instagram:** Fix ghost eye icon position on DM action bar ([83661ff](https://github.com/crimera/piko/commit/83661ffc7760a98cd0d6e7e900392cf300b7156f))
* **Instagram:** Fix inverse issue of `Hide reshare button` ([85ad73f](https://github.com/crimera/piko/commit/85ad73fe1bc8b0c2968ec3a36e63d537e9bf2636))

### 🔧 Improvements

* **Instagram:** Improve discover user blocking ([6c99846](https://github.com/crimera/piko/commit/6c99846d0f5cd4231f915185e0e526b1f9b1b678))
* **Instagram:** Improve flags to block `location consent` blok ([a4cf9b7](https://github.com/crimera/piko/commit/a4cf9b7aa1fc0466a645324a77b3e17fe0aadf2c))
* **Instagram:** Improve hook flags logic ([9a1f1cd](https://github.com/crimera/piko/commit/9a1f1cd177f008a8872742354e48daa27d828709))
* **Instagram:** Move debug export experiment list into Developer option section ([2567ed5](https://github.com/crimera/piko/commit/2567ed5060f86236f3b883d5930083b15bc31cc0))

## [3.7.0-dev.5](https://github.com/crimera/piko/compare/v3.7.0-dev.4...v3.7.0-dev.5) (2026-06-24)

### 🔧 Improvements

* **Instagram:** Remove user action bar support temporarily ([8173c82](https://github.com/crimera/piko/commit/8173c82a9af0d935a7838922dab7eab67a0a576f))

## [3.7.0-dev.4](https://github.com/crimera/piko/compare/v3.7.0-dev.3...v3.7.0-dev.4) (2026-06-24)

### 🐛 Bug Fixes

* **Instagram:** Fix `Change like animation` enum class injection issue ([626d556](https://github.com/crimera/piko/commit/626d556911295562f86d396851159738ab5c065b))
* **Instagram:** Remove blocking blok fixing your activity page issue ([6d4ce78](https://github.com/crimera/piko/commit/6d4ce78ae0d279bf4570a968258962a3ab47e714))

### 🚀 Updated App Support

* **Instagram:** Bump support for `435.0.0.37.76` ([d53a75a](https://github.com/crimera/piko/commit/d53a75a22ab99e2dbeb647bbe428face2037b16b))
* **Twitter:** Bump support for `12.2.0-release.0` ([70865fe](https://github.com/crimera/piko/commit/70865fee9c1b10a1fef078e449e44f28aa55f2fb))

### 🔧 Improvements

* **Instagram:** Rename `Follow back indicator` to `Friendship status indicator` patch ([3a5e1ff](https://github.com/crimera/piko/commit/3a5e1ff53a3eaaba7cfa987d741a573970692e55))
* **Instagram:** Update fingerprints to support v423 ([56d73f6](https://github.com/crimera/piko/commit/56d73f6f1a66b4eb91baabe093562c85c8a6781c))
* **Instagram:** Update more fingerprints to support v423 ([1ef7d91](https://github.com/crimera/piko/commit/1ef7d912e51d2eeb617d4421caac9ccf4a653cc5))
* **Twitter:** Add version check for `Block redirecting to X Lite` ([b011267](https://github.com/crimera/piko/commit/b011267781e219c6b641e7dd6bf26a5e9225b331))
* **Twitter:** Update `Customize Navigation Bar items` fingerprint ([4b77b3d](https://github.com/crimera/piko/commit/4b77b3dc0e919d483d3754f350c88f8bbd6f5fd2))

## [3.7.0-dev.3](https://github.com/crimera/piko/compare/v3.7.0-dev.2...v3.7.0-dev.3) (2026-06-21)

### 🔧 Improvements

* **Instagram:** Update "Friendship status" dialog ([b5b727a](https://github.com/crimera/piko/commit/b5b727a21211930182a4293f61288eea5b5ae655))
* **Twitter:** Added missing patch on patch info ([221fccb](https://github.com/crimera/piko/commit/221fccbf97dfbe62b80faaab2abe0162dc6bcbb8))

## [3.7.0-dev.2](https://github.com/crimera/piko/compare/v3.7.0-dev.1...v3.7.0-dev.2) (2026-06-21)

### 🐛 Bug Fixes

* **Instagram:** Fix button press key check (again) ([d0e9933](https://github.com/crimera/piko/commit/d0e9933d96f519c5f4a3c96ea9bc628878c0024b))

### ✨ New Features

* **Instagram:** Added "friendship status" along with followback indicator ([6561341](https://github.com/crimera/piko/commit/656134104098ee2b1afc9530416629cc32ea6e8e))

## [3.7.0-dev.1](https://github.com/crimera/piko/compare/v3.6.0...v3.7.0-dev.1) (2026-06-21)

### 🐛 Bug Fixes

* **Instagram:** Fix button press key check ([70862d4](https://github.com/crimera/piko/commit/70862d4b50ff4e0b159cadd8ba34dde97929326c))
* **Instagram:** Show downloader package error on launch failure ([#1377](https://github.com/crimera/piko/issues/1377)) ([c39915e](https://github.com/crimera/piko/commit/c39915e7a2febc409f10227a729f72ff66cd7c6d))
* **Instagram:** Update chirp font patch string ([5b23848](https://github.com/crimera/piko/commit/5b23848d40286690b215f6923da6a45c1f4c5038))
* **Instagram:** Update eye icon ([e5b6e3d](https://github.com/crimera/piko/commit/e5b6e3dd78f838279e62e75572b774ca05562a72))

### ✨ New Features

* **Instagram:** Add Crowdin support ([#1327](https://github.com/crimera/piko/issues/1327)) ([f03659b](https://github.com/crimera/piko/commit/f03659b9ee459640bc6df04504dd085544196a52))

### 🔧 Improvements

* **Instagram:** added flags to improve the experience and more stable ([#1348](https://github.com/crimera/piko/issues/1348)) ([a585d21](https://github.com/crimera/piko/commit/a585d21cdc811030c55a8c00c5053d33543a2916))
* **Instagram:** Added icons to Piko settings ([4f4a070](https://github.com/crimera/piko/commit/4f4a07064fdaed0f29c0d3a8aef193783c48a411))
* **Instagram:** Added patch info section on about ([a0394e8](https://github.com/crimera/piko/commit/a0394e863c6348bff7d7e3e84aef30cf554d122f))
* **Instagram:** Make Piko settings multi page ([cb5ef6a](https://github.com/crimera/piko/commit/cb5ef6a1710316a33c0c35db27c037154d8f6372))
* **Twitter:** Update Tweet user id extraction fingerprint ([2f573d2](https://github.com/crimera/piko/commit/2f573d2025e44728d95332b6e1bb0fea40a06aa4))

## [3.6.0](https://github.com/crimera/piko/compare/v3.5.0...v3.6.0) (2026-06-18)

### 🐛 Bug Fixes

* **Twitter:** Fix links handling on modern share sheet ([bdffdd9](https://github.com/crimera/piko/commit/bdffdd9a923dea94fdb6404f88bd087cacf107c6))

### ✨ New Features

* **Twitter:** Added `Block redirecting to X Lite` patch ([68bb954](https://github.com/crimera/piko/commit/68bb954c6dc52943aab1537f8a32f472dd4aad14))
* **Twitter:** Added `Crash logs` ([ac41501](https://github.com/crimera/piko/commit/ac41501cdd4a1ca5247db8314bd4ed3f4b0e22c1))

### 🚀 Updated App Support

* **Twitter:** Add `11.99.0-release.1` to supported versions list (Requires Piko-Shim) ([#1367](https://github.com/crimera/piko/issues/1367)) ([ee10064](https://github.com/crimera/piko/commit/ee100646a0e8bea517252c76d19c325d43c88301))

### 🔧 Improvements

* **Instagram-Translations:** Added Bengali translation  ([#1352](https://github.com/crimera/piko/issues/1352)) ([ce48398](https://github.com/crimera/piko/commit/ce483984e0a3eb7c1bdb08909e4b85e097d25e3d))
* **Twitter:** Adjust `Handle custom twitter links` stringsOption and booleanOption ([a7f782f](https://github.com/crimera/piko/commit/a7f782fa7aaddd4a3f83d1e01b2131219a927e45))

## [3.6.0-dev.1](https://github.com/crimera/piko/compare/v3.5.1-dev.1...v3.6.0-dev.1) (2026-06-18)

### ✨ New Features

* **Twitter:** Added `Block redirecting to X Lite` patch ([68bb954](https://github.com/crimera/piko/commit/68bb954c6dc52943aab1537f8a32f472dd4aad14))

## [3.5.1-dev.1](https://github.com/crimera/piko/compare/v3.5.0...v3.5.1-dev.1) (2026-06-17)

### 🐛 Bug Fixes

* **Twitter:** Fix links handling on modern share sheet ([bdffdd9](https://github.com/crimera/piko/commit/bdffdd9a923dea94fdb6404f88bd087cacf107c6))

### 🔧 Improvements

* **Instagram-Translations:** Added Bengali translation  ([#1352](https://github.com/crimera/piko/issues/1352)) ([ce48398](https://github.com/crimera/piko/commit/ce483984e0a3eb7c1bdb08909e4b85e097d25e3d))
* **Twitter:** Adjust `Handle custom twitter links` stringsOption and booleanOption ([a7f782f](https://github.com/crimera/piko/commit/a7f782fa7aaddd4a3f83d1e01b2131219a927e45))

## [3.5.0](https://github.com/crimera/piko/compare/v3.4.0...v3.5.0) (2026-06-16)

### 🐛 Bug Fixes

* **Instagram:** Check if `More options on profile` is patched before adding the button ([a8cfbab](https://github.com/crimera/piko/commit/a8cfbab17d75e3c52f0b39ba0d1ec2b8fa8fbf61))
* **Instagram:** Correction to make post time work ([#1338](https://github.com/crimera/piko/issues/1338)) ([b30e1ae](https://github.com/crimera/piko/commit/b30e1aea621d3edb5093255e6a334ec273ab80cf))
* **Instagram:** Fix audio extraction logic ([579f559](https://github.com/crimera/piko/commit/579f55951d5cf84af2d23d9cb2f3fac369ff74d2))
* **Instagram:** Fix crash on clicking mentions ([7896cf3](https://github.com/crimera/piko/commit/7896cf3f91b182e9628ccb7a55794e359e0bec9c))
* **Instagram:** Fix crashing on profile issue ([ff0676f](https://github.com/crimera/piko/commit/ff0676f6e0654038892061f69d44fda7eeea6a7d))
* **Instagram:** Fix current media index on more options on post ([bb416c1](https://github.com/crimera/piko/commit/bb416c12884485e080c448ee273c390fd70fafe1))
* **Instagram:** fix downloading dp into sub folder ([6a78dc5](https://github.com/crimera/piko/commit/6a78dc5b12d3f1832e01353b12d939b8e8693325))
* **Instagram:** Fix ImmutablePandoVideoVersion error while downloading some videos ([dc5dc4e](https://github.com/crimera/piko/commit/dc5dc4e7c7349e8561b3d6710c58cbd5a072f44b))
* **Instagram:** Fix lower resolution image downloading ([45f8aa0](https://github.com/crimera/piko/commit/45f8aa07a3f7ca636d6f4f17e1d96998e20b89ef))
* **Instagram:** Fix navigation buttons not hiding after selecting them ([9bbad36](https://github.com/crimera/piko/commit/9bbad36ef0783abf04d986e764a8b6a964b4372f))
* **Instagram:** Fix null userdata from mediadata ([ef8fb7e](https://github.com/crimera/piko/commit/ef8fb7ee09bf744183bb87302e8d36215a873023))
* **Instagram:** Fix persistent downloading notification after completion ([905828d](https://github.com/crimera/piko/commit/905828dd465b9b0aa0afc489bbf624acd8a3faa4))
* **Instagram:** Fix spilt username folder issue ([b2931c0](https://github.com/crimera/piko/commit/b2931c0ac5ed6a84efa830cd91ee2bb975848da6))
* **Instagram:** Hide navigation buttons crashing on tablets ([e5b0ddb](https://github.com/crimera/piko/commit/e5b0ddb4b8f612b279f464a99535094d979e906f))
* **Instagram:** String description ([45b5063](https://github.com/crimera/piko/commit/45b50630563dbe98aba6c774c3c831b1842f3c4a))
* **Twitter - Customize Navigation Bar items:** May not work on 11.95.0-alpha.0+ ([d4c5f4e](https://github.com/crimera/piko/commit/d4c5f4e29f633fbdbad9310ce3a45a2600a8814a))
* **Twitter - Customize Navigation Bar items:** Sometimes the order of navigation buttons is reset ([4790d6c](https://github.com/crimera/piko/commit/4790d6c2f2611463a9b8a54081bf4defcddb4bb2))
* **Twitter:** Some patches failed on 11.97.1-release.0+ ([293b16f](https://github.com/crimera/piko/commit/293b16f17edc71d6ad0bc90dc39a7d82d5a38de4))

### ✨ New Features

* Added support for custom downloader ([344d71f](https://github.com/crimera/piko/commit/344d71f04925336d7cc1f30fec423fb005f606f1))
* Added support for setting custom download path ([1ad2017](https://github.com/crimera/piko/commit/1ad2017e68a1ee190a740801653bea41de958d57))
* **Instagram:** Add `Clone` patch ([#1295](https://github.com/crimera/piko/issues/1295)) ([a6b1fe1](https://github.com/crimera/piko/commit/a6b1fe11f817b94c7c6e6d70b56df9394335d5f8))
* **Instagram:** Added `Download voice message` patch ([1ebf75c](https://github.com/crimera/piko/commit/1ebf75c2288af120a75bc52dcb0f6a89ed7ea2c8))
* **Instagram:** Added `External downloader` patch ([5d00775](https://github.com/crimera/piko/commit/5d007751b6ed834c1bc65ef478fa47187b8c7cdd))
* **Instagram:** Added `Save media comment` patch ([b756d4b](https://github.com/crimera/piko/commit/b756d4bb9dad139d8d996a373e5d98acca855d2e))
* **Instagram:** Added `Validate links` patch ([af31db7](https://github.com/crimera/piko/commit/af31db7b1ecbe5559a7ea8dc684d74819a771777))
* **Instagram:** Added ability to download video variants ([2baeea8](https://github.com/crimera/piko/commit/2baeea81698d843408c140f29e6d69ce86e2d748))
* **Instagram:** Added ability to turn on all ghost modes ([6a1c497](https://github.com/crimera/piko/commit/6a1c497d8e9ff761fd9e0e7ea93034b9465d549b))
* **Instagram:** Added alert if the mapping file is missing ([dc9b4c2](https://github.com/crimera/piko/commit/dc9b4c2ce682974c3b8fa2df3ef4ed5f01737ba5))
* **Instagram:** Added custom exception handler and crash logs ([b119727](https://github.com/crimera/piko/commit/b1197279845cad3f1d98f318ed86c144f764194d))
* **Instagram:** Added image variants download option ([5aca4b4](https://github.com/crimera/piko/commit/5aca4b44efe461bebaea397316649f6c5897f076))
* **Instagram:** Move profile more options button to action bar ([068ba4f](https://github.com/crimera/piko/commit/068ba4f5e32073ab52c983910b7a776d3d6bfd0c))
* **Instagram:** Move settings launcher to main feed action bar ([3ed88ed](https://github.com/crimera/piko/commit/3ed88ede87285c20532dc174b3cf4e4774dedc18))
* **Instagram:** Refine Piko settings UI ([#1310](https://github.com/crimera/piko/issues/1310)) ([dd76ee4](https://github.com/crimera/piko/commit/dd76ee4f1a31c8c7810f3247e92ee31894e72f6a))
* **Translations-Instagram:** Added Spanish translation ([#1288](https://github.com/crimera/piko/issues/1288)) ([023eef8](https://github.com/crimera/piko/commit/023eef8339afa9069173381da280052e72e59f73))
* **Twitter:** Add compatibility check patch to handle exceptions ([d46c253](https://github.com/crimera/piko/commit/d46c25343c6dc73a60379e8283c8a067c2075799))

### 🚀 Updated App Support

* **Instagram:** Bump support for `430.0.0.53.80` ([60a0c1a](https://github.com/crimera/piko/commit/60a0c1a80b38397f95b82d1eb51c053feabb27fa))
* **Twitter:** Added support for 11.93.xx ([dd7352c](https://github.com/crimera/piko/commit/dd7352cd9485a7af6d32a62b09410d65fd4567d2))
* **Twitter:** Bump support for `11.95.1-release.0` ([1e12f66](https://github.com/crimera/piko/commit/1e12f66bb86462bddff28f15620ab5cc7e767c97))
* **Twitter:** Bump support for `11.99.0-release.1` ([b9c578f](https://github.com/crimera/piko/commit/b9c578fabbc9bddaf0cbb30d77bbac2879ebc7f0))
* **Twitter:** Bump support for `12.0.0-release.0` ([ee7e7df](https://github.com/crimera/piko/commit/ee7e7dfd7da515b5e896139799a21a9ea814b55c))

### 🔧 Improvements

* Include patch version on crash logs ([a0f3ec0](https://github.com/crimera/piko/commit/a0f3ec02e0131dee3c8f43879a5c89b4244e67f9))
* **Instagram:**  Customise story ring size - Clarify standard size in the setting ([#1265](https://github.com/crimera/piko/issues/1265)) ([d30a32e](https://github.com/crimera/piko/commit/d30a32e163117b317b25d9eed7a53ff645f92fbe))
* **Instagram:** Added a new timestamp customization option ([#1312](https://github.com/crimera/piko/issues/1312)) ([2a82ac4](https://github.com/crimera/piko/commit/2a82ac4dc430984f34d89194565a12964d512657))
* **Instagram:** Added alternative logic for video variants ([45bf91f](https://github.com/crimera/piko/commit/45bf91ff0ea31930224bae777d7114d7777eb852))
* **Instagram:** Added Debug option for comments & improved comment button loading ([2c827ed](https://github.com/crimera/piko/commit/2c827ede209e99e3b00cd34ee6e3517144547c6f))
* **Instagram:** Added download story options to self stories ([9382ee0](https://github.com/crimera/piko/commit/9382ee050fe39457ec58b6efa4a9103f2cf0a946))
* **Instagram:** Added option to switch profile action between action bar and as button ([bf4f4d5](https://github.com/crimera/piko/commit/bf4f4d5498da66ead398b79bb970702325213482))
* **Instagram:** Fix crashing on clicking overflow menu button ([dee8831](https://github.com/crimera/piko/commit/dee8831cc36786a5fee9d751f3270238f82830c6))
* **Instagram:** Improve `Disable screenshot detection` patch ([b15a697](https://github.com/crimera/piko/commit/b15a6971198332f5e52fb486a97d5110142205cd))
* **Instagram:** Improve `Hide reshare button` patch fingerprint ([d22764b](https://github.com/crimera/piko/commit/d22764b6ae59c507298dbd0fb683be0ffac3fe88))
* **Instagram:** Improve profile info entity extractor ([1eae27e](https://github.com/crimera/piko/commit/1eae27e77dad179b88f1279ca6599b9d576dce33))
* **Instagram:** Improve View story mentions logic ([3a38492](https://github.com/crimera/piko/commit/3a3849259bea1d247f6cbfdb5be072ffe92ec9ac))
* **Instagram:** Make piko settings on action bar optional ([3b45655](https://github.com/crimera/piko/commit/3b456555e59c76b98f974f7e58a5c31a97658774))
* **Instagram:** Moved ghost mode toggle to DM action bar ([1d0c9b5](https://github.com/crimera/piko/commit/1d0c9b5fe4e96369ef80b4575f72fce7b14ad0c6))
* **Instagram:** Override flags that trigger new overflow menu ([1b645bb](https://github.com/crimera/piko/commit/1b645bb13da653895a60a3c73079960d4d4db7ec))
* **Instagram:** Potential fix for location blok due to analytics ([87c6195](https://github.com/crimera/piko/commit/87c61958b0c103a81b9a4f95bf18c1979c0a37a7))
* **Instagram:** refactor post overflow menu button on click ([2e55b54](https://github.com/crimera/piko/commit/2e55b54e1af223a78113b18c29ac7f0056fecd5e))
* **Instagram:** Streamline post overflow menu button ([8209a77](https://github.com/crimera/piko/commit/8209a778781a7de73ba838363810de8462e3f19f))
* **Instagram:** Streamline reels overflow menu button ([50bbef3](https://github.com/crimera/piko/commit/50bbef36bfbd3f76836d35a89a429d32c58f28ae))
* **Instagram:** Update `More options on post` description and button attributes ([e1d185a](https://github.com/crimera/piko/commit/e1d185a651a579bfa8543996df2831ca9bee97fe))
* **Instagram:** Updated `Hide stories tray` patch ([3acbcb5](https://github.com/crimera/piko/commit/3acbcb51ccc6383ef07224f216dd65f352dec670))
* **Instagram:** Updated `Hide suggested content` patch ([c122e6f](https://github.com/crimera/piko/commit/c122e6fd3319ea1e9972b6707f4a9a3860ba11ea))
* **Instagram:** Updated user data entity fingerprints ([de2f9d5](https://github.com/crimera/piko/commit/de2f9d56379d60dffe8f3ac7ddcf2ceaa780c7c1))
* **Instagram:** Warn when external downloader package is unset ([#1333](https://github.com/crimera/piko/issues/1333)) ([898178e](https://github.com/crimera/piko/commit/898178e510b6304dc0dcd6c4afc5c870e329348d))
* **Twitter:** Added `Priority tab` to hide notification tabs list ([c83f603](https://github.com/crimera/piko/commit/c83f603da2e14b9f864900f2d95a86cd985dc730))
* **Twitter:** Added version check for various patches ([6db66b5](https://github.com/crimera/piko/commit/6db66b523b4623762fb5c645343e5b7493024101))
* **Twitter:** Improve share menu enum logic for newer versions ([0cd809e](https://github.com/crimera/piko/commit/0cd809e979ccdca8c4ddcd195dc9831ac2c1a983))
* **Twitter:** Make Force Pip option independent of undo option in piko settings ([074489f](https://github.com/crimera/piko/commit/074489f2d27a7a1e3d120b9f956d4e96a4169ee4))
* **Twitter:** Make unofficial instance links optional for deeplinks ([6dea26b](https://github.com/crimera/piko/commit/6dea26b5435e68068d71adc5d727eefda8273a91))
* **Twitter:** replace dynamic string composition with explicit string resources ([#845](https://github.com/crimera/piko/issues/845)) ([49a7c01](https://github.com/crimera/piko/commit/49a7c018c389135fa8a8e3368514b4e339450522))
* **Twitter:** Update `Customize profile tabs` fingerprint ([da9333e](https://github.com/crimera/piko/commit/da9333e2bf2dfaacbe21ee48a6d5c498869c7218))
* **Twitter:** Update check mappings logic ([457ee93](https://github.com/crimera/piko/commit/457ee9333e91479d25e3bf72c4ada4c1978d8d24))

## [3.5.0-dev.8](https://github.com/crimera/piko/compare/v3.5.0-dev.7...v3.5.0-dev.8) (2026-06-16)

### 🐛 Bug Fixes

* **Instagram:** Correction to make post time work ([#1338](https://github.com/crimera/piko/issues/1338)) ([b30e1ae](https://github.com/crimera/piko/commit/b30e1aea621d3edb5093255e6a334ec273ab80cf))
* **Instagram:** Fix navigation buttons not hiding after selecting them ([9bbad36](https://github.com/crimera/piko/commit/9bbad36ef0783abf04d986e764a8b6a964b4372f))

### 🔧 Improvements

* Include patch version on crash logs ([a0f3ec0](https://github.com/crimera/piko/commit/a0f3ec02e0131dee3c8f43879a5c89b4244e67f9))
* **Instagram:** Fix crashing on clicking overflow menu button ([dee8831](https://github.com/crimera/piko/commit/dee8831cc36786a5fee9d751f3270238f82830c6))
* **Instagram:** Override flags that trigger new overflow menu ([1b645bb](https://github.com/crimera/piko/commit/1b645bb13da653895a60a3c73079960d4d4db7ec))
* **Instagram:** Update `More options on post` description and button attributes ([e1d185a](https://github.com/crimera/piko/commit/e1d185a651a579bfa8543996df2831ca9bee97fe))
* **Instagram:** Warn when external downloader package is unset ([#1333](https://github.com/crimera/piko/issues/1333)) ([898178e](https://github.com/crimera/piko/commit/898178e510b6304dc0dcd6c4afc5c870e329348d))

## [3.5.0-dev.7](https://github.com/crimera/piko/compare/v3.5.0-dev.6...v3.5.0-dev.7) (2026-06-14)

### 🐛 Bug Fixes

* **Instagram:** Fix ImmutablePandoVideoVersion error while downloading some videos ([dc5dc4e](https://github.com/crimera/piko/commit/dc5dc4e7c7349e8561b3d6710c58cbd5a072f44b))
* **Instagram:** Fix lower resolution image downloading ([45f8aa0](https://github.com/crimera/piko/commit/45f8aa07a3f7ca636d6f4f17e1d96998e20b89ef))
* **Instagram:** Fix null userdata from mediadata ([ef8fb7e](https://github.com/crimera/piko/commit/ef8fb7ee09bf744183bb87302e8d36215a873023))
* **Instagram:** Hide navigation buttons crashing on tablets ([e5b0ddb](https://github.com/crimera/piko/commit/e5b0ddb4b8f612b279f464a99535094d979e906f))
* **Twitter:** Some patches failed on 11.97.1-release.0+ ([293b16f](https://github.com/crimera/piko/commit/293b16f17edc71d6ad0bc90dc39a7d82d5a38de4))

### ✨ New Features

* **Instagram:** Add `Clone` patch ([#1295](https://github.com/crimera/piko/issues/1295)) ([a6b1fe1](https://github.com/crimera/piko/commit/a6b1fe11f817b94c7c6e6d70b56df9394335d5f8))
* **Instagram:** Added `External downloader` patch ([5d00775](https://github.com/crimera/piko/commit/5d007751b6ed834c1bc65ef478fa47187b8c7cdd))
* **Instagram:** Refine Piko settings UI ([#1310](https://github.com/crimera/piko/issues/1310)) ([dd76ee4](https://github.com/crimera/piko/commit/dd76ee4f1a31c8c7810f3247e92ee31894e72f6a))
* **Translations-Instagram:** Added Spanish translation ([#1288](https://github.com/crimera/piko/issues/1288)) ([023eef8](https://github.com/crimera/piko/commit/023eef8339afa9069173381da280052e72e59f73))
* **Twitter:** Add compatibility check patch to handle exceptions ([d46c253](https://github.com/crimera/piko/commit/d46c25343c6dc73a60379e8283c8a067c2075799))

### 🚀 Updated App Support

* **Twitter:** Bump support for `11.99.0-release.1` ([b9c578f](https://github.com/crimera/piko/commit/b9c578fabbc9bddaf0cbb30d77bbac2879ebc7f0))

### 🔧 Improvements

* **Instagram:** Added a new timestamp customization option ([#1312](https://github.com/crimera/piko/issues/1312)) ([2a82ac4](https://github.com/crimera/piko/commit/2a82ac4dc430984f34d89194565a12964d512657))
* **Instagram:** refactor post overflow menu button on click ([2e55b54](https://github.com/crimera/piko/commit/2e55b54e1af223a78113b18c29ac7f0056fecd5e))
* **Instagram:** Streamline post overflow menu button ([8209a77](https://github.com/crimera/piko/commit/8209a778781a7de73ba838363810de8462e3f19f))
* **Instagram:** Streamline reels overflow menu button ([50bbef3](https://github.com/crimera/piko/commit/50bbef36bfbd3f76836d35a89a429d32c58f28ae))

## [3.5.0-dev.6](https://github.com/crimera/piko/compare/v3.5.0-dev.5...v3.5.0-dev.6) (2026-06-08)

### 🐛 Bug Fixes

* **Instagram:** Check if `More options on profile` is patched before adding the button ([a8cfbab](https://github.com/crimera/piko/commit/a8cfbab17d75e3c52f0b39ba0d1ec2b8fa8fbf61))

### ✨ New Features

* **Instagram:** Added `Save media comment` patch ([b756d4b](https://github.com/crimera/piko/commit/b756d4bb9dad139d8d996a373e5d98acca855d2e))
* **Instagram:** Added image variants download option ([5aca4b4](https://github.com/crimera/piko/commit/5aca4b44efe461bebaea397316649f6c5897f076))

### 🔧 Improvements

* **Instagram:**  Customise story ring size - Clarify standard size in the setting ([#1265](https://github.com/crimera/piko/issues/1265)) ([d30a32e](https://github.com/crimera/piko/commit/d30a32e163117b317b25d9eed7a53ff645f92fbe))
* **Instagram:** Added alternative logic for video variants ([45bf91f](https://github.com/crimera/piko/commit/45bf91ff0ea31930224bae777d7114d7777eb852))
* **Instagram:** Added Debug option for comments & improved comment button loading ([2c827ed](https://github.com/crimera/piko/commit/2c827ede209e99e3b00cd34ee6e3517144547c6f))
* **Twitter:** Make unofficial instance links optional for deeplinks ([6dea26b](https://github.com/crimera/piko/commit/6dea26b5435e68068d71adc5d727eefda8273a91))

## [3.5.0-dev.5](https://github.com/crimera/piko/compare/v3.5.0-dev.4...v3.5.0-dev.5) (2026-06-05)

### 🐛 Bug Fixes

* **Instagram:** Fix crashing on profile issue ([ff0676f](https://github.com/crimera/piko/commit/ff0676f6e0654038892061f69d44fda7eeea6a7d))
* **Instagram:** fix downloading dp into sub folder ([6a78dc5](https://github.com/crimera/piko/commit/6a78dc5b12d3f1832e01353b12d939b8e8693325))
* **Instagram:** Fix persistent downloading notification after completion ([905828d](https://github.com/crimera/piko/commit/905828dd465b9b0aa0afc489bbf624acd8a3faa4))

### 🔧 Improvements

* **Instagram:** Improve `Disable screenshot detection` patch ([b15a697](https://github.com/crimera/piko/commit/b15a6971198332f5e52fb486a97d5110142205cd))

## [3.5.0-dev.4](https://github.com/crimera/piko/compare/v3.5.0-dev.3...v3.5.0-dev.4) (2026-05-31)

### 🔧 Improvements

* **Twitter:** Update check mappings logic ([457ee93](https://github.com/crimera/piko/commit/457ee9333e91479d25e3bf72c4ada4c1978d8d24))

## [3.5.0-dev.3](https://github.com/crimera/piko/compare/v3.5.0-dev.2...v3.5.0-dev.3) (2026-05-31)

### 🐛 Bug Fixes

* **Instagram:** Fix crash on clicking mentions ([7896cf3](https://github.com/crimera/piko/commit/7896cf3f91b182e9628ccb7a55794e359e0bec9c))
* **Instagram:** Fix current media index on more options on post ([bb416c1](https://github.com/crimera/piko/commit/bb416c12884485e080c448ee273c390fd70fafe1))
* **Instagram:** Fix spilt username folder issue ([b2931c0](https://github.com/crimera/piko/commit/b2931c0ac5ed6a84efa830cd91ee2bb975848da6))
* **Twitter - Customize Navigation Bar items:** May not work on 11.95.0-alpha.0+ ([d4c5f4e](https://github.com/crimera/piko/commit/d4c5f4e29f633fbdbad9310ce3a45a2600a8814a))
* **Twitter - Customize Navigation Bar items:** Sometimes the order of navigation buttons is reset ([4790d6c](https://github.com/crimera/piko/commit/4790d6c2f2611463a9b8a54081bf4defcddb4bb2))

### ✨ New Features

* **Instagram:** Added `Validate links` patch ([af31db7](https://github.com/crimera/piko/commit/af31db7b1ecbe5559a7ea8dc684d74819a771777))
* **Instagram:** Added alert if the mapping file is missing ([dc9b4c2](https://github.com/crimera/piko/commit/dc9b4c2ce682974c3b8fa2df3ef4ed5f01737ba5))
* **Instagram:** Added custom exception handler and crash logs ([b119727](https://github.com/crimera/piko/commit/b1197279845cad3f1d98f318ed86c144f764194d))

### 🚀 Updated App Support

* **Twitter:** Bump support for `11.95.1-release.0` ([1e12f66](https://github.com/crimera/piko/commit/1e12f66bb86462bddff28f15620ab5cc7e767c97))

### 🔧 Improvements

* **Instagram:** Added download story options to self stories ([9382ee0](https://github.com/crimera/piko/commit/9382ee050fe39457ec58b6efa4a9103f2cf0a946))
* **Instagram:** Added option to switch profile action between action bar and as button ([bf4f4d5](https://github.com/crimera/piko/commit/bf4f4d5498da66ead398b79bb970702325213482))
* **Instagram:** Make piko settings on action bar optional ([3b45655](https://github.com/crimera/piko/commit/3b456555e59c76b98f974f7e58a5c31a97658774))
* **Instagram:** Moved ghost mode toggle to DM action bar ([1d0c9b5](https://github.com/crimera/piko/commit/1d0c9b5fe4e96369ef80b4575f72fce7b14ad0c6))
* **Instagram:** Potential fix for location blok due to analytics ([87c6195](https://github.com/crimera/piko/commit/87c61958b0c103a81b9a4f95bf18c1979c0a37a7))
* **Twitter:** Added `Priority tab` to hide notification tabs list ([c83f603](https://github.com/crimera/piko/commit/c83f603da2e14b9f864900f2d95a86cd985dc730))
* **Twitter:** Update `Customize profile tabs` fingerprint ([da9333e](https://github.com/crimera/piko/commit/da9333e2bf2dfaacbe21ee48a6d5c498869c7218))

## [3.5.0-dev.2](https://github.com/crimera/piko/compare/v3.5.0-dev.1...v3.5.0-dev.2) (2026-05-27)

### 🔧 Improvements

* **Twitter:** replace dynamic string composition with explicit string resources ([#845](https://github.com/crimera/piko/issues/845)) ([49a7c01](https://github.com/crimera/piko/commit/49a7c018c389135fa8a8e3368514b4e339450522))

## [3.5.0-dev.1](https://github.com/crimera/piko/compare/v3.4.1-dev.1...v3.5.0-dev.1) (2026-05-23)

### 🐛 Bug Fixes

* **Instagram:** Fix audio extraction logic ([579f559](https://github.com/crimera/piko/commit/579f55951d5cf84af2d23d9cb2f3fac369ff74d2))

### ✨ New Features

* Added support for custom downloader ([344d71f](https://github.com/crimera/piko/commit/344d71f04925336d7cc1f30fec423fb005f606f1))
* Added support for setting custom download path ([1ad2017](https://github.com/crimera/piko/commit/1ad2017e68a1ee190a740801653bea41de958d57))
* **Instagram:** Added `Download voice message` patch ([1ebf75c](https://github.com/crimera/piko/commit/1ebf75c2288af120a75bc52dcb0f6a89ed7ea2c8))
* **Instagram:** Added ability to download video variants ([2baeea8](https://github.com/crimera/piko/commit/2baeea81698d843408c140f29e6d69ce86e2d748))
* **Instagram:** Added ability to turn on all ghost modes ([6a1c497](https://github.com/crimera/piko/commit/6a1c497d8e9ff761fd9e0e7ea93034b9465d549b))
* **Instagram:** Move profile more options button to action bar ([068ba4f](https://github.com/crimera/piko/commit/068ba4f5e32073ab52c983910b7a776d3d6bfd0c))
* **Instagram:** Move settings launcher to main feed action bar ([3ed88ed](https://github.com/crimera/piko/commit/3ed88ede87285c20532dc174b3cf4e4774dedc18))

### 🚀 Updated App Support

* **Instagram:** Bump support for `430.0.0.53.80` ([60a0c1a](https://github.com/crimera/piko/commit/60a0c1a80b38397f95b82d1eb51c053feabb27fa))

### 🔧 Improvements

* **Instagram:** Improve `Hide reshare button` patch fingerprint ([d22764b](https://github.com/crimera/piko/commit/d22764b6ae59c507298dbd0fb683be0ffac3fe88))
* **Instagram:** Improve profile info entity extractor ([1eae27e](https://github.com/crimera/piko/commit/1eae27e77dad179b88f1279ca6599b9d576dce33))
* **Instagram:** Improve View story mentions logic ([3a38492](https://github.com/crimera/piko/commit/3a3849259bea1d247f6cbfdb5be072ffe92ec9ac))
* **Instagram:** Updated `Hide stories tray` patch ([3acbcb5](https://github.com/crimera/piko/commit/3acbcb51ccc6383ef07224f216dd65f352dec670))
* **Instagram:** Updated `Hide suggested content` patch ([c122e6f](https://github.com/crimera/piko/commit/c122e6fd3319ea1e9972b6707f4a9a3860ba11ea))
* **Instagram:** Updated user data entity fingerprints ([de2f9d5](https://github.com/crimera/piko/commit/de2f9d56379d60dffe8f3ac7ddcf2ceaa780c7c1))

## [3.4.1-dev.1](https://github.com/crimera/piko/compare/v3.4.0...v3.4.1-dev.1) (2026-05-22)

### 🐛 Bug Fixes

* **Instagram:** String description ([45b5063](https://github.com/crimera/piko/commit/45b50630563dbe98aba6c774c3c831b1842f3c4a))

### 🚀 Updated App Support

* **Twitter:** Added support for 11.93.xx ([dd7352c](https://github.com/crimera/piko/commit/dd7352cd9485a7af6d32a62b09410d65fd4567d2))

### 🔧 Improvements

* **Twitter:** Added version check for various patches ([6db66b5](https://github.com/crimera/piko/commit/6db66b523b4623762fb5c645343e5b7493024101))
* **Twitter:** Improve share menu enum logic for newer versions ([0cd809e](https://github.com/crimera/piko/commit/0cd809e979ccdca8c4ddcd195dc9831ac2c1a983))

## [3.4.0](https://github.com/crimera/piko/compare/v3.3.0...v3.4.0) (2026-05-19)

### 🐛 Bug Fixes

* **Twitter:** Added warning during `Disunify xchat system` patch failure ([2035e4c](https://github.com/crimera/piko/commit/2035e4c5f1febcc64959074665c51d28fc7c0cde))

### ✨ New Features

* **Instagram - Translations:** Added `Japanese` Translation ([#1143](https://github.com/crimera/piko/issues/1143)) ([07e62c1](https://github.com/crimera/piko/commit/07e62c1636724a4afa70aad27df17a8fb67ae42c))
* **Instagram - Translations:** Added `Portuguese` Translation ([#1145](https://github.com/crimera/piko/issues/1145)) ([8d36aaf](https://github.com/crimera/piko/commit/8d36aaf263eb8339f12a403fd3ac2889bfce7d0b))
* **Twitter:** Partial support to 11.91.xx ([6dbca75](https://github.com/crimera/piko/commit/6dbca754d3cfa0cd7aa9826c261b197f534a82f4))

## [3.4.0-dev.2](https://github.com/crimera/piko/compare/v3.4.0-dev.1...v3.4.0-dev.2) (2026-05-17)

### 🐛 Bug Fixes

* **Twitter:** Added warning during `Disunify xchat system` patch failure ([2035e4c](https://github.com/crimera/piko/commit/2035e4c5f1febcc64959074665c51d28fc7c0cde))

### ✨ New Features

* **Instagram - Translations:** Added `Japanese` Translation ([#1143](https://github.com/crimera/piko/issues/1143)) ([07e62c1](https://github.com/crimera/piko/commit/07e62c1636724a4afa70aad27df17a8fb67ae42c))
* **Instagram - Translations:** Added `Portuguese` Translation ([#1145](https://github.com/crimera/piko/issues/1145)) ([8d36aaf](https://github.com/crimera/piko/commit/8d36aaf263eb8339f12a403fd3ac2889bfce7d0b))

# [3.4.0-dev.1](https://github.com/crimera/piko/compare/v3.3.0...v3.4.0-dev.1) (2026-05-16)


### Features

* **Twitter:** Partial support to 11.91.xx ([6dbca75](https://github.com/crimera/piko/commit/6dbca754d3cfa0cd7aa9826c261b197f534a82f4))

# [3.3.0](https://github.com/crimera/piko/compare/v3.2.0...v3.3.0) (2026-05-12)


### Bug Fixes

* fallback instruction address ([95f69e3](https://github.com/crimera/piko/commit/95f69e3fef4774072bb82b2717d9ba44ed8e0487))
* **instagram/entity:** check-cast Object arg before IgdsButton.setStyle ([7f7b605](https://github.com/crimera/piko/commit/7f7b605de6d0e36a23d4413c6876f7e48b16e5c3))
* **instagram/story:** declare StoryButton.storyButtonAction static ([24d435e](https://github.com/crimera/piko/commit/24d435eb15e9598912af101bfd161372801d9143))
* **instagram/story:** pair long arg with consecutive /range register in emitted invoke ([d65b339](https://github.com/crimera/piko/commit/d65b339b0d01705a2b5b837b3e7b6f601a73e742))
* **Instagram:** download all carousel media ([2f93f78](https://github.com/crimera/piko/commit/2f93f786eb25b6186b0a2657b6eb75b52a405f33))
* **Instagram:** Fix `Change like animation` patch ([a9dacb2](https://github.com/crimera/piko/commit/a9dacb2a15bc7a502d3931f0fb8ec5e13bc05d61))
* **Instagram:** fix `Follow back indicator` patch ([ef6dfdf](https://github.com/crimera/piko/commit/ef6dfdfec9d1a89d5289c26f1b942f2f7da757ad))
* **Instagram:** Fix `Make ephemeral media permanent` patch ([fc22c94](https://github.com/crimera/piko/commit/fc22c94eb323fbc5ce12591e4a06c2dd4e590a88))
* **Instagram:** Fix flag hooks loading ([a673853](https://github.com/crimera/piko/commit/a673853a8dae600a58dad3144f11310fe4e28475))
* **Instagram:** Fix hooks flag (for trigger) ([a3a6c3d](https://github.com/crimera/piko/commit/a3a6c3d1b9a08f755f12fe46f3b5944e96e708e8))
* **Instagram:** keep one navigation button visible ([dd5dce8](https://github.com/crimera/piko/commit/dd5dce8f8974df4e47ff3eb32057ca8ca0cd9c25))
* **Instagram:** Override flags to fix certain issues ([07c6313](https://github.com/crimera/piko/commit/07c63138482048709618c172bfd8a7a3843d30f2))
* **Instagram:** Potential fix for A16-A17 ([b3352b4](https://github.com/crimera/piko/commit/b3352b481c0af9c59f587bceb0e1b6f50472437f))
* **Twitter - Import/Export login token:** Add import menu to piko settings as a workaround for redesigned login screen ([dad823c](https://github.com/crimera/piko/commit/dad823c3d4a7fa88d5e98cc8b24146fcfb5c5758))


### Features

* **Instagram:** Add `Disable Reels scrolling` patch ([9a03ca1](https://github.com/crimera/piko/commit/9a03ca1ed1ec529489dcca73cb8b7fb314ea198b))
* **instagram:** add amoled theme patch ([f34ea47](https://github.com/crimera/piko/commit/f34ea473d3a63b6afd35f573bb88d7aad1178813)), closes [#ff000000](https://github.com/crimera/piko/issues/ff000000) [#ff0c1014](https://github.com/crimera/piko/issues/ff0c1014) [#000000](https://github.com/crimera/piko/issues/000000)
* **Instagram:** Added `Change like animation` patch ([cb759bc](https://github.com/crimera/piko/commit/cb759bcab2e754a794a907846e077a956416e363))
* **Instagram:** Added `Copy comment` patch ([eb3f378](https://github.com/crimera/piko/commit/eb3f378a2e29ad60560cb6ccc0f05ab9eca44aae))
* **Instagram:** Added `Customise story ring size` patch ([cfe8a55](https://github.com/crimera/piko/commit/cfe8a55423e2e1f53dbc769beb082644d1bc3689))
* **Instagram:** Added `Disable double tap like` patch ([daa8474](https://github.com/crimera/piko/commit/daa84741cb05f1d7bd4af63dfe3458125a7df5c5))
* **Instagram:** Added `Disable highlights` patch ([03f367e](https://github.com/crimera/piko/commit/03f367eb1a371b46e1425028a861d44886ecd906))
* **Instagram:** Added `Disable screenshot detection` patch ([a1141c9](https://github.com/crimera/piko/commit/a1141c9af37bfac52a06c2ea86a1b9c72b2de8b0))
* **Instagram:** Added `Disable video autoplay` patch ([9294e08](https://github.com/crimera/piko/commit/9294e08699c8e996140a8cd84f345819eee96dab))
* **Instagram:** Added `Enable whitehat settings` patch ([31529bb](https://github.com/crimera/piko/commit/31529bb0a2c90a700dc99b54f9302377ca29f91e))
* **Instagram:** Added `Hide notes tray` patch ([a856398](https://github.com/crimera/piko/commit/a8563984fe465ae8cc8e7e1a0d3b129ae343ca81))
* **Instagram:** Added `Improve image viewing` patch ([d716354](https://github.com/crimera/piko/commit/d7163541f0678bf532d137e2147572975d925638))
* **Instagram:** Added `More options on post` patch ([19db767](https://github.com/crimera/piko/commit/19db767dbeb00d9d5cd46552ba2bd425753eef2e))
* **Instagram:** Added `More options on profile` patch ([1cd5797](https://github.com/crimera/piko/commit/1cd5797d945b7ecbdaa295b1a426302784546975))
* **Instagram:** Added `Remove empty bottom space` patch ([2b0eb1f](https://github.com/crimera/piko/commit/2b0eb1fa94cfc8c5d6b7d713a8080c351fa25d66))
* **Instagram:** Added `Stories audio autoplay` patch ([f514dcf](https://github.com/crimera/piko/commit/f514dcf35bd77fe318103741c95adf5f7ccfcff6))
* **Instagram:** Added `Unlock employee options` patch ([6041c06](https://github.com/crimera/piko/commit/6041c06875ba7e879f2fbd07a49f8596af1368bb))
* **Instagram:** Added `Unlock Plus benefits` patch ([84d9fd6](https://github.com/crimera/piko/commit/84d9fd62e12d103a833e386c90504b97a4652744))
* **Instagram:** Added ability to download audio from some posts and reel ([8d503d3](https://github.com/crimera/piko/commit/8d503d3ecffd66949779acb5cc24480e75f06f91))
* **Instagram:** Added ability to download mappings ([ee843af](https://github.com/crimera/piko/commit/ee843af511c656e3a6ce4fa86102459ff80392e0))
* **Instagram:** Added debug option to extraction developer options codes ([313e15c](https://github.com/crimera/piko/commit/313e15c74be4f0c389ecebce8447fcdfc455c95e))
* **Instagram:** Added hook to override developer flags ([01e43a6](https://github.com/crimera/piko/commit/01e43a6f206af4692f3545adf8680f77f855dddc))
* **Instagram:** Added one time welcome message on launch ([6d03daa](https://github.com/crimera/piko/commit/6d03daa1dba71482d373f726f67d359e8958dfcb))
* **Instagram:** Added support to `425.0.0.47.61` ([f02ede0](https://github.com/crimera/piko/commit/f02ede0ee1f8444dfae5580c4dcee63d49bb3d5e))
* **Instagram:** Added support to `426.0.0.37.68` ([dce5983](https://github.com/crimera/piko/commit/dce598300cb6af1cad291e4b820bd7ce6e441b9a))
* **Instagram:** Initial support for translations ([caf8ffb](https://github.com/crimera/piko/commit/caf8ffb7704ae514a3b5f98ae265878214d42ae5))
* Read DMs anonymously ([48f1593](https://github.com/crimera/piko/commit/48f1593e303f00cb4fb1e14233ac51d03f273ae3))
* **Translations-Instagram:** Added `Indonesian` translations ([4a77dcb](https://github.com/crimera/piko/commit/4a77dcb64b3747b04535999b0809908f93cc39d6))
* **Translations-Instagram:** Added `Polish` translation ([#1089](https://github.com/crimera/piko/issues/1089)) ([99ccf20](https://github.com/crimera/piko/commit/99ccf20e3f88d39be9c4ea1b2d248479bfe790ba))
* **Translations-Instagram:** Added `Russian` translations ([b8b951b](https://github.com/crimera/piko/commit/b8b951b14267aaafb8193c65553dd6ea3cdbce3f))
* **Translations-Instagram:** Added `Turkish` translations ([#1103](https://github.com/crimera/piko/issues/1103)) ([6f03170](https://github.com/crimera/piko/commit/6f03170d88b4f9fc2c156838cbafc792246496fa))

# [3.3.0-dev.8](https://github.com/crimera/piko/compare/v3.3.0-dev.7...v3.3.0-dev.8) (2026-05-11)


### Features

* **Translations-Instagram:** Added `Turkish` translations ([#1103](https://github.com/crimera/piko/issues/1103)) ([6f03170](https://github.com/crimera/piko/commit/6f03170d88b4f9fc2c156838cbafc792246496fa))

# [3.3.0-dev.7](https://github.com/crimera/piko/compare/v3.3.0-dev.6...v3.3.0-dev.7) (2026-05-09)


### Features

* **Instagram:** Added ability to download mappings ([ee843af](https://github.com/crimera/piko/commit/ee843af511c656e3a6ce4fa86102459ff80392e0))
* **Instagram:** Added one time welcome message on launch ([6d03daa](https://github.com/crimera/piko/commit/6d03daa1dba71482d373f726f67d359e8958dfcb))
* **Translations-Instagram:** Added `Indonesian` translations ([4a77dcb](https://github.com/crimera/piko/commit/4a77dcb64b3747b04535999b0809908f93cc39d6))
* **Translations-Instagram:** Added `Polish` translation ([#1089](https://github.com/crimera/piko/issues/1089)) ([99ccf20](https://github.com/crimera/piko/commit/99ccf20e3f88d39be9c4ea1b2d248479bfe790ba))
* **Translations-Instagram:** Added `Russian` translations ([b8b951b](https://github.com/crimera/piko/commit/b8b951b14267aaafb8193c65553dd6ea3cdbce3f))

# [3.3.0-dev.6](https://github.com/crimera/piko/compare/v3.3.0-dev.5...v3.3.0-dev.6) (2026-05-06)


### Bug Fixes

* **Instagram:** Fix hooks flag (for trigger) ([a3a6c3d](https://github.com/crimera/piko/commit/a3a6c3d1b9a08f755f12fe46f3b5944e96e708e8))

# [3.3.0-dev.5](https://github.com/crimera/piko/compare/v3.3.0-dev.4...v3.3.0-dev.5) (2026-05-06)


### Bug Fixes

* **Instagram:** Potential fix for A16-A17 ([b3352b4](https://github.com/crimera/piko/commit/b3352b481c0af9c59f587bceb0e1b6f50472437f))

# [3.3.0-dev.4](https://github.com/crimera/piko/compare/v3.3.0-dev.3...v3.3.0-dev.4) (2026-05-05)


### Bug Fixes

* **Instagram:** Fix `Change like animation` patch ([a9dacb2](https://github.com/crimera/piko/commit/a9dacb2a15bc7a502d3931f0fb8ec5e13bc05d61))
* **Instagram:** Fix flag hooks loading ([a673853](https://github.com/crimera/piko/commit/a673853a8dae600a58dad3144f11310fe4e28475))
* **Instagram:** Override flags to fix certain issues ([07c6313](https://github.com/crimera/piko/commit/07c63138482048709618c172bfd8a7a3843d30f2))


### Features

* **Instagram:** Added `Disable double tap like` patch ([daa8474](https://github.com/crimera/piko/commit/daa84741cb05f1d7bd4af63dfe3458125a7df5c5))
* **Instagram:** Added `Enable whitehat settings` patch ([31529bb](https://github.com/crimera/piko/commit/31529bb0a2c90a700dc99b54f9302377ca29f91e))
* **Instagram:** Added `More options on post` patch ([19db767](https://github.com/crimera/piko/commit/19db767dbeb00d9d5cd46552ba2bd425753eef2e))
* **Instagram:** Added `Unlock employee options` patch ([6041c06](https://github.com/crimera/piko/commit/6041c06875ba7e879f2fbd07a49f8596af1368bb))
* **Instagram:** Added hook to override developer flags ([01e43a6](https://github.com/crimera/piko/commit/01e43a6f206af4692f3545adf8680f77f855dddc))
* **Instagram:** Initial support for translations ([caf8ffb](https://github.com/crimera/piko/commit/caf8ffb7704ae514a3b5f98ae265878214d42ae5))

# [3.3.0-dev.3](https://github.com/crimera/piko/compare/v3.3.0-dev.2...v3.3.0-dev.3) (2026-04-26)


### Bug Fixes

* **Instagram:** Fix `Make ephemeral media permanent` patch ([fc22c94](https://github.com/crimera/piko/commit/fc22c94eb323fbc5ce12591e4a06c2dd4e590a88))


### Features

* **Instagram:** Added `Change like animation` patch ([cb759bc](https://github.com/crimera/piko/commit/cb759bcab2e754a794a907846e077a956416e363))
* **Instagram:** Added `Customise story ring size` patch ([cfe8a55](https://github.com/crimera/piko/commit/cfe8a55423e2e1f53dbc769beb082644d1bc3689))
* **Instagram:** Added `Unlock Plus benefits` patch ([84d9fd6](https://github.com/crimera/piko/commit/84d9fd62e12d103a833e386c90504b97a4652744))

# [3.3.0-dev.2](https://github.com/crimera/piko/compare/v3.3.0-dev.1...v3.3.0-dev.2) (2026-04-23)


### Bug Fixes

* **instagram/entity:** check-cast Object arg before IgdsButton.setStyle ([7f7b605](https://github.com/crimera/piko/commit/7f7b605de6d0e36a23d4413c6876f7e48b16e5c3))
* **instagram/story:** declare StoryButton.storyButtonAction static ([24d435e](https://github.com/crimera/piko/commit/24d435eb15e9598912af101bfd161372801d9143))
* **instagram/story:** pair long arg with consecutive /range register in emitted invoke ([d65b339](https://github.com/crimera/piko/commit/d65b339b0d01705a2b5b837b3e7b6f601a73e742))
* **Instagram:** fix `Follow back indicator` patch ([ef6dfdf](https://github.com/crimera/piko/commit/ef6dfdfec9d1a89d5289c26f1b942f2f7da757ad))


### Features

* **instagram:** add amoled theme patch ([f34ea47](https://github.com/crimera/piko/commit/f34ea473d3a63b6afd35f573bb88d7aad1178813)), closes [#ff000000](https://github.com/crimera/piko/issues/ff000000) [#ff0c1014](https://github.com/crimera/piko/issues/ff0c1014) [#000000](https://github.com/crimera/piko/issues/000000)
* **Instagram:** Added `Disable highlights` patch ([03f367e](https://github.com/crimera/piko/commit/03f367eb1a371b46e1425028a861d44886ecd906))
* **Instagram:** Added `Disable video autoplay` patch ([9294e08](https://github.com/crimera/piko/commit/9294e08699c8e996140a8cd84f345819eee96dab))
* **Instagram:** Added `Stories audio autoplay` patch ([f514dcf](https://github.com/crimera/piko/commit/f514dcf35bd77fe318103741c95adf5f7ccfcff6))
* **Instagram:** Added ability to download audio from some posts and reel ([8d503d3](https://github.com/crimera/piko/commit/8d503d3ecffd66949779acb5cc24480e75f06f91))
* **Instagram:** Added debug option to extraction developer options codes ([313e15c](https://github.com/crimera/piko/commit/313e15c74be4f0c389ecebce8447fcdfc455c95e))
* **Instagram:** Added support to `425.0.0.47.61` ([f02ede0](https://github.com/crimera/piko/commit/f02ede0ee1f8444dfae5580c4dcee63d49bb3d5e))
* **Instagram:** Added support to `426.0.0.37.68` ([dce5983](https://github.com/crimera/piko/commit/dce598300cb6af1cad291e4b820bd7ce6e441b9a))

# [3.3.0-dev.1](https://github.com/crimera/piko/compare/v3.2.0...v3.3.0-dev.1) (2026-04-19)


### Bug Fixes

* fallback instruction address ([95f69e3](https://github.com/crimera/piko/commit/95f69e3fef4774072bb82b2717d9ba44ed8e0487))
* **Instagram:** download all carousel media ([2f93f78](https://github.com/crimera/piko/commit/2f93f786eb25b6186b0a2657b6eb75b52a405f33))
* **Instagram:** keep one navigation button visible ([dd5dce8](https://github.com/crimera/piko/commit/dd5dce8f8974df4e47ff3eb32057ca8ca0cd9c25))
* **Twitter - Import/Export login token:** Add import menu to piko settings as a workaround for redesigned login screen ([dad823c](https://github.com/crimera/piko/commit/dad823c3d4a7fa88d5e98cc8b24146fcfb5c5758))


### Features

* **Instagram:** Add `Disable Reels scrolling` patch ([9a03ca1](https://github.com/crimera/piko/commit/9a03ca1ed1ec529489dcca73cb8b7fb314ea198b))
* **Instagram:** Added `Copy comment` patch ([eb3f378](https://github.com/crimera/piko/commit/eb3f378a2e29ad60560cb6ccc0f05ab9eca44aae))
* **Instagram:** Added `Disable screenshot detection` patch ([a1141c9](https://github.com/crimera/piko/commit/a1141c9af37bfac52a06c2ea86a1b9c72b2de8b0))
* **Instagram:** Added `Hide notes tray` patch ([a856398](https://github.com/crimera/piko/commit/a8563984fe465ae8cc8e7e1a0d3b129ae343ca81))
* **Instagram:** Added `Improve image viewing` patch ([d716354](https://github.com/crimera/piko/commit/d7163541f0678bf532d137e2147572975d925638))
* **Instagram:** Added `More options on profile` patch ([1cd5797](https://github.com/crimera/piko/commit/1cd5797d945b7ecbdaa295b1a426302784546975))
* **Instagram:** Added `Remove empty bottom space` patch ([2b0eb1f](https://github.com/crimera/piko/commit/2b0eb1fa94cfc8c5d6b7d713a8080c351fa25d66))
* Read DMs anonymously ([48f1593](https://github.com/crimera/piko/commit/48f1593e303f00cb4fb1e14233ac51d03f273ae3))

# [3.2.0](https://github.com/crimera/piko/compare/v3.1.0...v3.2.0) (2026-04-10)


### Bug Fixes

* **Instagram:** `Download media` fingerprint ([e161d4e](https://github.com/crimera/piko/commit/e161d4ed0eafb3a7d802c1ac3d20ed176ede797d))
* **Instagram:** `Hide suggested content` patch fingerprint ([fdb7a1f](https://github.com/crimera/piko/commit/fdb7a1fc72287a9d509c749b3a9bb58e4a8633ea))
* **Instagram:** `Remove build expired popup` patch yet again ([33378d1](https://github.com/crimera/piko/commit/33378d13a7aff3c52160190c1d474884c205df78))
* **Instagram:** `Sanitize share links` patch fingerprint ([339d6b0](https://github.com/crimera/piko/commit/339d6b0f58245af830c72ef89f27d87ac3aa3f92))
* **Instagram:** fix `Improve image viewing` patch ([5655756](https://github.com/crimera/piko/commit/5655756526bbad2588db7fefcb0641d1470aa251))
* **Instagram:** fix `Media` fingerprints again ([1fdaa80](https://github.com/crimera/piko/commit/1fdaa80a8761fdc25f5ee33e61860fd800dcf2c3))
* **Instagram:** Fix `Open links externally` patch ([b5aa5da](https://github.com/crimera/piko/commit/b5aa5da0bbf860ec3108bce45b51e401e848d36f))
* **Instagram:** Fix `Remove build expired popup` patch ([1235af4](https://github.com/crimera/piko/commit/1235af4aac05c939ce5ff84ca570f2dced3e4e24))
* **Instagram:** fix Download media - author and media type ([95c7a73](https://github.com/crimera/piko/commit/95c7a732479b5954b7793826c37d8e64a4bbc821))
* **Instagram:** fix Download option on feed ([4f4c07f](https://github.com/crimera/piko/commit/4f4c07fcd64c3bcb513dc59b184d7e3e3cde5bb2))
* **Instagram:** Fix feed download button method fingerprint ([dc1b97e](https://github.com/crimera/piko/commit/dc1b97ebf1afd5ca03a4de403ec3a9e84144052b))
* **Instagram:** Fix fingerprint of Feed button on click ([9f988e2](https://github.com/crimera/piko/commit/9f988e269e205609b2122675f88a09862b0d2e2c))
* **Instagram:** Fix fingerprints broken on 423 ([3859ba4](https://github.com/crimera/piko/commit/3859ba4da669dfb0dbfd23ab66fa3c9354f84199))
* **Instagram:** Fix Friendship status fingerprints broken on 423 ([0f42aaf](https://github.com/crimera/piko/commit/0f42aaf4e6d818db4a40b83ace1bbe6ca126abf9))
* **Instagram:** Fix friendship status method fingerprint ([276048e](https://github.com/crimera/piko/commit/276048e0e6ffc31d531096748b1243d1c7500aca))
* **Instagram:** fix padding issue in Piko settings button ([4855f38](https://github.com/crimera/piko/commit/4855f38410ed6999e3d501cb0301efee4490a148))
* **Instagram:** Fix piko settings action bar ([1712146](https://github.com/crimera/piko/commit/17121469f71b0c71953f70b2cf6dc09ab920b78a))
* **Instagram:** fix Piko settings issues ([d3369f2](https://github.com/crimera/piko/commit/d3369f2aa594737bbf73ef86bb8b3001e17c4327))
* **Instagram:** fix piko settings nav bar clipping ([0b94452](https://github.com/crimera/piko/commit/0b94452310b8d3630142d8b9b3715b4bbea012d9))
* **Instagram:** Fix story button method fingerprint ([ba7b16d](https://github.com/crimera/piko/commit/ba7b16d599eabb43400f6cb5a8162a8f056c29b6))
* **Instagram:** Fixed sanitize post and reels urls ([61257fb](https://github.com/crimera/piko/commit/61257fbd601e69b3c507b5da22b687439890c873))
* **Instagram:** Follow indicator handling ([ad3ed3f](https://github.com/crimera/piko/commit/ad3ed3fd0576c17cf409a69c2703ed0484c0fac0))
* **Twitter:** Fix `Customize notification tabs` patch in 11.81 ([fa81d84](https://github.com/crimera/piko/commit/fa81d844096ce7a941df12a6301ff48c2f489582))
* **Twitter:** Fix `Customize notification tabs` patch on 11.78.xx ([05958d2](https://github.com/crimera/piko/commit/05958d2de69935b2a9de1550f06eeed4e2debaee))
* **Twitter:** Fix `Log server response` patch on 11.77.xx ([c2111f1](https://github.com/crimera/piko/commit/c2111f1fd166107eefc436c38f320bd1db33a905))
* **Twitter:** Fix GIFs downloading as image via native downloader ([d18317a](https://github.com/crimera/piko/commit/d18317a4f7b7e013765143f33d34807e3764a063))


### Features

* Add `Import/Export login token` patch ([5667e4c](https://github.com/crimera/piko/commit/5667e4cd251685a01d9459a2c637a79a832259b6))
* **Bring back twitter:** Use strings from Twitter 9.98.0 for all languages ([ebcfb9a](https://github.com/crimera/piko/commit/ebcfb9ae7bdbb8f3648b4191ee7c448ee4f6c90a))
* **Instagram:** Add `Hide navigation buttons` patch ([948f136](https://github.com/crimera/piko/commit/948f1362b298668c8ec960f2801bb1b2c7807a04))
* **Instagram:** Add `Hide reshare button` patch ([84ad6ae](https://github.com/crimera/piko/commit/84ad6ae7b4f3112a2175b1360c113c9a71b1ff9b))
* **Instagram:** Added `Customise story timestamp` patch ([421ca76](https://github.com/crimera/piko/commit/421ca76dfa2f67b77bafed5c477c1e24f50657a4))
* **Instagram:** Added `Disable ads` patch ([4046078](https://github.com/crimera/piko/commit/40460788ac473f32f2dbee9735b691e0086d3b31))
* **Instagram:** Added `Disable analytics` patch ([e01da66](https://github.com/crimera/piko/commit/e01da663b520a00b386016cfc00d733a3b39ec70))
* **Instagram:** Added `Disable discover people` patch ([36fbfb5](https://github.com/crimera/piko/commit/36fbfb53f48996c977507c675c8ca4cc426f387b))
* **Instagram:** Added `Disable story flipping` patch ([05f374b](https://github.com/crimera/piko/commit/05f374b4fbe54e8bd8cc165545c6d7e7d01848a7))
* **Instagram:** Added `Distraction free` patches ([ec3ae44](https://github.com/crimera/piko/commit/ec3ae44a0fbfe95515e5250d7e366fcbf88eb8a3))
* **Instagram:** Added `Download media` patch ([b87f023](https://github.com/crimera/piko/commit/b87f02368f26185cf6881d68d63f91830ff46fe8))
* **Instagram:** Added `Follow back indicator` patch ([e6974a1](https://github.com/crimera/piko/commit/e6974a14f23cc549ff1330e3fce125ddee930e15))
* **Instagram:** Added `Hide group creation button on sharesheet` patch ([8faab8c](https://github.com/crimera/piko/commit/8faab8cd984e2dede46aa9ed0355b7c63e2d0535))
* **Instagram:** Added `Hide stories tray` patch ([c4af4df](https://github.com/crimera/piko/commit/c4af4df649762d0b4f1409849edd7fa6626ca3c7))
* **Instagram:** Added `Hide suggested content` patch ([2a10346](https://github.com/crimera/piko/commit/2a10346a3ff680e0ebda33fb2cff547de46457fe))
* **Instagram:** Added `Improve image viewing` patch ([72d103d](https://github.com/crimera/piko/commit/72d103da8c059e2751fdb54c968995a669b1612f))
* **Instagram:** Added `Open links externally` patch ([d199468](https://github.com/crimera/piko/commit/d1994683fac5e9734e4287c424f25205e21de80f))
* **Instagram:** Added `Remove build expired popup` patch ([8932242](https://github.com/crimera/piko/commit/89322421eb2d1f0fbd0e6c2b937e23cd987005ec))
* **Instagram:** Added `Sanitize share links` patch ([43a886f](https://github.com/crimera/piko/commit/43a886ffa801476d57a14a40fd149fc09ec7aa9a))
* **Instagram:** Added `Unlimited replays on ephemeral media` patch ([00e3656](https://github.com/crimera/piko/commit/00e3656db467efd5fbca9de9884716fe75faa188))
* **Instagram:** Added `View live anonymously` patch ([d5c6fb3](https://github.com/crimera/piko/commit/d5c6fb3dc87288eb3429a898d132b55c98609091))
* **Instagram:** Added `View stories anonymously` patch ([2fab876](https://github.com/crimera/piko/commit/2fab8765622b41e7e11cfb57493bd09b788eee27))
* **Instagram:** Added `View story mentions` patch ([ebddfbe](https://github.com/crimera/piko/commit/ebddfbeb46ec781ddcabc7956ca9a40645f5cb18))
* **Instagram:** Added delete analytics cache folder ([f1a1602](https://github.com/crimera/piko/commit/f1a16029c2d0951a77dbad5dff0735abc3fb4d47))
* **Instagram:** Added mapping restore ([6691e56](https://github.com/crimera/piko/commit/6691e565722877aca516a8b6bf531fab667574af))
* **Instagram:** Added open media externally ([9d0b1eb](https://github.com/crimera/piko/commit/9d0b1ebd6d71eb3db43123f9b8577f29c75fb223))
* **Instagram:** Added override backup ([9b9498a](https://github.com/crimera/piko/commit/9b9498abf51c75b24578470d473076eb35421990))
* **Instagram:** Added override restore ([7d433b2](https://github.com/crimera/piko/commit/7d433b2c39a2e8eb9c70324582d9704a7c7889b5))
* **Instagram:** Added patch information in settings ([90f1885](https://github.com/crimera/piko/commit/90f1885dc65d0a1670d751fe25367ffd711f992e))
* **Instagram:** Added settings and developer options patch ([859c684](https://github.com/crimera/piko/commit/859c6847ee2e45f33812c66201e3fd9f8a96689c))
* **Instagram:** handle signature check on link share and on incoming link ([7698274](https://github.com/crimera/piko/commit/76982744b7adcc8cac5470586af9d27bad9a01c6))
* **Twitter:** Added `Backup and restore` section ([4d894f4](https://github.com/crimera/piko/commit/4d894f4686feb1bf3c2e2973b8fe3e986e1af22c))

# [3.2.0-dev.5](https://github.com/crimera/piko/compare/v3.2.0-dev.4...v3.2.0-dev.5) (2026-04-09)


### Bug Fixes

* **Twitter:** Fix `Customize notification tabs` patch in 11.81 ([fa81d84](https://github.com/crimera/piko/commit/fa81d844096ce7a941df12a6301ff48c2f489582))

# [3.2.0-dev.4](https://github.com/crimera/piko/compare/v3.2.0-dev.3...v3.2.0-dev.4) (2026-04-08)


### Bug Fixes

* **Instagram:** fix `Improve image viewing` patch ([5655756](https://github.com/crimera/piko/commit/5655756526bbad2588db7fefcb0641d1470aa251))
* **Instagram:** fix padding issue in Piko settings button ([4855f38](https://github.com/crimera/piko/commit/4855f38410ed6999e3d501cb0301efee4490a148))
* **Instagram:** fix Piko settings issues ([d3369f2](https://github.com/crimera/piko/commit/d3369f2aa594737bbf73ef86bb8b3001e17c4327))
* **Instagram:** fix piko settings nav bar clipping ([0b94452](https://github.com/crimera/piko/commit/0b94452310b8d3630142d8b9b3715b4bbea012d9))


### Features

* **Instagram:** Add `Hide navigation buttons` patch ([948f136](https://github.com/crimera/piko/commit/948f1362b298668c8ec960f2801bb1b2c7807a04))
* **Instagram:** Add `Hide reshare button` patch ([84ad6ae](https://github.com/crimera/piko/commit/84ad6ae7b4f3112a2175b1360c113c9a71b1ff9b))
* **Instagram:** Added `Hide group creation button on sharesheet` patch ([8faab8c](https://github.com/crimera/piko/commit/8faab8cd984e2dede46aa9ed0355b7c63e2d0535))
* **Instagram:** Added `Improve image viewing` patch ([72d103d](https://github.com/crimera/piko/commit/72d103da8c059e2751fdb54c968995a669b1612f))
* **Instagram:** Added open media externally ([9d0b1eb](https://github.com/crimera/piko/commit/9d0b1ebd6d71eb3db43123f9b8577f29c75fb223))

# [3.2.0-dev.3](https://github.com/crimera/piko/compare/v3.2.0-dev.2...v3.2.0-dev.3) (2026-04-05)


### Features

* Add `Import/Export login token` patch ([5667e4c](https://github.com/crimera/piko/commit/5667e4cd251685a01d9459a2c637a79a832259b6))

# [3.2.0-dev.2](https://github.com/crimera/piko/compare/v3.2.0-dev.1...v3.2.0-dev.2) (2026-04-02)


### Bug Fixes

* **Instagram:** Fix fingerprint of Feed button on click ([9f988e2](https://github.com/crimera/piko/commit/9f988e269e205609b2122675f88a09862b0d2e2c))

# [3.2.0-dev.1](https://github.com/crimera/piko/compare/v3.1.0...v3.2.0-dev.1) (2026-04-01)


### Bug Fixes

* **Instagram:** `Download media` fingerprint ([e161d4e](https://github.com/crimera/piko/commit/e161d4ed0eafb3a7d802c1ac3d20ed176ede797d))
* **Instagram:** `Hide suggested content` patch fingerprint ([fdb7a1f](https://github.com/crimera/piko/commit/fdb7a1fc72287a9d509c749b3a9bb58e4a8633ea))
* **Instagram:** `Remove build expired popup` patch yet again ([33378d1](https://github.com/crimera/piko/commit/33378d13a7aff3c52160190c1d474884c205df78))
* **Instagram:** `Sanitize share links` patch fingerprint ([339d6b0](https://github.com/crimera/piko/commit/339d6b0f58245af830c72ef89f27d87ac3aa3f92))
* **Instagram:** fix `Media` fingerprints again ([1fdaa80](https://github.com/crimera/piko/commit/1fdaa80a8761fdc25f5ee33e61860fd800dcf2c3))
* **Instagram:** Fix `Open links externally` patch ([b5aa5da](https://github.com/crimera/piko/commit/b5aa5da0bbf860ec3108bce45b51e401e848d36f))
* **Instagram:** Fix `Remove build expired popup` patch ([1235af4](https://github.com/crimera/piko/commit/1235af4aac05c939ce5ff84ca570f2dced3e4e24))
* **Instagram:** fix Download media - author and media type ([95c7a73](https://github.com/crimera/piko/commit/95c7a732479b5954b7793826c37d8e64a4bbc821))
* **Instagram:** fix Download option on feed ([4f4c07f](https://github.com/crimera/piko/commit/4f4c07fcd64c3bcb513dc59b184d7e3e3cde5bb2))
* **Instagram:** Fix feed download button method fingerprint ([dc1b97e](https://github.com/crimera/piko/commit/dc1b97ebf1afd5ca03a4de403ec3a9e84144052b))
* **Instagram:** Fix fingerprints broken on 423 ([3859ba4](https://github.com/crimera/piko/commit/3859ba4da669dfb0dbfd23ab66fa3c9354f84199))
* **Instagram:** Fix Friendship status fingerprints broken on 423 ([0f42aaf](https://github.com/crimera/piko/commit/0f42aaf4e6d818db4a40b83ace1bbe6ca126abf9))
* **Instagram:** Fix friendship status method fingerprint ([276048e](https://github.com/crimera/piko/commit/276048e0e6ffc31d531096748b1243d1c7500aca))
* **Instagram:** Fix piko settings action bar ([1712146](https://github.com/crimera/piko/commit/17121469f71b0c71953f70b2cf6dc09ab920b78a))
* **Instagram:** Fix story button method fingerprint ([ba7b16d](https://github.com/crimera/piko/commit/ba7b16d599eabb43400f6cb5a8162a8f056c29b6))
* **Instagram:** Fixed sanitize post and reels urls ([61257fb](https://github.com/crimera/piko/commit/61257fbd601e69b3c507b5da22b687439890c873))
* **Instagram:** Follow indicator handling ([ad3ed3f](https://github.com/crimera/piko/commit/ad3ed3fd0576c17cf409a69c2703ed0484c0fac0))
* **Twitter:** Fix `Customize notification tabs` patch on 11.78.xx ([05958d2](https://github.com/crimera/piko/commit/05958d2de69935b2a9de1550f06eeed4e2debaee))
* **Twitter:** Fix `Log server response` patch on 11.77.xx ([c2111f1](https://github.com/crimera/piko/commit/c2111f1fd166107eefc436c38f320bd1db33a905))
* **Twitter:** Fix GIFs downloading as image via native downloader ([d18317a](https://github.com/crimera/piko/commit/d18317a4f7b7e013765143f33d34807e3764a063))


### Features

* **Bring back twitter:** Use strings from Twitter 9.98.0 for all languages ([ebcfb9a](https://github.com/crimera/piko/commit/ebcfb9ae7bdbb8f3648b4191ee7c448ee4f6c90a))
* **Instagram:** Added `Customise story timestamp` patch ([421ca76](https://github.com/crimera/piko/commit/421ca76dfa2f67b77bafed5c477c1e24f50657a4))
* **Instagram:** Added `Disable ads` patch ([4046078](https://github.com/crimera/piko/commit/40460788ac473f32f2dbee9735b691e0086d3b31))
* **Instagram:** Added `Disable analytics` patch ([e01da66](https://github.com/crimera/piko/commit/e01da663b520a00b386016cfc00d733a3b39ec70))
* **Instagram:** Added `Disable discover people` patch ([36fbfb5](https://github.com/crimera/piko/commit/36fbfb53f48996c977507c675c8ca4cc426f387b))
* **Instagram:** Added `Disable story flipping` patch ([05f374b](https://github.com/crimera/piko/commit/05f374b4fbe54e8bd8cc165545c6d7e7d01848a7))
* **Instagram:** Added `Distraction free` patches ([ec3ae44](https://github.com/crimera/piko/commit/ec3ae44a0fbfe95515e5250d7e366fcbf88eb8a3))
* **Instagram:** Added `Download media` patch ([b87f023](https://github.com/crimera/piko/commit/b87f02368f26185cf6881d68d63f91830ff46fe8))
* **Instagram:** Added `Follow back indicator` patch ([e6974a1](https://github.com/crimera/piko/commit/e6974a14f23cc549ff1330e3fce125ddee930e15))
* **Instagram:** Added `Hide stories tray` patch ([c4af4df](https://github.com/crimera/piko/commit/c4af4df649762d0b4f1409849edd7fa6626ca3c7))
* **Instagram:** Added `Hide suggested content` patch ([2a10346](https://github.com/crimera/piko/commit/2a10346a3ff680e0ebda33fb2cff547de46457fe))
* **Instagram:** Added `Open links externally` patch ([d199468](https://github.com/crimera/piko/commit/d1994683fac5e9734e4287c424f25205e21de80f))
* **Instagram:** Added `Remove build expired popup` patch ([8932242](https://github.com/crimera/piko/commit/89322421eb2d1f0fbd0e6c2b937e23cd987005ec))
* **Instagram:** Added `Sanitize share links` patch ([43a886f](https://github.com/crimera/piko/commit/43a886ffa801476d57a14a40fd149fc09ec7aa9a))
* **Instagram:** Added `Unlimited replays on ephemeral media` patch ([00e3656](https://github.com/crimera/piko/commit/00e3656db467efd5fbca9de9884716fe75faa188))
* **Instagram:** Added `View live anonymously` patch ([d5c6fb3](https://github.com/crimera/piko/commit/d5c6fb3dc87288eb3429a898d132b55c98609091))
* **Instagram:** Added `View stories anonymously` patch ([2fab876](https://github.com/crimera/piko/commit/2fab8765622b41e7e11cfb57493bd09b788eee27))
* **Instagram:** Added `View story mentions` patch ([ebddfbe](https://github.com/crimera/piko/commit/ebddfbeb46ec781ddcabc7956ca9a40645f5cb18))
* **Instagram:** Added delete analytics cache folder ([f1a1602](https://github.com/crimera/piko/commit/f1a16029c2d0951a77dbad5dff0735abc3fb4d47))
* **Instagram:** Added mapping restore ([6691e56](https://github.com/crimera/piko/commit/6691e565722877aca516a8b6bf531fab667574af))
* **Instagram:** Added override backup ([9b9498a](https://github.com/crimera/piko/commit/9b9498abf51c75b24578470d473076eb35421990))
* **Instagram:** Added override restore ([7d433b2](https://github.com/crimera/piko/commit/7d433b2c39a2e8eb9c70324582d9704a7c7889b5))
* **Instagram:** Added patch information in settings ([90f1885](https://github.com/crimera/piko/commit/90f1885dc65d0a1670d751fe25367ffd711f992e))
* **Instagram:** Added settings and developer options patch ([859c684](https://github.com/crimera/piko/commit/859c6847ee2e45f33812c66201e3fd9f8a96689c))
* **Instagram:** handle signature check on link share and on incoming link ([7698274](https://github.com/crimera/piko/commit/76982744b7adcc8cac5470586af9d27bad9a01c6))
* **Twitter:** Added `Backup and restore` section ([4d894f4](https://github.com/crimera/piko/commit/4d894f4686feb1bf3c2e2973b8fe3e986e1af22c))

# [3.1.0-dev.5](https://github.com/crimera/piko/compare/v3.1.0-dev.4...v3.1.0-dev.5) (2026-03-30)


### Bug Fixes

* **Instagram:** Fixed sanitize post and reels urls ([61257fb](https://github.com/crimera/piko/commit/61257fbd601e69b3c507b5da22b687439890c873))

# [3.1.0-dev.4](https://github.com/crimera/piko/compare/v3.1.0-dev.3...v3.1.0-dev.4) (2026-03-29)


### Bug Fixes

* **Instagram:** Fix `Open links externally` patch ([b5aa5da](https://github.com/crimera/piko/commit/b5aa5da0bbf860ec3108bce45b51e401e848d36f))

# [3.1.0-dev.3](https://github.com/crimera/piko/compare/v3.1.0-dev.2...v3.1.0-dev.3) (2026-03-29)


### Bug Fixes

* **Instagram:** `Download media` fingerprint ([e161d4e](https://github.com/crimera/piko/commit/e161d4ed0eafb3a7d802c1ac3d20ed176ede797d))
* **Instagram:** `Hide suggested content` patch fingerprint ([fdb7a1f](https://github.com/crimera/piko/commit/fdb7a1fc72287a9d509c749b3a9bb58e4a8633ea))
* **Instagram:** `Remove build expired popup` patch yet again ([33378d1](https://github.com/crimera/piko/commit/33378d13a7aff3c52160190c1d474884c205df78))
* **Instagram:** `Sanitize share links` patch fingerprint ([339d6b0](https://github.com/crimera/piko/commit/339d6b0f58245af830c72ef89f27d87ac3aa3f92))
* **Instagram:** fix `Media` fingerprints again ([1fdaa80](https://github.com/crimera/piko/commit/1fdaa80a8761fdc25f5ee33e61860fd800dcf2c3))
* **Instagram:** Fix `Remove build expired popup` patch ([1235af4](https://github.com/crimera/piko/commit/1235af4aac05c939ce5ff84ca570f2dced3e4e24))
* **Instagram:** fix Download media - author and media type ([95c7a73](https://github.com/crimera/piko/commit/95c7a732479b5954b7793826c37d8e64a4bbc821))
* **Instagram:** fix Download option on feed ([4f4c07f](https://github.com/crimera/piko/commit/4f4c07fcd64c3bcb513dc59b184d7e3e3cde5bb2))
* **Instagram:** Fix feed download button method fingerprint ([dc1b97e](https://github.com/crimera/piko/commit/dc1b97ebf1afd5ca03a4de403ec3a9e84144052b))
* **Instagram:** Fix fingerprints broken on 423 ([3859ba4](https://github.com/crimera/piko/commit/3859ba4da669dfb0dbfd23ab66fa3c9354f84199))
* **Instagram:** Fix Friendship status fingerprints broken on 423 ([0f42aaf](https://github.com/crimera/piko/commit/0f42aaf4e6d818db4a40b83ace1bbe6ca126abf9))
* **Instagram:** Fix friendship status method fingerprint ([276048e](https://github.com/crimera/piko/commit/276048e0e6ffc31d531096748b1243d1c7500aca))
* **Instagram:** Fix piko settings action bar ([1712146](https://github.com/crimera/piko/commit/17121469f71b0c71953f70b2cf6dc09ab920b78a))
* **Instagram:** Fix story button method fingerprint ([ba7b16d](https://github.com/crimera/piko/commit/ba7b16d599eabb43400f6cb5a8162a8f056c29b6))
* **Instagram:** Follow indicator handling ([ad3ed3f](https://github.com/crimera/piko/commit/ad3ed3fd0576c17cf409a69c2703ed0484c0fac0))


### Features

* **Instagram:** Added `Customise story timestamp` patch ([421ca76](https://github.com/crimera/piko/commit/421ca76dfa2f67b77bafed5c477c1e24f50657a4))
* **Instagram:** Added `Disable ads` patch ([4046078](https://github.com/crimera/piko/commit/40460788ac473f32f2dbee9735b691e0086d3b31))
* **Instagram:** Added `Disable analytics` patch ([e01da66](https://github.com/crimera/piko/commit/e01da663b520a00b386016cfc00d733a3b39ec70))
* **Instagram:** Added `Disable discover people` patch ([36fbfb5](https://github.com/crimera/piko/commit/36fbfb53f48996c977507c675c8ca4cc426f387b))
* **Instagram:** Added `Disable story flipping` patch ([05f374b](https://github.com/crimera/piko/commit/05f374b4fbe54e8bd8cc165545c6d7e7d01848a7))
* **Instagram:** Added `Distraction free` patches ([ec3ae44](https://github.com/crimera/piko/commit/ec3ae44a0fbfe95515e5250d7e366fcbf88eb8a3))
* **Instagram:** Added `Download media` patch ([b87f023](https://github.com/crimera/piko/commit/b87f02368f26185cf6881d68d63f91830ff46fe8))
* **Instagram:** Added `Follow back indicator` patch ([e6974a1](https://github.com/crimera/piko/commit/e6974a14f23cc549ff1330e3fce125ddee930e15))
* **Instagram:** Added `Hide stories tray` patch ([c4af4df](https://github.com/crimera/piko/commit/c4af4df649762d0b4f1409849edd7fa6626ca3c7))
* **Instagram:** Added `Hide suggested content` patch ([2a10346](https://github.com/crimera/piko/commit/2a10346a3ff680e0ebda33fb2cff547de46457fe))
* **Instagram:** Added `Open links externally` patch ([d199468](https://github.com/crimera/piko/commit/d1994683fac5e9734e4287c424f25205e21de80f))
* **Instagram:** Added `Remove build expired popup` patch ([8932242](https://github.com/crimera/piko/commit/89322421eb2d1f0fbd0e6c2b937e23cd987005ec))
* **Instagram:** Added `Sanitize share links` patch ([43a886f](https://github.com/crimera/piko/commit/43a886ffa801476d57a14a40fd149fc09ec7aa9a))
* **Instagram:** Added `Unlimited replays on ephemeral media` patch ([00e3656](https://github.com/crimera/piko/commit/00e3656db467efd5fbca9de9884716fe75faa188))
* **Instagram:** Added `View live anonymously` patch ([d5c6fb3](https://github.com/crimera/piko/commit/d5c6fb3dc87288eb3429a898d132b55c98609091))
* **Instagram:** Added `View stories anonymously` patch ([2fab876](https://github.com/crimera/piko/commit/2fab8765622b41e7e11cfb57493bd09b788eee27))
* **Instagram:** Added `View story mentions` patch ([ebddfbe](https://github.com/crimera/piko/commit/ebddfbeb46ec781ddcabc7956ca9a40645f5cb18))
* **Instagram:** Added delete analytics cache folder ([f1a1602](https://github.com/crimera/piko/commit/f1a16029c2d0951a77dbad5dff0735abc3fb4d47))
* **Instagram:** Added mapping restore ([6691e56](https://github.com/crimera/piko/commit/6691e565722877aca516a8b6bf531fab667574af))
* **Instagram:** Added override backup ([9b9498a](https://github.com/crimera/piko/commit/9b9498abf51c75b24578470d473076eb35421990))
* **Instagram:** Added override restore ([7d433b2](https://github.com/crimera/piko/commit/7d433b2c39a2e8eb9c70324582d9704a7c7889b5))
* **Instagram:** Added patch information in settings ([90f1885](https://github.com/crimera/piko/commit/90f1885dc65d0a1670d751fe25367ffd711f992e))
* **Instagram:** Added settings and developer options patch ([859c684](https://github.com/crimera/piko/commit/859c6847ee2e45f33812c66201e3fd9f8a96689c))
* **Instagram:** handle signature check on link share and on incoming link ([7698274](https://github.com/crimera/piko/commit/76982744b7adcc8cac5470586af9d27bad9a01c6))
* **Twitter:** Added `Backup and restore` section ([4d894f4](https://github.com/crimera/piko/commit/4d894f4686feb1bf3c2e2973b8fe3e986e1af22c))

# [3.1.0-dev.2](https://github.com/crimera/piko/compare/v3.1.0-dev.1...v3.1.0-dev.2) (2026-03-27)


### Bug Fixes

* **Twitter:** Fix `Customize notification tabs` patch on 11.78.xx ([05958d2](https://github.com/crimera/piko/commit/05958d2de69935b2a9de1550f06eeed4e2debaee))
* **Twitter:** Fix `Log server response` patch on 11.77.xx ([c2111f1](https://github.com/crimera/piko/commit/c2111f1fd166107eefc436c38f320bd1db33a905))
* **Twitter:** Fix GIFs downloading as image via native downloader ([d18317a](https://github.com/crimera/piko/commit/d18317a4f7b7e013765143f33d34807e3764a063))

# [3.1.0-dev.1](https://github.com/crimera/piko/compare/v3.0.0...v3.1.0-dev.1) (2026-03-22)


### Features

* **Bring back twitter:** Use strings from Twitter 9.98.0 for all languages ([ebcfb9a](https://github.com/crimera/piko/commit/ebcfb9ae7bdbb8f3648b4191ee7c448ee4f6c90a))

# [3.0.0](https://github.com/crimera/piko/compare/v2.0.0...v3.0.0) (2026-03-18)


### Bug Fixes

* fix webview resource id ([6c1c81d](https://github.com/crimera/piko/commit/6c1c81d057f3bee73ed8fb53cc95665b89e9c973))
* **i18n:** complete and improve French translation for dev/v3 ([8497136](https://github.com/crimera/piko/commit/8497136d42582c801922087161e22f7ed0076021))
* **Twitter - Dynamic Color:** update border and icon tint colors ([fcd1aa3](https://github.com/crimera/piko/commit/fcd1aa33fecb0eaaa76b0168d78a56c074874e36))
* **Twitter - Share Tweet as Image:** Add the patch in the about page ([00fa95e](https://github.com/crimera/piko/commit/00fa95e307e5a3130d6d216bcdc183312d6a0cc4))
* **Twitter - Share Tweet as Image:** Category title showing up even if patch was disabled ([e03d22e](https://github.com/crimera/piko/commit/e03d22e6d229b746020d0780e4ffdab0ec5ea0a8))
* **Twitter:** Fix `Custom sharing domain` not overriding new share sheet ([fd446fa](https://github.com/crimera/piko/commit/fd446fad33d7ceaf98666cbefde1f03e2315c55f))
* **Twitter:** fix high resolution video extraction ([3ecf524](https://github.com/crimera/piko/commit/3ecf52427de28e7ec1e876a81201e07a73081d39))
* **Twitter:** Fix image link on post text ([5745621](https://github.com/crimera/piko/commit/57456212d2135fab771a158ebb18bcc26d8256fe))
* **Twitter:** high resolution video entity fingerprint ([2025afb](https://github.com/crimera/piko/commit/2025afb553fe5c7b72410286aecfaafc4b009d6b))
* Use the original poster's username/name for retweet posts. ([1a1f818](https://github.com/crimera/piko/commit/1a1f818779d9c4359ca0574ff2bef1e6db525582))
* webview resource id ([fd544a9](https://github.com/crimera/piko/commit/fd544a9a0796f4f9fffb8c9b876069cfb1e43bc8))


### Features

* Add `Browse tweet object` patch ([2e05c33](https://github.com/crimera/piko/commit/2e05c334ee32ba6075249bb873f13ba6d822d77e))
* Change to Morphe patcher 1.1.1 ([31eb19e](https://github.com/crimera/piko/commit/31eb19e05f5dae9c4531db3c33dd8bc966b7b515))
* **Twitter:** Add `Share Tweet as Image` ([e8d6321](https://github.com/crimera/piko/commit/e8d6321cbb9d22d91702dfab583255dca0b7d99c))
* **Twitter:** Add download media button in tweet inline action items ([#806](https://github.com/crimera/piko/issues/806)) ([d79c6e8](https://github.com/crimera/piko/commit/d79c6e8efe89e46482d7143f50f4eacda07628ca))
* **Twitter:** Added `Legacy share links` patch ([3b986b0](https://github.com/crimera/piko/commit/3b986b09d40195c0b0a6cc1eefef79a91a475673))
* **Twitter:** Added new source for `Native translator` ([6945434](https://github.com/crimera/piko/commit/69454343db3550ebba427d29ecbf1c0614cc94ec))


### BREAKING CHANGES

* Old ReVanced CLI and Manager no longer work

# [3.0.0-dev.15](https://github.com/crimera/piko/compare/v3.0.0-dev.14...v3.0.0-dev.15) (2026-03-17)


### Bug Fixes

* **i18n:** complete and improve French translation for dev/v3 ([8497136](https://github.com/crimera/piko/commit/8497136d42582c801922087161e22f7ed0076021))

# [3.0.0-dev.14](https://github.com/crimera/piko/compare/v3.0.0-dev.13...v3.0.0-dev.14) (2026-03-16)


### Bug Fixes

* **Twitter:** high resolution video entity fingerprint ([2025afb](https://github.com/crimera/piko/commit/2025afb553fe5c7b72410286aecfaafc4b009d6b))

# [3.0.0-dev.13](https://github.com/crimera/piko/compare/v3.0.0-dev.12...v3.0.0-dev.13) (2026-03-15)


### Bug Fixes

* **Twitter - Dynamic Color:** update border and icon tint colors ([fcd1aa3](https://github.com/crimera/piko/commit/fcd1aa33fecb0eaaa76b0168d78a56c074874e36))

# [3.0.0-dev.12](https://github.com/crimera/piko/compare/v3.0.0-dev.11...v3.0.0-dev.12) (2026-03-15)


### Features

* **Twitter:** Add download media button in tweet inline action items ([#806](https://github.com/crimera/piko/issues/806)) ([d79c6e8](https://github.com/crimera/piko/commit/d79c6e8efe89e46482d7143f50f4eacda07628ca))

# [3.0.0-dev.11](https://github.com/crimera/piko/compare/v3.0.0-dev.10...v3.0.0-dev.11) (2026-03-14)


### Bug Fixes

* **Twitter:** Fix image link on post text ([5745621](https://github.com/crimera/piko/commit/57456212d2135fab771a158ebb18bcc26d8256fe))


### Features

* **Twitter:** Added `Legacy share links` patch ([3b986b0](https://github.com/crimera/piko/commit/3b986b09d40195c0b0a6cc1eefef79a91a475673))

# [3.0.0-dev.10](https://github.com/crimera/piko/compare/v3.0.0-dev.9...v3.0.0-dev.10) (2026-03-08)


### Bug Fixes

* **Twitter:** fix high resolution video extraction ([3ecf524](https://github.com/crimera/piko/commit/3ecf52427de28e7ec1e876a81201e07a73081d39))

# [3.0.0-dev.9](https://github.com/crimera/piko/compare/v3.0.0-dev.8...v3.0.0-dev.9) (2026-02-26)


### Bug Fixes

* fix webview resource id ([6c1c81d](https://github.com/crimera/piko/commit/6c1c81d057f3bee73ed8fb53cc95665b89e9c973))

# [3.0.0-dev.8](https://github.com/crimera/piko/compare/v3.0.0-dev.7...v3.0.0-dev.8) (2026-02-25)


### Bug Fixes

* webview resource id ([fd544a9](https://github.com/crimera/piko/commit/fd544a9a0796f4f9fffb8c9b876069cfb1e43bc8))

# [3.0.0-dev.7](https://github.com/crimera/piko/compare/v3.0.0-dev.6...v3.0.0-dev.7) (2026-02-24)


### Features

* Add `Browse tweet object` patch ([2e05c33](https://github.com/crimera/piko/commit/2e05c334ee32ba6075249bb873f13ba6d822d77e))

# [3.0.0-dev.6](https://github.com/crimera/piko/compare/v3.0.0-dev.5...v3.0.0-dev.6) (2026-02-23)


### Bug Fixes

* **Twitter - Share Tweet as Image:** Add the patch in the about page ([00fa95e](https://github.com/crimera/piko/commit/00fa95e307e5a3130d6d216bcdc183312d6a0cc4))
* **Twitter - Share Tweet as Image:** Category title showing up even if patch was disabled ([e03d22e](https://github.com/crimera/piko/commit/e03d22e6d229b746020d0780e4ffdab0ec5ea0a8))

# [3.0.0-dev.5](https://github.com/crimera/piko/compare/v3.0.0-dev.4...v3.0.0-dev.5) (2026-02-23)


### Features

* **Twitter:** Add `Share Tweet as Image` ([e8d6321](https://github.com/crimera/piko/commit/e8d6321cbb9d22d91702dfab583255dca0b7d99c))

# [3.0.0-dev.4](https://github.com/crimera/piko/compare/v3.0.0-dev.3...v3.0.0-dev.4) (2026-02-21)


### Bug Fixes

* Use the original poster's username/name for retweet posts. ([1a1f818](https://github.com/crimera/piko/commit/1a1f818779d9c4359ca0574ff2bef1e6db525582))

# [3.0.0-dev.3](https://github.com/crimera/piko/compare/v3.0.0-dev.2...v3.0.0-dev.3) (2026-02-19)


### Features

* **Twitter:** Added new source for `Native translator` ([6945434](https://github.com/crimera/piko/commit/69454343db3550ebba427d29ecbf1c0614cc94ec))

# [3.0.0-dev.2](https://github.com/crimera/piko/compare/v3.0.0-dev.1...v3.0.0-dev.2) (2026-02-17)


### Bug Fixes

* **Twitter:** Fix `Custom sharing domain` not overriding new share sheet ([fd446fa](https://github.com/crimera/piko/commit/fd446fad33d7ceaf98666cbefde1f03e2315c55f))

# [3.0.0-dev.1](https://github.com/crimera/piko/compare/v2.0.0...v3.0.0-dev.1) (2026-02-14)


### Features

* Change to Morphe patcher 1.1.1 ([31eb19e](https://github.com/crimera/piko/commit/31eb19e05f5dae9c4531db3c33dd8bc966b7b515))


### BREAKING CHANGES

* Old ReVanced CLI and Manager no longer work

## [2.0.0](https://github.com/crimera/piko/compare/v1.59.0...v2.0.0) (2026-02-11)

### ⚠ BREAKING CHANGES

* Various APIs have been changed or removed.

### Bug Fixes

* **Custom font:** Fix crash on Android 8 by restricting the functionality to Android 9+ ([477f634](https://github.com/crimera/piko/commit/477f6345a062bc3605dd343d290734074483a61c))
* **Custom font:** Fix crash on Android 8 by restricting the functionality to Android 9+ ([000539b](https://github.com/crimera/piko/commit/000539b8b67d97b83efdf4eab2d311e9b492f167))
* **Dynamic color:** Reflect piko's original changes ([0c91cad](https://github.com/crimera/piko/commit/0c91cad6d4112a02735edc5776a136e9f7c88271))
* **entity:** swap username and display name method mappings in TweetEntityPatch ([b946ebf](https://github.com/crimera/piko/commit/b946ebff8b59081ad3c53eb9ed108c3695dfe5fa))
* some patch has compatibleWith and dependsOn in execute block ([dd25a6c](https://github.com/crimera/piko/commit/dd25a6cd43354b8d6f4cb60d7798c539b06a6e50))
* **Twitter:** `Disunify xchat system` patch ([ad767b1](https://github.com/crimera/piko/commit/ad767b10afcc01c83450988816a60cf32d8fc195))
* **Twitter:** Added missing `notifications` item on hide sidebar elements ([39816e9](https://github.com/crimera/piko/commit/39816e91f85bad367494231e07c8ff1c0d9b58ce))
* **Twitter:** Correct Db clear keyword ([ca71ea7](https://github.com/crimera/piko/commit/ca71ea73a2957e1c64e1e2ed02b64311287bfaa0))
* **Twitter:** Corrected Moon app icon string ([60d0ede](https://github.com/crimera/piko/commit/60d0eded80fd32dbc7f1a1c229ed0c86da31efd5))
* **Twitter:** Fix `Custom download folder` in/from 11.51.xx ([c885395](https://github.com/crimera/piko/commit/c885395fce086f1f6791722cc615b671a6c69027))
* **Twitter:** Fix `Customize timeline top bar` fingerprint (again) ([189dfdd](https://github.com/crimera/piko/commit/189dfdd9e02de3869ed331d0258f4e83da309299))
* **Twitter:** Fix `Customize timeline top bar` logic ([642d092](https://github.com/crimera/piko/commit/642d0927a4819743a40d662db5c70cc3a4ff76d2))
* **Twitter:** Fix `Customize timeline top bar` patch ([2aa2a36](https://github.com/crimera/piko/commit/2aa2a3644956f588c46e9b3f08a94a2def9908d7))
* **Twitter:** Fix `Customize timeline top bar` patch - update tab ids ([c1d66c4](https://github.com/crimera/piko/commit/c1d66c42a56854f67633a07fb50d866c70ae096c))
* **Twitter:** fix `Enable force HD videos` patch ([23f2859](https://github.com/crimera/piko/commit/23f285974c8c12a117b81c794a64e94e6f33e531))
* **Twitter:** Fix `Extension hook` ([6fb52f7](https://github.com/crimera/piko/commit/6fb52f7307b596988ee8b4286717b378d3c2ca4d))
* **Twitter:** Fix `Native reader mode` deeplink ([24be415](https://github.com/crimera/piko/commit/24be4154d5a17a2c065dc8cff66b4087a165090a))
* **Twitter:** Fix `Native reader mode` patch in 10.28 and above ([800da14](https://github.com/crimera/piko/commit/800da149f4179044296d265ff4de9e7b2737e9b8))
* **Twitter:** Fix `Show post source label` patch ([42efbe2](https://github.com/crimera/piko/commit/42efbe23f17b44259fbc597f1ec72b0456bece15))
* **Twitter:** Fix font import bug. ([c8ea53c](https://github.com/crimera/piko/commit/c8ea53c8a50d3854911aec5dd2205661eba54ed5))
* **Twitter:** Fix font section header ([35e9b2b](https://github.com/crimera/piko/commit/35e9b2beb9efdb8d624455714c99cebbffed574e))
* **Twitter:** Fix font section header ([a7a7b2e](https://github.com/crimera/piko/commit/a7a7b2e719293102b45e202505eeb032f81d06c0))
* **Twitter:** Fix remove ads on replies ([8fda05e](https://github.com/crimera/piko/commit/8fda05ec94ffc7a48dfc1eb3a17bb14f6328ca6f))
* **Twitter:** Fix tweet short text extraction for `Custom translator` patch ([18becfb](https://github.com/crimera/piko/commit/18becfb31e68e05d571bd8651ba7ebfe7ecba3d1))
* **Twitter:** Fix unescaped strings ([41405a7](https://github.com/crimera/piko/commit/41405a75e50141e902aaac74f5fad9a2fcb06422))
* **Twitter:** Fixed host name issue due to `Custom sharing domain` patch ([3b26c84](https://github.com/crimera/piko/commit/3b26c84a902200f687cd327fb83281301e653dc1))
* **Twitter:** Fixed preference import ([4623b93](https://github.com/crimera/piko/commit/4623b93b68b18f42d0b8c435d4089f903ddfe4fd))
* **Twitter:** revert `semantic-release` version ([b50c530](https://github.com/crimera/piko/commit/b50c5301139ea1b972b6ccd507c929896219ff26))
* **Twitter:** Update `extensions` hook ([bf20765](https://github.com/crimera/piko/commit/bf2076592f49c11337acedf0d90e8a9d2d8d4ba4))
* **Universal:** Set version code as int ([ee83df7](https://github.com/crimera/piko/commit/ee83df7f8f18cf4cf2306b0a662a845ed565e106))
* wrong index number on multiple medias ([d088d03](https://github.com/crimera/piko/commit/d088d03a5dc743e1e50f403d14b71bc59b38571b))

### Features

* **Change version code:** Add compatibleWith to make it a non-universal patch ([c684cbc](https://github.com/crimera/piko/commit/c684cbc04017549ef247438764d6f10828912c7b))
* **Change version code:** Add compatibleWith to make it a non-universal patch ([3664dbf](https://github.com/crimera/piko/commit/3664dbf560b9dc61cc90de4e6f53f54d86f528b0))
* Migrate ci ([c737ca8](https://github.com/crimera/piko/commit/c737ca8edef074ff1beff17db7d27e5f26c17dc1))
* **Settings:** Allow preference titles to be multiple lines ([5581330](https://github.com/crimera/piko/commit/558133068396d532837c53347288fa42a7fb47f6))
* **Settings:** Allow preference titles to be multiple lines ([3075555](https://github.com/crimera/piko/commit/3075555611163ff67c073afd887d7fff4aeb45a7))
* **Twitter:** Added `Change app icon` patch ([efbd6f7](https://github.com/crimera/piko/commit/efbd6f708357d0256104e31748a035d92acee8f4))
* **Twitter:** Added `Customise font` patch ([e02d7db](https://github.com/crimera/piko/commit/e02d7dbd884ac4daf7c113d44575d085ba792989))
* **Twitter:** Added `Customize notification tabs` patch ([2e902e9](https://github.com/crimera/piko/commit/2e902e92b8cc56e757235cf47bbd6a52151b8c17))
* **Twitter:** Added `Disunify xchat system` patch ([1fa9b7b](https://github.com/crimera/piko/commit/1fa9b7bb949152f536e95d801ded61ead21caac1))
* **Twitter:** Added `Hide badges from navigation bar icons` patch ([1d98886](https://github.com/crimera/piko/commit/1d988863d06418e270d2821e366a5fdf1f3c0d47))
* **Twitter:** Added `Hide post metrics` patch ([81627c2](https://github.com/crimera/piko/commit/81627c2e75abb98a5b42da42187b7d9918a0b46b))
* **Twitter:** Added `Pause search suggestions` patch ([a5f3d8e](https://github.com/crimera/piko/commit/a5f3d8e87b19b61223b4959cdccb68630ceeea4e))
* **Twitter:** Added `Pause search suggestions` patch ([ddbdcfe](https://github.com/crimera/piko/commit/ddbdcfeda9418e83e4206101c9847e866e6a23a4))
* **Twitter:** Added `Remove search suggestions` patch ([33fa525](https://github.com/crimera/piko/commit/33fa5257b2d0ff0ce5423db6df733202e705aac0))
* **Twitter:** Added `Remove search suggestions` patch ([dd8e67b](https://github.com/crimera/piko/commit/dd8e67b3a634036e308a2a99844c7c966f69890b))
* **Twitter:** Added `Show changelogs` patch ([4b3adf7](https://github.com/crimera/piko/commit/4b3adf7a5e8966bc800d41b947349fb36345d5f4))

### Updates

* spanish translation to new strings ([28dbebd](https://github.com/crimera/piko/commit/28dbebd3508bbb8601ac3e706cb081aed69e224a))
* **Translation:** `Japanese` strings ([2f91899](https://github.com/crimera/piko/commit/2f91899580b5cf1e7eaec93ef780c27111a83865))
* **Translation:** `Japanese` strings ([054b2c5](https://github.com/crimera/piko/commit/054b2c5b93a43bc412e03adcb875117e513dd5bb))
* **Translation:** Added `pl` to Bring Back Twitter resource list ([44a5436](https://github.com/crimera/piko/commit/44a5436eabe9e9493984e9413ccbc74592eb8280))
* **Translation:** Added `pt-rBr` to `Bring Back Twitter` Patch ([9e33933](https://github.com/crimera/piko/commit/9e33933279bb80a40532a382726c9ddff53d43a2))
* **Translation:** Added `zh-rHK` ([58a2f4f](https://github.com/crimera/piko/commit/58a2f4fdb64d86a61ed27ad5bf632d260738688c))
* **Translation:** Fix `Vietnamese` strings ([3d1e213](https://github.com/crimera/piko/commit/3d1e213a6691216946ae703ea1ef239e56db584c))
* **Translations:** `Japanese` strings ([09b42d3](https://github.com/crimera/piko/commit/09b42d3fc0ce1199cdd2b4ec0904132ff2a5dc05))
* **Translations:** <Arabic> ([9ae0f3a](https://github.com/crimera/piko/commit/9ae0f3ad2f5a4d1ff7bdcb2f9d9c56ed909520d5))
* **Translations:** Update `Brazilian Portuguese` ([bbe2af9](https://github.com/crimera/piko/commit/bbe2af9a81b62d23885ecbbe93464b7abeabb73f))
* **Translations:** Update `Italian` strings ([837edf9](https://github.com/crimera/piko/commit/837edf922f1d6c2319e51a5a80907f13245fa8ca))
* **Translations:** Update `Korean` strings ([6bdf0cc](https://github.com/crimera/piko/commit/6bdf0ccb08e426b23d51abb9fe9f4907214030d3))
* **Translations:** Update `Polish` ([beba988](https://github.com/crimera/piko/commit/beba988141027bf05066f3b740ff8b7a72f43221))
* **Translations:** Update `Polish` ([6f5e2e9](https://github.com/crimera/piko/commit/6f5e2e9d384868aacba878e6565a3eeb14282154))
* **Translations:** Update `Polish` ([8302efe](https://github.com/crimera/piko/commit/8302efea73fa46b72e00eb0acd388af4a1e6376a))
* **Translations:** Update `Polish` ([f353663](https://github.com/crimera/piko/commit/f353663e2bcdffde840f0cb2097a69071206df23))
* **Translations:** Update `Polish` ([36011a6](https://github.com/crimera/piko/commit/36011a6677013e744f6227bdd1a7eb3550293f43))
* **Translations:** Update `Polish` ([2347537](https://github.com/crimera/piko/commit/23475370b2f9edaaf76f00d85b9fdbb3a4fcbffb))
* **Translations:** Update `Polish` ([15cf2b1](https://github.com/crimera/piko/commit/15cf2b1b1f61b87adde8cd27e59f83d0bba2f1d7))
* **Translations:** Update `Polish` ([1bcacaa](https://github.com/crimera/piko/commit/1bcacaa634e1ccd08ee7b3968c8761b789f2e5d6))
* **Translations:** Update `Polish` ([0983e57](https://github.com/crimera/piko/commit/0983e5723e0b6ea1a171aeefe774f64bb3993edf))
* **Translations:** Update `Polish` ([43da4b5](https://github.com/crimera/piko/commit/43da4b5ebc4b12d155d8f81495bbd6a09b1f44ad))
* **Translations:** Update `Polish` strings ([e32b911](https://github.com/crimera/piko/commit/e32b91113dc1b9dedea73cc606a6fd3bbf4f9a9d))
* **Translations:** Update Arabic ([a4f3df8](https://github.com/crimera/piko/commit/a4f3df857d4b82253bcae1cd268d5ec05d8d5b54))
* **Translations:** Update Korean ([f337585](https://github.com/crimera/piko/commit/f337585a3672f9b77f0da4fb76bb240cf84a8fdb))
* **Translations:** Update Korean ([a67efa4](https://github.com/crimera/piko/commit/a67efa42283b9ca42a43990cf3b0718384f8f527))
* **Translations:** Update Korean ([89820de](https://github.com/crimera/piko/commit/89820de1be72efe1af24826a5b57bf43f30dd37c))
* **Translations:** Update Korean ([23f1f25](https://github.com/crimera/piko/commit/23f1f25895787b168bce81ec6e6a66742b2b5ee1))
* **Translations:** Update Korean ([b1edad5](https://github.com/crimera/piko/commit/b1edad5c433e9d6f06010fe438e995ab02da6f2b))
* **Translations:** Updated `Arabic` strings [#735](https://github.com/crimera/piko/issues/735) ([61a05c6](https://github.com/crimera/piko/commit/61a05c64c3f40f906980c3e99b89a4c68b280184))
* **Translations:** Updated `Italian` ([071835c](https://github.com/crimera/piko/commit/071835c37ceae0f7e5b5e8e396e91327f9ae01ba))
* **Translations:** Updated `Japanese` strings ([cd5a888](https://github.com/crimera/piko/commit/cd5a8880c9265bf070f2f0793db9a11c741bf22c))
* **Translations:** Updated `Spanish` strings [#732](https://github.com/crimera/piko/issues/732) ([8137cd5](https://github.com/crimera/piko/commit/8137cd5da6ddf57d6088ddbdcb9640e77682b40f))
* **Translations:** Updated `Turkish` ([ae0df82](https://github.com/crimera/piko/commit/ae0df82a1601bd6588bd9f5db0f4071c83f428f2))
* **Translation:** Update `Japanese` ([6c22ae2](https://github.com/crimera/piko/commit/6c22ae255149a057680ad85f6a59ce829100bb65))
* **Translation:** Update `Vietnamese` ([9343e0e](https://github.com/crimera/piko/commit/9343e0e5c750566b4a86ff72de84050950c9551a))
* **Translation:** Update Traditional Chinese ([9f4d654](https://github.com/crimera/piko/commit/9f4d654f3bf91d7e68adf0b426c02feed32d3eed))
* **Translation:** Updated `Brazilian Portuguese` strings ([bb448a1](https://github.com/crimera/piko/commit/bb448a1367b692f267cd176e0d9daab547088667))
* **Translation:** Updated `Brazilian Portuguese` strings ([a53f3a0](https://github.com/crimera/piko/commit/a53f3a020eaf3b88570bda8dcb01c9968873c9e2))
* **Translation:** Updated `Japanese` strings ([373e275](https://github.com/crimera/piko/commit/373e275683c7c2ee83053751be851c9757f48ff8))
* **Translation:** Updated `Polish` strings ([4ba908b](https://github.com/crimera/piko/commit/4ba908b54e24f8fc78a884bdeb19aa59f0dff0c0))
* **Translation:** Updated `Polish` strings ([b6773c3](https://github.com/crimera/piko/commit/b6773c34549239a5580761faad5067f5a33c522c))
* **Twitter:** `Custom sharing domain` : added support for new share sheet ([a27675a](https://github.com/crimera/piko/commit/a27675a2b6324623e3ec09236fe6be2a51b2a22a))
* **Twitter:** Added more elements to hide from navigation bar ([8e6706c](https://github.com/crimera/piko/commit/8e6706c8578dbe86e97315da1da48b228071378d))
* **Twitter:** Include translations for app icon strings ([edad4a6](https://github.com/crimera/piko/commit/edad4a6438cf49a6226b02d94f4f41ccae31e683))
* **Twitter:** Set Splashscreen color to blue in `Bring back twitter` patch ([fbb9a09](https://github.com/crimera/piko/commit/fbb9a093dabe0634792f6b342489ed06d75f6bc6))
* **Twitter:** update `Custom sharing domain` patch in xchat share sheet ([4726ddb](https://github.com/crimera/piko/commit/4726ddb247468435ad22266cb148a4ea62ab3421))
* **Twitter:** Update `Customize timeline top bar` fingerprint ([38b706f](https://github.com/crimera/piko/commit/38b706fd3b866425284aa1e4a423f99c684f545c))
* **Twitter:** Updated missing patch names in `About section` ([fed6cee](https://github.com/crimera/piko/commit/fed6ceedd21501d06ad1e3a562135f5f65a335c2))
* **Twitter:** Updated side bar elements to hide ([45f93a1](https://github.com/crimera/piko/commit/45f93a1d6aeaddbf06011cea05abc8f79ba25b12))

### Refactors

* **Bring Back Twitter:** Added more numeric character  <-> emoji pairs ([5534c57](https://github.com/crimera/piko/commit/5534c5726d216148b07a5ad8dab29c88dd40fa7f))
* **Bring Back Twitter:** Refactor English strings ([18b68b3](https://github.com/crimera/piko/commit/18b68b3014ed69017207bcaced90a228f6791e90))
* **Dynamic color:** Do not get elements repeatedly in XML operation ([cc41d35](https://github.com/crimera/piko/commit/cc41d3525a6a1588f857a0b602e8a5208cec0fd3))
* **Dynamic color:** Do not get elements repeatedly in XML operation ([3417fe1](https://github.com/crimera/piko/commit/3417fe15d2d558b042a44a06e9c21a1523d12540))
* **Twitter:** Correct ja strings replacement in BBT patch ([ee200a5](https://github.com/crimera/piko/commit/ee200a5c5ae14e1a935903b5de9e7ecf7f03e0f9))
* **Twitter:** fix `Remove promoted trends` ([0e1d4ed](https://github.com/crimera/piko/commit/0e1d4ed2ac090451172f2bed985310061b987428))
* **Twitter:** handle piko resources programmatically ([3cc0f07](https://github.com/crimera/piko/commit/3cc0f0715c6ad62c14d6cd13e91f0965886e1534))
* **Twitter:** potential fix for resource compilation failing in manager ([fa0dfac](https://github.com/crimera/piko/commit/fa0dfac2b959ba9a958bb458cc4572f28ff94902))
* **Twitter:** refactor `Bring back twitter` patch ([f24cb72](https://github.com/crimera/piko/commit/f24cb72309f648493b209fffb1e7d19bd5c705f6))
* **Twitter:** refactor fingerprint for tweet short text ([062aeb3](https://github.com/crimera/piko/commit/062aeb3b4902185a041b73689bad56e8636b951b))
* **Twitter:** refactor fingerprint for tweet short text ([c00264a](https://github.com/crimera/piko/commit/c00264aebbe4717e61dd08b0998ff814f92ba3bd))
* **Twitter:** refactor native reader theme system. ([2ab5f35](https://github.com/crimera/piko/commit/2ab5f355103a3c65ddbfde63259da9eec90cc10b))
* **Twitter:** remove old comments ([1655283](https://github.com/crimera/piko/commit/165528374dadeab472a5f7d28bc60be12a09bbe0))

## [2.0.0-dev.23](https://github.com/crimera/piko/compare/v2.0.0-dev.22...v2.0.0-dev.23) (2026-01-28)

### Updates

* **Twitter:** update `Custom sharing domain` patch in xchat share sheet ([4726ddb](https://github.com/crimera/piko/commit/4726ddb247468435ad22266cb148a4ea62ab3421))

## [2.0.0-dev.22](https://github.com/crimera/piko/compare/v2.0.0-dev.21...v2.0.0-dev.22) (2026-01-27)

### Bug Fixes

* **Twitter:** Fix `Customize timeline top bar` patch - update tab ids ([c1d66c4](https://github.com/crimera/piko/commit/c1d66c42a56854f67633a07fb50d866c70ae096c))

## [2.0.0-dev.21](https://github.com/crimera/piko/compare/v2.0.0-dev.20...v2.0.0-dev.21) (2026-01-25)

### Bug Fixes

* **Twitter:** Fix `Customize timeline top bar` patch ([2aa2a36](https://github.com/crimera/piko/commit/2aa2a3644956f588c46e9b3f08a94a2def9908d7))
* **Twitter:** Fix tweet short text extraction for `Custom translator` patch ([18becfb](https://github.com/crimera/piko/commit/18becfb31e68e05d571bd8651ba7ebfe7ecba3d1))

### Updates

* **Translations:** Update `Brazilian Portuguese` ([bbe2af9](https://github.com/crimera/piko/commit/bbe2af9a81b62d23885ecbbe93464b7abeabb73f))
* **Translations:** Update `Polish` ([beba988](https://github.com/crimera/piko/commit/beba988141027bf05066f3b740ff8b7a72f43221))

## [2.0.0-dev.20](https://github.com/crimera/piko/compare/v2.0.0-dev.19...v2.0.0-dev.20) (2026-01-04)

### Bug Fixes

* **Twitter:** revert `semantic-release` version ([b50c530](https://github.com/crimera/piko/commit/b50c5301139ea1b972b6ccd507c929896219ff26))

### Updates

* **Translations:** Update `Polish` ([6f5e2e9](https://github.com/crimera/piko/commit/6f5e2e9d384868aacba878e6565a3eeb14282154))
* **Translations:** Update Korean ([f337585](https://github.com/crimera/piko/commit/f337585a3672f9b77f0da4fb76bb240cf84a8fdb))
* **Twitter:** `Custom sharing domain` : added support for new share sheet ([a27675a](https://github.com/crimera/piko/commit/a27675a2b6324623e3ec09236fe6be2a51b2a22a))

### Refactors

* **Twitter:** refactor native reader theme system. ([2ab5f35](https://github.com/crimera/piko/commit/2ab5f355103a3c65ddbfde63259da9eec90cc10b))

## [2.0.0-dev.19](https://github.com/crimera/piko/compare/v2.0.0-dev.18...v2.0.0-dev.19) (2025-12-27)

### Bug Fixes

* **Twitter:** Fix `Custom download folder` in/from 11.51.xx ([c885395](https://github.com/crimera/piko/commit/c885395fce086f1f6791722cc615b671a6c69027))

## [2.0.0-dev.18](https://github.com/crimera/piko/compare/v2.0.0-dev.17...v2.0.0-dev.18) (2025-12-15)

### Bug Fixes

* **Twitter:** `Disunify xchat system` patch ([ad767b1](https://github.com/crimera/piko/commit/ad767b10afcc01c83450988816a60cf32d8fc195))
* **Twitter:** Fix `Customize timeline top bar` logic ([642d092](https://github.com/crimera/piko/commit/642d0927a4819743a40d662db5c70cc3a4ff76d2))

### Updates

* **Translations:** Update `Polish` ([8302efe](https://github.com/crimera/piko/commit/8302efea73fa46b72e00eb0acd388af4a1e6376a))

## [2.0.0-dev.17](https://github.com/crimera/piko/compare/v2.0.0-dev.16...v2.0.0-dev.17) (2025-12-14)

### Bug Fixes

* **Twitter:** Fix `Customize timeline top bar` fingerprint (again) ([189dfdd](https://github.com/crimera/piko/commit/189dfdd9e02de3869ed331d0258f4e83da309299))

### Features

* **Twitter:** Added `Disunify xchat system` patch ([1fa9b7b](https://github.com/crimera/piko/commit/1fa9b7bb949152f536e95d801ded61ead21caac1))

## [2.0.0-dev.16](https://github.com/crimera/piko/compare/v2.0.0-dev.15...v2.0.0-dev.16) (2025-12-10)

### Bug Fixes

* **Twitter:** Fix `Native reader mode` deeplink ([24be415](https://github.com/crimera/piko/commit/24be4154d5a17a2c065dc8cff66b4087a165090a))

## [2.0.0-dev.15](https://github.com/crimera/piko/compare/v2.0.0-dev.14...v2.0.0-dev.15) (2025-12-10)

### Bug Fixes

* **Twitter:** Fix unescaped strings ([41405a7](https://github.com/crimera/piko/commit/41405a75e50141e902aaac74f5fad9a2fcb06422))

### Updates

* **Translations:** Update `Polish` ([f353663](https://github.com/crimera/piko/commit/f353663e2bcdffde840f0cb2097a69071206df23))
* **Translations:** Update Arabic ([a4f3df8](https://github.com/crimera/piko/commit/a4f3df857d4b82253bcae1cd268d5ec05d8d5b54))
* **Translations:** Update Korean ([a67efa4](https://github.com/crimera/piko/commit/a67efa42283b9ca42a43990cf3b0718384f8f527))
* **Twitter:** Update `Customize timeline top bar` fingerprint ([38b706f](https://github.com/crimera/piko/commit/38b706fd3b866425284aa1e4a423f99c684f545c))

## [2.0.0-dev.14](https://github.com/crimera/piko/compare/v2.0.0-dev.13...v2.0.0-dev.14) (2025-12-07)

### Features

* **Twitter:** Added `Hide post metrics` patch ([81627c2](https://github.com/crimera/piko/commit/81627c2e75abb98a5b42da42187b7d9918a0b46b))

### Updates

* **Translations:** `Japanese` strings ([09b42d3](https://github.com/crimera/piko/commit/09b42d3fc0ce1199cdd2b4ec0904132ff2a5dc05))
* **Translations:** Update `Polish` ([36011a6](https://github.com/crimera/piko/commit/36011a6677013e744f6227bdd1a7eb3550293f43))
* **Translations:** Update `Polish` strings ([e32b911](https://github.com/crimera/piko/commit/e32b91113dc1b9dedea73cc606a6fd3bbf4f9a9d))
* **Translations:** Update Korean ([89820de](https://github.com/crimera/piko/commit/89820de1be72efe1af24826a5b57bf43f30dd37c))
* **Translations:** Updated `Italian` ([071835c](https://github.com/crimera/piko/commit/071835c37ceae0f7e5b5e8e396e91327f9ae01ba))
* **Twitter:** Updated missing patch names in `About section` ([fed6cee](https://github.com/crimera/piko/commit/fed6ceedd21501d06ad1e3a562135f5f65a335c2))

## [2.0.0-dev.13](https://github.com/crimera/piko/compare/v2.0.0-dev.12...v2.0.0-dev.13) (2025-11-27)

### Features

* **Twitter:** Added `Hide badges from navigation bar icons` patch ([1d98886](https://github.com/crimera/piko/commit/1d988863d06418e270d2821e366a5fdf1f3c0d47))

### Updates

* **Translations:** Update Korean ([23f1f25](https://github.com/crimera/piko/commit/23f1f25895787b168bce81ec6e6a66742b2b5ee1))
* **Translations:** Updated `Turkish` ([ae0df82](https://github.com/crimera/piko/commit/ae0df82a1601bd6588bd9f5db0f4071c83f428f2))
* **Twitter:** Added more elements to hide from navigation bar ([8e6706c](https://github.com/crimera/piko/commit/8e6706c8578dbe86e97315da1da48b228071378d))

### Refactors

* **Bring Back Twitter:** Added more numeric character  <-> emoji pairs ([5534c57](https://github.com/crimera/piko/commit/5534c5726d216148b07a5ad8dab29c88dd40fa7f))
* **Bring Back Twitter:** Refactor English strings ([18b68b3](https://github.com/crimera/piko/commit/18b68b3014ed69017207bcaced90a228f6791e90))

## [2.0.0-dev.12](https://github.com/crimera/piko/compare/v2.0.0-dev.11...v2.0.0-dev.12) (2025-11-23)

### Bug Fixes

* **Twitter:** Fixed preference import ([4623b93](https://github.com/crimera/piko/commit/4623b93b68b18f42d0b8c435d4089f903ddfe4fd))

### Updates

* spanish translation to new strings ([28dbebd](https://github.com/crimera/piko/commit/28dbebd3508bbb8601ac3e706cb081aed69e224a))
* **Translations:** <Arabic> ([9ae0f3a](https://github.com/crimera/piko/commit/9ae0f3ad2f5a4d1ff7bdcb2f9d9c56ed909520d5))
* **Translations:** Updated `Arabic` strings [#735](https://github.com/crimera/piko/issues/735) ([61a05c6](https://github.com/crimera/piko/commit/61a05c64c3f40f906980c3e99b89a4c68b280184))
* **Translations:** Updated `Spanish` strings [#732](https://github.com/crimera/piko/issues/732) ([8137cd5](https://github.com/crimera/piko/commit/8137cd5da6ddf57d6088ddbdcb9640e77682b40f))
* **Twitter:** Updated side bar elements to hide ([45f93a1](https://github.com/crimera/piko/commit/45f93a1d6aeaddbf06011cea05abc8f79ba25b12))

## [2.0.0-dev.11](https://github.com/crimera/piko/compare/v2.0.0-dev.10...v2.0.0-dev.11) (2025-11-18)

### Bug Fixes

* **Twitter:** Corrected Moon app icon string ([60d0ede](https://github.com/crimera/piko/commit/60d0eded80fd32dbc7f1a1c229ed0c86da31efd5))
* **Twitter:** Fix font import bug. ([c8ea53c](https://github.com/crimera/piko/commit/c8ea53c8a50d3854911aec5dd2205661eba54ed5))

### Updates

* **Translations:** Update `Korean` strings ([6bdf0cc](https://github.com/crimera/piko/commit/6bdf0ccb08e426b23d51abb9fe9f4907214030d3))
* **Translations:** Update `Polish` ([2347537](https://github.com/crimera/piko/commit/23475370b2f9edaaf76f00d85b9fdbb3a4fcbffb))
* **Twitter:** Include translations for app icon strings ([edad4a6](https://github.com/crimera/piko/commit/edad4a6438cf49a6226b02d94f4f41ccae31e683))

## [2.0.0-dev.10](https://github.com/crimera/piko/compare/v2.0.0-dev.9...v2.0.0-dev.10) (2025-11-13)

### Bug Fixes

* **Twitter:** Fix `Show post source label` patch ([42efbe2](https://github.com/crimera/piko/commit/42efbe23f17b44259fbc597f1ec72b0456bece15))

### Features

* **Twitter:** Added `Change app icon` patch ([efbd6f7](https://github.com/crimera/piko/commit/efbd6f708357d0256104e31748a035d92acee8f4))

### Updates

* **Translations:** Update `Polish` ([15cf2b1](https://github.com/crimera/piko/commit/15cf2b1b1f61b87adde8cd27e59f83d0bba2f1d7))
* **Translations:** Update Korean ([b1edad5](https://github.com/crimera/piko/commit/b1edad5c433e9d6f06010fe438e995ab02da6f2b))

## [2.0.0-dev.9](https://github.com/crimera/piko/compare/v2.0.0-dev.8...v2.0.0-dev.9) (2025-11-05)

### Bug Fixes

* **entity:** swap username and display name method mappings in TweetEntityPatch ([b946ebf](https://github.com/crimera/piko/commit/b946ebff8b59081ad3c53eb9ed108c3695dfe5fa))

## [2.0.0-dev.8](https://github.com/crimera/piko/compare/v2.0.0-dev.7...v2.0.0-dev.8) (2025-11-02)

### Bug Fixes

* **Custom font:** Fix crash on Android 8 by restricting the functionality to Android 9+ ([477f634](https://github.com/crimera/piko/commit/477f6345a062bc3605dd343d290734074483a61c))
* **Twitter:** Added missing `notifications` item on hide sidebar elements ([39816e9](https://github.com/crimera/piko/commit/39816e91f85bad367494231e07c8ff1c0d9b58ce))
* **Twitter:** Fix `Extension hook` ([6fb52f7](https://github.com/crimera/piko/commit/6fb52f7307b596988ee8b4286717b378d3c2ca4d))
* **Twitter:** Fix font section header ([35e9b2b](https://github.com/crimera/piko/commit/35e9b2beb9efdb8d624455714c99cebbffed574e))

### Features

* **Change version code:** Add compatibleWith to make it a non-universal patch ([c684cbc](https://github.com/crimera/piko/commit/c684cbc04017549ef247438764d6f10828912c7b))
* **Settings:** Allow preference titles to be multiple lines ([5581330](https://github.com/crimera/piko/commit/558133068396d532837c53347288fa42a7fb47f6))
* **Twitter:** Added `Customize notification tabs` patch ([2e902e9](https://github.com/crimera/piko/commit/2e902e92b8cc56e757235cf47bbd6a52151b8c17))
* **Twitter:** Added `Pause search suggestions` patch ([a5f3d8e](https://github.com/crimera/piko/commit/a5f3d8e87b19b61223b4959cdccb68630ceeea4e))
* **Twitter:** Added `Remove search suggestions` patch ([33fa525](https://github.com/crimera/piko/commit/33fa5257b2d0ff0ce5423db6df733202e705aac0))

### Updates

* **Translation:** `Japanese` strings ([2f91899](https://github.com/crimera/piko/commit/2f91899580b5cf1e7eaec93ef780c27111a83865))
* **Translations:** Update `Italian` strings ([837edf9](https://github.com/crimera/piko/commit/837edf922f1d6c2319e51a5a80907f13245fa8ca))
* **Translations:** Update `Polish` ([1bcacaa](https://github.com/crimera/piko/commit/1bcacaa634e1ccd08ee7b3968c8761b789f2e5d6))
* **Translations:** Updated `Japanese` strings ([cd5a888](https://github.com/crimera/piko/commit/cd5a8880c9265bf070f2f0793db9a11c741bf22c))
* **Translation:** Updated `Brazilian Portuguese` strings ([bb448a1](https://github.com/crimera/piko/commit/bb448a1367b692f267cd176e0d9daab547088667))
* **Translation:** Updated `Polish` strings ([4ba908b](https://github.com/crimera/piko/commit/4ba908b54e24f8fc78a884bdeb19aa59f0dff0c0))

### Refactors

* **Dynamic color:** Do not get elements repeatedly in XML operation ([cc41d35](https://github.com/crimera/piko/commit/cc41d3525a6a1588f857a0b602e8a5208cec0fd3))
* **Twitter:** refactor fingerprint for tweet short text ([062aeb3](https://github.com/crimera/piko/commit/062aeb3b4902185a041b73689bad56e8636b951b))

## [2.0.0-dev.7](https://github.com/crimera/piko/compare/v2.0.0-dev.6...v2.0.0-dev.7) (2025-10-26)

### Bug Fixes

* **Custom font:** Fix crash on Android 8 by restricting the functionality to Android 9+ ([000539b](https://github.com/crimera/piko/commit/000539b8b67d97b83efdf4eab2d311e9b492f167))
* **Twitter:** Fix font section header ([a7a7b2e](https://github.com/crimera/piko/commit/a7a7b2e719293102b45e202505eeb032f81d06c0))

### Features

* **Change version code:** Add compatibleWith to make it a non-universal patch ([3664dbf](https://github.com/crimera/piko/commit/3664dbf560b9dc61cc90de4e6f53f54d86f528b0))
* **Settings:** Allow preference titles to be multiple lines ([3075555](https://github.com/crimera/piko/commit/3075555611163ff67c073afd887d7fff4aeb45a7))
* **Twitter:** Added `Pause search suggestions` patch ([ddbdcfe](https://github.com/crimera/piko/commit/ddbdcfeda9418e83e4206101c9847e866e6a23a4))
* **Twitter:** Added `Remove search suggestions` patch ([dd8e67b](https://github.com/crimera/piko/commit/dd8e67b3a634036e308a2a99844c7c966f69890b))

### Updates

* **Translation:** Updated `Brazilian Portuguese` strings ([a53f3a0](https://github.com/crimera/piko/commit/a53f3a020eaf3b88570bda8dcb01c9968873c9e2))
* **Translation:** Updated `Japanese` strings ([373e275](https://github.com/crimera/piko/commit/373e275683c7c2ee83053751be851c9757f48ff8))
* **Translation:** Updated `Polish` strings ([b6773c3](https://github.com/crimera/piko/commit/b6773c34549239a5580761faad5067f5a33c522c))

### Refactors

* **Dynamic color:** Do not get elements repeatedly in XML operation ([3417fe1](https://github.com/crimera/piko/commit/3417fe15d2d558b042a44a06e9c21a1523d12540))
* **Twitter:** refactor fingerprint for tweet short text ([c00264a](https://github.com/crimera/piko/commit/c00264aebbe4717e61dd08b0998ff814f92ba3bd))

## [2.0.0-dev.6](https://github.com/crimera/piko/compare/v2.0.0-dev.5...v2.0.0-dev.6) (2025-10-18)

### Bug Fixes

* **Dynamic color:** Reflect piko's original changes ([0c91cad](https://github.com/crimera/piko/commit/0c91cad6d4112a02735edc5776a136e9f7c88271))
* **Twitter:** fix `Enable force HD videos` patch ([23f2859](https://github.com/crimera/piko/commit/23f285974c8c12a117b81c794a64e94e6f33e531))
* **Twitter:** Update `extensions` hook ([bf20765](https://github.com/crimera/piko/commit/bf2076592f49c11337acedf0d90e8a9d2d8d4ba4))

### Features

* **Twitter:** Added `Customise font` patch ([e02d7db](https://github.com/crimera/piko/commit/e02d7dbd884ac4daf7c113d44575d085ba792989))

### Updates

* **Translations:** Update `Polish` ([0983e57](https://github.com/crimera/piko/commit/0983e5723e0b6ea1a171aeefe774f64bb3993edf))

## [2.0.0-dev.5](https://github.com/crimera/piko/compare/v2.0.0-dev.4...v2.0.0-dev.5) (2025-10-14)

### Bug Fixes

* **Twitter:** Correct Db clear keyword ([ca71ea7](https://github.com/crimera/piko/commit/ca71ea73a2957e1c64e1e2ed02b64311287bfaa0))
* **Twitter:** Fix `Native reader mode` patch in 10.28 and above ([800da14](https://github.com/crimera/piko/commit/800da149f4179044296d265ff4de9e7b2737e9b8))
* **Twitter:** Fixed host name issue due to `Custom sharing domain` patch ([3b26c84](https://github.com/crimera/piko/commit/3b26c84a902200f687cd327fb83281301e653dc1))

### Features

* **Twitter:** Added `Show changelogs` patch ([4b3adf7](https://github.com/crimera/piko/commit/4b3adf7a5e8966bc800d41b947349fb36345d5f4))

### Updates

* **Translation:** `Japanese` strings ([054b2c5](https://github.com/crimera/piko/commit/054b2c5b93a43bc412e03adcb875117e513dd5bb))
* **Translation:** Added `pl` to Bring Back Twitter resource list ([44a5436](https://github.com/crimera/piko/commit/44a5436eabe9e9493984e9413ccbc74592eb8280))
* **Translation:** Added `pt-rBr` to `Bring Back Twitter` Patch ([9e33933](https://github.com/crimera/piko/commit/9e33933279bb80a40532a382726c9ddff53d43a2))
* **Translation:** Added `zh-rHK` ([58a2f4f](https://github.com/crimera/piko/commit/58a2f4fdb64d86a61ed27ad5bf632d260738688c))
* **Translation:** Fix `Vietnamese` strings ([3d1e213](https://github.com/crimera/piko/commit/3d1e213a6691216946ae703ea1ef239e56db584c))
* **Translation:** Update `Japanese` ([6c22ae2](https://github.com/crimera/piko/commit/6c22ae255149a057680ad85f6a59ce829100bb65))
* **Translation:** Update `Vietnamese` ([9343e0e](https://github.com/crimera/piko/commit/9343e0e5c750566b4a86ff72de84050950c9551a))
* **Translation:** Update Traditional Chinese ([9f4d654](https://github.com/crimera/piko/commit/9f4d654f3bf91d7e68adf0b426c02feed32d3eed))
* **Twitter:** Set Splashscreen color to blue in `Bring back twitter` patch ([fbb9a09](https://github.com/crimera/piko/commit/fbb9a093dabe0634792f6b342489ed06d75f6bc6))

## [2.0.0-dev.4](https://github.com/crimera/piko/compare/v2.0.0-dev.3...v2.0.0-dev.4) (2025-10-08)

### Updates

* **Translations:** Update `Polish` ([43da4b5](https://github.com/crimera/piko/commit/43da4b5ebc4b12d155d8f81495bbd6a09b1f44ad))

## [2.0.0-dev.3](https://github.com/crimera/piko/compare/v2.0.0-dev.2...v2.0.0-dev.3) (2025-10-04)

### Refactors

* **Twitter:** Correct ja strings replacement in BBT patch ([ee200a5](https://github.com/crimera/piko/commit/ee200a5c5ae14e1a935903b5de9e7ecf7f03e0f9))
* **Twitter:** fix `Remove promoted trends` ([0e1d4ed](https://github.com/crimera/piko/commit/0e1d4ed2ac090451172f2bed985310061b987428))
* **Twitter:** handle piko resources programmatically ([3cc0f07](https://github.com/crimera/piko/commit/3cc0f0715c6ad62c14d6cd13e91f0965886e1534))
* **Twitter:** refactor `Bring back twitter` patch ([f24cb72](https://github.com/crimera/piko/commit/f24cb72309f648493b209fffb1e7d19bd5c705f6))
* **Twitter:** remove old comments ([1655283](https://github.com/crimera/piko/commit/165528374dadeab472a5f7d28bc60be12a09bbe0))

## [2.0.0-dev.2](https://github.com/crimera/piko/compare/v2.0.0-dev.1...v2.0.0-dev.2) (2025-09-27)

### Bug Fixes

* **Twitter:** Fix remove ads on replies ([8fda05e](https://github.com/crimera/piko/commit/8fda05ec94ffc7a48dfc1eb3a17bb14f6328ca6f))
* **Universal:** Set version code as int ([ee83df7](https://github.com/crimera/piko/commit/ee83df7f8f18cf4cf2306b0a662a845ed565e106))

### Refactors

* **Twitter:** potential fix for resource compilation failing in manager ([fa0dfac](https://github.com/crimera/piko/commit/fa0dfac2b959ba9a958bb458cc4572f28ff94902))

## [2.0.0-dev.1](https://github.com/crimera/piko/compare/v1.59.0...v2.0.0-dev.1) (2025-09-24)

### ⚠ BREAKING CHANGES

* Various APIs have been changed or removed.

### Bug Fixes

* some patch has compatibleWith and dependsOn in execute block ([dd25a6c](https://github.com/crimera/piko/commit/dd25a6cd43354b8d6f4cb60d7798c539b06a6e50))
* wrong index number on multiple medias ([d088d03](https://github.com/crimera/piko/commit/d088d03a5dc743e1e50f403d14b71bc59b38571b))

### Features

* Migrate ci ([c737ca8](https://github.com/crimera/piko/commit/c737ca8edef074ff1beff17db7d27e5f26c17dc1))

## [1.59.0](https://github.com/crimera/piko/compare/v1.58.1...v1.59.0) (2025-09-11)

### Features

* **Twitter:** Added 'Native reader mode'  patch ([308e1e6](https://github.com/crimera/piko/commit/308e1e6ae392eb6c0b9ade6383957fd2983e68f5))

### Updates

* **Translations:** New translations for `pt-br` ([850aa0d](https://github.com/crimera/piko/commit/850aa0d17e0cd9a83a9c897be11b45784a82860a))
* **Translations:** Update `Polish` ([973391d](https://github.com/crimera/piko/commit/973391d6e0cfb1735dbc2102a419b9df783fa8f9))

### Refactors

* **Twitter:** consolidate native features ([79a37af](https://github.com/crimera/piko/commit/79a37afded871a185545afcd1c6a36815ec89b41))
* **Twitter:** Moved to `models` approach ([4bc56cb](https://github.com/crimera/piko/commit/4bc56cbb3de7147706786e186ebf7f2ea9df15a2))

## [1.59.0-dev.3](https://github.com/crimera/piko/compare/v1.59.0-dev.2...v1.59.0-dev.3) (2025-09-11)

### Updates

* **Translations:** New translations for `pt-br` ([850aa0d](https://github.com/crimera/piko/commit/850aa0d17e0cd9a83a9c897be11b45784a82860a))

## [1.59.0-dev.2](https://github.com/crimera/piko/compare/v1.59.0-dev.1...v1.59.0-dev.2) (2025-09-03)

### Updates

* **Translations:** Update `Polish` ([973391d](https://github.com/crimera/piko/commit/973391d6e0cfb1735dbc2102a419b9df783fa8f9))

## [1.59.0-dev.1](https://github.com/crimera/piko/compare/v1.58.1...v1.59.0-dev.1) (2025-09-02)

### Features

* **Twitter:** Added 'Native reader mode'  patch ([308e1e6](https://github.com/crimera/piko/commit/308e1e6ae392eb6c0b9ade6383957fd2983e68f5))

### Refactors

* **Twitter:** consolidate native features ([79a37af](https://github.com/crimera/piko/commit/79a37afded871a185545afcd1c6a36815ec89b41))
* **Twitter:** Moved to `models` approach ([4bc56cb](https://github.com/crimera/piko/commit/4bc56cbb3de7147706786e186ebf7f2ea9df15a2))

## [1.58.1](https://github.com/crimera/piko/compare/v1.58.0...v1.58.1) (2025-09-02)

### Updates

* **Translations:** Update `Japanese` ([c28d9c7](https://github.com/crimera/piko/commit/c28d9c7850794cb8aede686201e5d80482c42f1e))

## [1.58.1-dev.1](https://github.com/crimera/piko/compare/v1.58.0...v1.58.1-dev.1) (2025-09-01)

### Updates

* **Translations:** Update `Japanese` ([c28d9c7](https://github.com/crimera/piko/commit/c28d9c7850794cb8aede686201e5d80482c42f1e))

## [1.58.0](https://github.com/crimera/piko/compare/v1.57.1...v1.58.0) (2025-08-30)

### Features

* **Translations:** Update `Polish` ([97b3790](https://github.com/crimera/piko/commit/97b379029deba1044436cb5a983335b515e7f959))

## [1.58.0-dev.1](https://github.com/crimera/piko/compare/v1.57.1...v1.58.0-dev.1) (2025-08-21)

### Features

* **Translations:** Update `Polish` ([97b3790](https://github.com/crimera/piko/commit/97b379029deba1044436cb5a983335b515e7f959))

## [1.57.1](https://github.com/crimera/piko/compare/v1.57.0...v1.57.1) (2025-08-11)

### Bug Fixes

* Unescaped apostrophe ([487e992](https://github.com/crimera/piko/commit/487e99259b772cbf44f09028807db223f464df85))

## [1.57.1-dev.1](https://github.com/crimera/piko/compare/v1.57.0...v1.57.1-dev.1) (2025-08-11)

### Bug Fixes

* Unescaped apostrophe ([487e992](https://github.com/crimera/piko/commit/487e99259b772cbf44f09028807db223f464df85))

## [1.57.0](https://github.com/crimera/piko/compare/v1.56.0...v1.57.0) (2025-08-11)

### Bug Fixes

* **Twitter:** Fix `Customize side bar items` patch ([4664f02](https://github.com/crimera/piko/commit/4664f02c065396dc28406fe5b47478eff6b6c4aa))
* **Twitter:** Fix App icon error toast ([2997b56](https://github.com/crimera/piko/commit/2997b56f13c37681acbf89efcbd12647ee1c5056))

### Features

* **Twitter:** support custom deeplink hosts ([499cc5e](https://github.com/crimera/piko/commit/499cc5ea3e32d3e6d551755df2f94b7dbc3da9af))

### Refactors

* **Twitter:** Move redirect BM to settings patch dependancy ([4dbc491](https://github.com/crimera/piko/commit/4dbc49198ecd3a10d288f8f7cebcbca255aaa9b7))

## [1.57.0-dev.2](https://github.com/crimera/piko/compare/v1.57.0-dev.1...v1.57.0-dev.2) (2025-08-03)

### Bug Fixes

* **Twitter:** Fix `Customize side bar items` patch ([4664f02](https://github.com/crimera/piko/commit/4664f02c065396dc28406fe5b47478eff6b6c4aa))
* **Twitter:** Fix App icon error toast ([2997b56](https://github.com/crimera/piko/commit/2997b56f13c37681acbf89efcbd12647ee1c5056))

### Refactors

* **Twitter:** Move redirect BM to settings patch dependancy ([4dbc491](https://github.com/crimera/piko/commit/4dbc49198ecd3a10d288f8f7cebcbca255aaa9b7))

## [1.57.0-dev.1](https://github.com/crimera/piko/compare/v1.56.0...v1.57.0-dev.1) (2025-07-26)

### Features

* **Twitter:** support custom deeplink hosts ([499cc5e](https://github.com/crimera/piko/commit/499cc5ea3e32d3e6d551755df2f94b7dbc3da9af))

## [1.56.0](https://github.com/crimera/piko/compare/v1.55.0...v1.56.0) (2025-07-22)

### Features

* **Translations:** Update `Polish` ([e49393e](https://github.com/crimera/piko/commit/e49393eefe75118c29575324f5832c7cc3589530))
* **Twitter:** Added `Show post source label` patch ([931bc76](https://github.com/crimera/piko/commit/931bc762c3fc03535bf427b3e691f09e76271c85))

### Updates

* **Translations:** Update `Polish` ([#613](https://github.com/crimera/piko/issues/613)) ([b6ea9de](https://github.com/crimera/piko/commit/b6ea9dec045eeb5172fc1d01b1365929e127b4b0))

## [1.56.0-dev.2](https://github.com/crimera/piko/compare/v1.56.0-dev.1...v1.56.0-dev.2) (2025-07-19)

### Features

* **Translations:** Update `Polish` ([e49393e](https://github.com/crimera/piko/commit/e49393eefe75118c29575324f5832c7cc3589530))

## [1.56.0-dev.1](https://github.com/crimera/piko/compare/v1.55.1-dev.1...v1.56.0-dev.1) (2025-07-13)

### Features

* **Twitter:** Added `Show post source label` patch ([931bc76](https://github.com/crimera/piko/commit/931bc762c3fc03535bf427b3e691f09e76271c85))

## [1.55.1-dev.1](https://github.com/crimera/piko/compare/v1.55.0...v1.55.1-dev.1) (2025-07-10)

### Updates

* **Translations:** Update `Polish` ([#613](https://github.com/crimera/piko/issues/613)) ([b6ea9de](https://github.com/crimera/piko/commit/b6ea9dec045eeb5172fc1d01b1365929e127b4b0))

## [1.55.0](https://github.com/crimera/piko/compare/v1.54.2...v1.55.0) (2025-07-05)

### Bug Fixes

* **Twitter - Log server response:** Escape single qoutes ([cedbfaf](https://github.com/crimera/piko/commit/cedbfaf77913afb81b0363207a9839ea1624fa63))
* **Twitter:** `Hide community badges` patch ([f539260](https://github.com/crimera/piko/commit/f5392600b3e51a3c32fa3ffb4da5d751da3b8612))

### Features

* **Twitter:** Added `Hide community badges` patch ([57936a1](https://github.com/crimera/piko/commit/57936a167eb23eeb992ca39015149e71e04270c5))
* **Twitter:** Added `Log server response` patch ([bff4363](https://github.com/crimera/piko/commit/bff4363a56386ec6e1c80f2a57bdc70a28827be6))

## [1.55.0-dev.2](https://github.com/crimera/piko/compare/v1.55.0-dev.1...v1.55.0-dev.2) (2025-07-05)

### Bug Fixes

* **Twitter - Log server response:** Escape single qoutes ([cedbfaf](https://github.com/crimera/piko/commit/cedbfaf77913afb81b0363207a9839ea1624fa63))

## [1.55.0-dev.1](https://github.com/crimera/piko/compare/v1.54.2-dev.1...v1.55.0-dev.1) (2025-07-03)

### Bug Fixes

* **Twitter:** `Hide community badges` patch ([f539260](https://github.com/crimera/piko/commit/f5392600b3e51a3c32fa3ffb4da5d751da3b8612))

### Features

* **Twitter:** Added `Hide community badges` patch ([57936a1](https://github.com/crimera/piko/commit/57936a167eb23eeb992ca39015149e71e04270c5))
* **Twitter:** Added `Log server response` patch ([bff4363](https://github.com/crimera/piko/commit/bff4363a56386ec6e1c80f2a57bdc70a28827be6))

## [1.54.2-dev.1](https://github.com/crimera/piko/compare/v1.54.1...v1.54.2-dev.1) (2025-06-17)
=======
## [1.54.2](https://github.com/crimera/piko/compare/v1.54.1...v1.54.2) (2025-06-17)

### Bug Fixes

* **Twitter:** fix `Enable force HD videos` patch ([6d8d200](https://github.com/crimera/piko/commit/6d8d200a521375252c675117365e1fb85f701083))
* **Twitter:** fix `Hide nudge button` patch (again) ([be2cd9d](https://github.com/crimera/piko/commit/be2cd9de0aa2545274369ed0c724ffead77148ee))

## [1.54.1-dev.2](https://github.com/crimera/piko/compare/v1.54.1-dev.1...v1.54.1-dev.2) (2025-06-16)

### Bug Fixes

* **Twitter:** fix `Enable force HD videos` patch ([6d8d200](https://github.com/crimera/piko/commit/6d8d200a521375252c675117365e1fb85f701083))
* **Twitter:** fix `Hide nudge button` patch (again) ([be2cd9d](https://github.com/crimera/piko/commit/be2cd9de0aa2545274369ed0c724ffead77148ee))

## [1.54.1-dev.1](https://github.com/crimera/piko/compare/v1.54.0...v1.54.1-dev.1) (2025-06-16)

## [1.54.1](https://github.com/crimera/piko/compare/v1.54.0...v1.54.1) (2025-06-16)

### Bug Fixes

* **Twitter:** Fix unescaped characters ([829eedd](https://github.com/crimera/piko/commit/829eedd90eabc13575b49da9cc5551f894787b76))

## [1.54.0](https://github.com/crimera/piko/compare/v1.53.0...v1.54.0) (2025-06-16)

### Bug Fixes

* **Translations:** Fix unescaped strings in fr and vi ([be94c4c](https://github.com/crimera/piko/commit/be94c4c3b6785a1f9ecfdc1dbad48a4a9885a539))
* **Twitter - copy media link + Custom download folder:** Update fingerprint to work on latest twitter release ([cc8fadb](https://github.com/crimera/piko/commit/cc8fadbac2d31139ae8b9572dd1aeb2565564e75))
* **Twitter:** Fix `Enable Undo Posts` patch ([883b6cb](https://github.com/crimera/piko/commit/883b6cb92c52d1a475f6663bdf474518280b4da4))
* **Twitter:** Fix `Hide nudge button` patch ([87ceb49](https://github.com/crimera/piko/commit/87ceb49f841c99012fcbbc315edc1c4657376e37))
* **Twitter:** Fix Settings crash ([015c5bd](https://github.com/crimera/piko/commit/015c5bdd1247ec6263fa194ca6e580690e13e223))
* **Twitter:** Fix share menu patches ([ba561be](https://github.com/crimera/piko/commit/ba561be67cf5d854cfff477a3a80b85928a4170a))
* **ui:** adjust monet-light colors to have a white background ([0906e93](https://github.com/crimera/piko/commit/0906e93027747e43becd1d94bca24f54ecc97683))

### Features

* **Translations:** Add italian translation ([88e22fb](https://github.com/crimera/piko/commit/88e22fbb64eae5b2b185c0c785d75a29bb342458))
* **Translations:** Korean translation added ([492e631](https://github.com/crimera/piko/commit/492e6312df05d3bdae618e350a929a8b22914c98))
* **Translations:** Update `Japanese` ([80282f0](https://github.com/crimera/piko/commit/80282f0e4eb3b6f1cde7eb6e30f7d00ba9b26a0c))
* **Translations:** Update `Japanese` ([a7da7d7](https://github.com/crimera/piko/commit/a7da7d7468203a3244496b4ed692a8d09da18b45))

### Updates

* **Translations:** Add French & Korean to Language List ([#567](https://github.com/crimera/piko/issues/567)) ([6e139be](https://github.com/crimera/piko/commit/6e139be56dbc4f754c892d7c8ba2ed28ee8fa67f))

## [1.54.0-dev.8](https://github.com/crimera/piko/compare/v1.54.0-dev.7...v1.54.0-dev.8) (2025-06-15)

### Bug Fixes

* **Twitter:** Fix share menu patches ([ba561be](https://github.com/crimera/piko/commit/ba561be67cf5d854cfff477a3a80b85928a4170a))

## [1.54.0-dev.7](https://github.com/crimera/piko/compare/v1.54.0-dev.6...v1.54.0-dev.7) (2025-06-09)

### Bug Fixes

* **Twitter:** Fix `Enable Undo Posts` patch ([883b6cb](https://github.com/crimera/piko/commit/883b6cb92c52d1a475f6663bdf474518280b4da4))
* **Twitter:** Fix `Hide nudge button` patch ([87ceb49](https://github.com/crimera/piko/commit/87ceb49f841c99012fcbbc315edc1c4657376e37))
* **Twitter:** Fix Settings crash ([015c5bd](https://github.com/crimera/piko/commit/015c5bdd1247ec6263fa194ca6e580690e13e223))
* **ui:** adjust monet-light colors to have a white background ([0906e93](https://github.com/crimera/piko/commit/0906e93027747e43becd1d94bca24f54ecc97683))

## [1.54.0-dev.6](https://github.com/crimera/piko/compare/v1.54.0-dev.5...v1.54.0-dev.6) (2025-05-19)

### Features

* **Translations:** Update `Japanese` ([80282f0](https://github.com/crimera/piko/commit/80282f0e4eb3b6f1cde7eb6e30f7d00ba9b26a0c))

## [1.54.0-dev.5](https://github.com/crimera/piko/compare/v1.54.0-dev.4...v1.54.0-dev.5) (2025-05-09)

### Bug Fixes

* **Twitter - copy media link + Custom download folder:** Update fingerprint to work on latest twitter release ([cc8fadb](https://github.com/crimera/piko/commit/cc8fadbac2d31139ae8b9572dd1aeb2565564e75))

## [1.54.0-dev.4](https://github.com/crimera/piko/compare/v1.54.0-dev.3...v1.54.0-dev.4) (2025-04-25)

### Bug Fixes

* **Translations:** Fix unescaped strings in fr and vi ([be94c4c](https://github.com/crimera/piko/commit/be94c4c3b6785a1f9ecfdc1dbad48a4a9885a539))

## [1.54.0-dev.3](https://github.com/crimera/piko/compare/v1.54.0-dev.2...v1.54.0-dev.3) (2025-04-25)

### Updates

* **Translations:** Add French & Korean to Language List ([#567](https://github.com/crimera/piko/issues/567)) ([6e139be](https://github.com/crimera/piko/commit/6e139be56dbc4f754c892d7c8ba2ed28ee8fa67f))

## [1.54.0-dev.2](https://github.com/crimera/piko/compare/v1.54.0-dev.1...v1.54.0-dev.2) (2025-04-20)

### Features

* **Translations:** Update `Japanese` ([a7da7d7](https://github.com/crimera/piko/commit/a7da7d7468203a3244496b4ed692a8d09da18b45))

## [1.54.0-dev.1](https://github.com/crimera/piko/compare/v1.53.0...v1.54.0-dev.1) (2025-04-14)

### Features

* **Translations:** Korean translation added ([492e631](https://github.com/crimera/piko/commit/492e6312df05d3bdae618e350a929a8b22914c98))

## [1.53.0](https://github.com/crimera/piko/compare/v1.52.0...v1.53.0) (2025-04-06)

### Bug Fixes

* **Twitter - Custom Downloader:** Added VideoDataClass Fingerprint ([99ff271](https://github.com/crimera/piko/commit/99ff271b3fcbf1a6f3666b97c256528435f6501c))
* **Twitter - Custom Downloader:** Improve fingerprints ([f962310](https://github.com/crimera/piko/commit/f9623106106bd21b9b595983e8db244c8c35e227))

### Features

* **Translations:** Update `Polish` ([d81f93c](https://github.com/crimera/piko/commit/d81f93cff2c31c9fe82ff8e43598ab90e6d899ab))

## [1.53.0-dev.1](https://github.com/crimera/piko/compare/v1.52.0...v1.53.0-dev.1) (2025-04-06)

### Bug Fixes

* **Twitter - Custom Downloader:** Added VideoDataClass Fingerprint ([99ff271](https://github.com/crimera/piko/commit/99ff271b3fcbf1a6f3666b97c256528435f6501c))
* **Twitter - Custom Downloader:** Improve fingerprints ([f962310](https://github.com/crimera/piko/commit/f9623106106bd21b9b595983e8db244c8c35e227))

### Features

* **Translations:** Update `Polish` ([d81f93c](https://github.com/crimera/piko/commit/d81f93cff2c31c9fe82ff8e43598ab90e6d899ab))

## [1.52.0-dev.1](https://github.com/crimera/piko/compare/v1.51.2-dev.1...v1.52.0-dev.1) (2025-04-05)

### Features

* **Translations:** Update `Polish` ([d81f93c](https://github.com/crimera/piko/commit/d81f93cff2c31c9fe82ff8e43598ab90e6d899ab))

## [1.51.2-dev.1](https://github.com/crimera/piko/compare/v1.51.1...v1.51.2-dev.1) (2025-04-05)

### Bug Fixes

* **Twitter - Custom Downloader:** Added VideoDataClass Fingerprint ([99ff271](https://github.com/crimera/piko/commit/99ff271b3fcbf1a6f3666b97c256528435f6501c))
* **Twitter - Custom Downloader:** Improve fingerprints ([f962310](https://github.com/crimera/piko/commit/f9623106106bd21b9b595983e8db244c8c35e227))

## [1.52.0](https://github.com/crimera/piko/compare/v1.51.1...v1.52.0) (2025-04-06)

### Features

* **Translations:** French translation added ([a6f650c](https://github.com/crimera/piko/commit/a6f650c3cbea3b3964fc4b58962067

## [1.51.1](https://github.com/crimera/piko/compare/v1.51.0...v1.51.1) (2025-03-26)

### Bug Fixes

* Add support for 10.83.0 releases ([9344d52](https://github.com/crimera/piko/commit/9344d527d1ec5e0fd812bd835c45304a6619df95))

## [1.51.1-dev.1](https://github.com/crimera/piko/compare/v1.51.0...v1.51.1-dev.1) (2025-03-20)

### Bug Fixes

* Add support for 10.83.0 releases ([9344d52](https://github.com/crimera/piko/commit/9344d527d1ec5e0fd812bd835c45304a6619df95))

## [1.51.0](https://github.com/crimera/piko/compare/v1.50.0...v1.51.0) (2025-03-20)

### Bug Fixes

* Add back settings for the custom sharemenu buttons ([bc7e777](https://github.com/crimera/piko/commit/bc7e777e59091801238d4692823415b0d7d2855b))
* Adding debug menu patch results in a crash ([caf82eb](https://github.com/crimera/piko/commit/caf82ebd95bd113dbd5cacda1deffa9194cb280b))
* **Bring back twitter:** Resource compilation fails on ReVanced Manager ([a364bec](https://github.com/crimera/piko/commit/a364becc7f6f70724c37b9499e79885fb09f0436))
* **Enable Reader Mode:** Specify the compatible version, show a warning instead of throwing an exception when failed ([b1c52e7](https://github.com/crimera/piko/commit/b1c52e73daabe3222e925ba5d6b866af31a35045))
* **Remove Detailed posts:** Change the settings label from "detailed" to "related" ([3cf5f9e](https://github.com/crimera/piko/commit/3cf5f9ec9e383deb17919f2b3c5254954502c825))
* Remove obsolete `Open browser chooser on opening links` patch ([a1e2b76](https://github.com/crimera/piko/commit/a1e2b766a872c3ee2facef1444bfa92ab4236144))

### Features

* **Settings:** Add a description to "Native features" page ([be7aa54](https://github.com/crimera/piko/commit/be7aa5472c9b12ff6207992b21292b4fb4d337cf))

### Updates

* Improve adding new buttons in share menu ([16cc3bd](https://github.com/crimera/piko/commit/16cc3bd01c03bfc800d61f0844b455c5d086422a))

## [1.51.0-dev.4](https://github.com/crimera/piko/compare/v1.51.0-dev.3...v1.51.0-dev.4) (2025-03-20)

### Bug Fixes

* Adding debug menu patch results in a crash ([caf82eb](https://github.com/crimera/piko/commit/caf82ebd95bd113dbd5cacda1deffa9194cb280b))

## [1.51.0-dev.3](https://github.com/crimera/piko/compare/v1.51.0-dev.2...v1.51.0-dev.3) (2025-03-20)

### Bug Fixes

* Add back settings for the custom sharemenu buttons ([bc7e777](https://github.com/crimera/piko/commit/bc7e777e59091801238d4692823415b0d7d2855b))

## [1.51.0-dev.2](https://github.com/crimera/piko/compare/v1.51.0-dev.1...v1.51.0-dev.2) (2025-03-20)

### Updates

* Improve adding new buttons in share menu ([16cc3bd](https://github.com/crimera/piko/commit/16cc3bd01c03bfc800d61f0844b455c5d086422a))

## [1.51.0-dev.1](https://github.com/crimera/piko/compare/v1.50.0...v1.51.0-dev.1) (2025-03-17)

### Bug Fixes

* **Bring back twitter:** Resource compilation fails on ReVanced Manager ([a364bec](https://github.com/crimera/piko/commit/a364becc7f6f70724c37b9499e79885fb09f0436))
* **Enable Reader Mode:** Specify the compatible version, show a warning instead of throwing an exception when failed ([b1c52e7](https://github.com/crimera/piko/commit/b1c52e73daabe3222e925ba5d6b866af31a35045))
* **Remove Detailed posts:** Change the settings label from "detailed" to "related" ([3cf5f9e](https://github.com/crimera/piko/commit/3cf5f9ec9e383deb17919f2b3c5254954502c825))
* Remove obsolete `Open browser chooser on opening links` patch ([a1e2b76](https://github.com/crimera/piko/commit/a1e2b766a872c3ee2facef1444bfa92ab4236144))

### Features

* **Settings:** Add a description to "Native features" page ([be7aa54](https://github.com/crimera/piko/commit/be7aa5472c9b12ff6207992b21292b4fb4d337cf))

## [1.50.0](https://github.com/crimera/piko/compare/v1.49.1...v1.50.0) (2025-02-08)

### Features

* **Translations:** Update `Japanese` ([039aac3](https://github.com/crimera/piko/commit/039aac304215858769c794684f837719edad9790))

## [1.50.0-dev.1](https://github.com/crimera/piko/compare/v1.49.1...v1.50.0-dev.1) (2025-01-31)

### Features

* **Translations:** Update `Japanese` ([039aac3](https://github.com/crimera/piko/commit/039aac304215858769c794684f837719edad9790))

## [1.49.1](https://github.com/crimera/piko/compare/v1.49.0...v1.49.1) (2025-01-29)

### Bug Fixes

* **Twitter:** fix `Custom downloader` patch ([f4d953a](https://github.com/crimera/piko/commit/f4d953a3dc7cb8325e56e515cd38a8ab707d2162))
* **Twitter:** fix `Custom translator` patch ([8065fa3](https://github.com/crimera/piko/commit/8065fa32019d1d1bd4c9bd116f1774e345203356))
* **Twitter:** fix `Enable debug menu for posts` patch ([72a72f2](https://github.com/crimera/piko/commit/72a72f2114d0ee9fe2cac0e5eae5b03e196dd6e2))

### Refactors

* **Twitter:** refactor button class Hook ([2bf411a](https://github.com/crimera/piko/commit/2bf411a61fd5181d5266d1496becf7b93f4d0d08))
* **Twitter:** Removed unused string from pt-BR ([cdb2067](https://github.com/crimera/piko/commit/cdb2067360944309a9156b71bf9776457c44c49a))

## [1.49.1-dev.1](https://github.com/crimera/piko/compare/v1.49.0...v1.49.1-dev.1) (2025-01-28)

### Bug Fixes

* **Twitter:** fix `Custom downloader` patch ([f4d953a](https://github.com/crimera/piko/commit/f4d953a3dc7cb8325e56e515cd38a8ab707d2162))
* **Twitter:** fix `Custom translator` patch ([8065fa3](https://github.com/crimera/piko/commit/8065fa32019d1d1bd4c9bd116f1774e345203356))
* **Twitter:** fix `Enable debug menu for posts` patch ([72a72f2](https://github.com/crimera/piko/commit/72a72f2114d0ee9fe2cac0e5eae5b03e196dd6e2))

### Refactors

* **Twitter:** refactor button class Hook ([2bf411a](https://github.com/crimera/piko/commit/2bf411a61fd5181d5266d1496becf7b93f4d0d08))
* **Twitter:** Removed unused string from pt-BR ([cdb2067](https://github.com/crimera/piko/commit/cdb2067360944309a9156b71bf9776457c44c49a))

## [1.49.0](https://github.com/crimera/piko/compare/v1.48.0...v1.49.0) (2025-01-28)

### Features

* **Twitter:** Added `Remove Todays news` patch ([8324633](https://github.com/crimera/piko/commit/8324633509fdf61756751fdde67e5752ff3dee5c))

### Refactors

* **Twitter:** refactor strings-pl ([9aacfa1](https://github.com/crimera/piko/commit/9aacfa1baf7ed0301850f30ae8053c101ef8b27b))

## [1.49.0-dev.1](https://github.com/crimera/piko/compare/v1.48.0...v1.49.0-dev.1) (2025-01-22)

### Features

* **Twitter:** Added `Remove Todays news` patch ([8324633](https://github.com/crimera/piko/commit/8324633509fdf61756751fdde67e5752ff3dee5c))

### Refactors

* **Twitter:** refactor strings-pl ([9aacfa1](https://github.com/crimera/piko/commit/9aacfa1baf7ed0301850f30ae8053c101ef8b27b))

## [1.48.0](https://github.com/crimera/piko/compare/v1.47.1...v1.48.0) (2025-01-07)

### Features

* **Translations:** Updated Traditional Chinese string-zh-rCN.xml ([6cc2373](https://github.com/crimera/piko/commit/6cc2373e417a1ed386a2682f970662e367033b43))
* **Translations:** Updated Traditional Chinese string-zh-rTW.xml ([6787c28](https://github.com/crimera/piko/commit/6787c28318762382d73f1eb8c6ad9abc4b2ee2e6))

### Refactors

* **Twitter:** Added 'Native features' section ([12d2bda](https://github.com/crimera/piko/commit/12d2bdaafd111eee81f22bdafa306c3493754c80))
* **Twitter:** Added Native download filename customization ([99a10b1](https://github.com/crimera/piko/commit/99a10b1615ffa3fb72df0ad283255e9c837a012f))

## [1.48.0-dev.2](https://github.com/crimera/piko/compare/v1.48.0-dev.1...v1.48.0-dev.2) (2024-12-24)

### Refactors

* **Twitter:** Added 'Native features' section ([12d2bda](https://github.com/crimera/piko/commit/12d2bdaafd111eee81f22bdafa306c3493754c80))
* **Twitter:** Added Native download filename customization ([99a10b1](https://github.com/crimera/piko/commit/99a10b1615ffa3fb72df0ad283255e9c837a012f))

## [1.48.0-dev.1](https://github.com/crimera/piko/compare/v1.47.1-dev.1...v1.48.0-dev.1) (2024-12-22)

### Features

* **Translations:** Updated Traditional Chinese string-zh-rCN.xml ([6cc2373](https://github.com/crimera/piko/commit/6cc2373e417a1ed386a2682f970662e367033b43))
* **Translations:** Updated Traditional Chinese string-zh-rTW.xml ([6787c28](https://github.com/crimera/piko/commit/6787c28318762382d73f1eb8c6ad9abc4b2ee2e6))

## [1.47.1-dev.1](https://github.com/crimera/piko/compare/v1.47.0...v1.47.1-dev.1) (2024-12-22)

### Bug Fixes

* Improve getUsername fingerprint ([af617af](https://github.com/crimera/piko/commit/af617af523bfa7df00a232a51364ea9e8ea4d34f))

## [1.47.0](https://github.com/crimera/piko/compare/v1.46.1...v1.47.0) (2024-12-14)

### Features

* **Twitter:** Added `Customize search suggestions` patch ([aaca565](https://github.com/crimera/piko/commit/aaca565c650d6cf4b2cbb8abf2e206efe9983cb1))
* **Twitter:** Added `Customize search tab items` patch ([9edc97a](https://github.com/crimera/piko/commit/9edc97a89e61f28a5cd9a419d167a6c51a1a9816))
* **Twitter:** Added `Remove top people in search` patch ([95b5ef9](https://github.com/crimera/piko/commit/95b5ef902e6f595093b2304e5b2a8189f273389c))

### Refactors

* **Twitter:** Strings in 'Customization' ([c52c2c0](https://github.com/crimera/piko/commit/c52c2c01948bdea5593636a99502d8b5c6c41dca))
* **Twitter:** Strings in 'Customization' ([a75221b](https://github.com/crimera/piko/commit/a75221b80c1d3223b88890a95ca1610432defbe2))

## [1.47.0-dev.1](https://github.com/crimera/piko/compare/v1.46.1...v1.47.0-dev.1) (2024-12-09)

### Features

* **Twitter:** Added `Customize search suggestions` patch ([aaca565](https://github.com/crimera/piko/commit/aaca565c650d6cf4b2cbb8abf2e206efe9983cb1))
* **Twitter:** Added `Customize search tab items` patch ([9edc97a](https://github.com/crimera/piko/commit/9edc97a89e61f28a5cd9a419d167a6c51a1a9816))
* **Twitter:** Added `Remove top people in search` patch ([95b5ef9](https://github.com/crimera/piko/commit/95b5ef902e6f595093b2304e5b2a8189f273389c))

### Refactors

* **Twitter:** Strings in 'Customization' ([c52c2c0](https://github.com/crimera/piko/commit/c52c2c01948bdea5593636a99502d8b5c6c41dca))
* **Twitter:** Strings in 'Customization' ([a75221b](https://github.com/crimera/piko/commit/a75221b80c1d3223b88890a95ca1610432defbe2))

## [1.46.1](https://github.com/crimera/piko/compare/v1.46.0...v1.46.1) (2024-12-04)

### Refactors

* **Twitter:** Changed `Top Articles ` string ([b590695](https://github.com/crimera/piko/commit/b5906957cb8cda07a40e02008b5ad69ad6389637))

## [1.46.1-dev.1](https://github.com/crimera/piko/compare/v1.46.0...v1.46.1-dev.1) (2024-12-03)

### Refactors

* **Twitter:** Changed `Top Articles ` string ([b590695](https://github.com/crimera/piko/commit/b5906957cb8cda07a40e02008b5ad69ad6389637))

## [1.46.0](https://github.com/crimera/piko/compare/v1.45.1...v1.46.0) (2024-12-01)

### Features

* **Twitter:** Added `Customize explore tabs` patch ([4be6a7f](https://github.com/crimera/piko/commit/4be6a7fe6ace42ca299d2e4bc7f9a963774f3bcd))

## [1.46.0-dev.1](https://github.com/crimera/piko/compare/v1.45.1...v1.46.0-dev.1) (2024-11-27)

### Features

* **Twitter:** Added `Customize explore tabs` patch ([4be6a7f](https://github.com/crimera/piko/commit/4be6a7fe6ace42ca299d2e4bc7f9a963774f3bcd))

## [1.45.1](https://github.com/crimera/piko/compare/v1.45.0...v1.45.1) (2024-11-27)

### Bug Fixes

* **Twitter:** Change patch name from `Enable app icon settings` -> `Enable app icons` ([5a7ef46](https://github.com/crimera/piko/commit/5a7ef469557e5cf4ecc9ce8465d73c20501dc524))

### Refactors

* **Twitter:** Added toggle for `Show sensitive media` patch ([cac4fe7](https://github.com/crimera/piko/commit/cac4fe747640e37dc9155c63f23082c44963c05d))

## [1.45.1-dev.2](https://github.com/crimera/piko/compare/v1.45.1-dev.1...v1.45.1-dev.2) (2024-11-25)

### Refactors

* **Twitter:** Added toggle for `Show sensitive media` patch ([cac4fe7](https://github.com/crimera/piko/commit/cac4fe747640e37dc9155c63f23082c44963c05d))

## [1.45.1-dev.1](https://github.com/crimera/piko/compare/v1.45.0...v1.45.1-dev.1) (2024-11-24)

### Bug Fixes

* **Twitter:** Change patch name from `Enable app icon settings` -> `Enable app icons` ([5a7ef46](https://github.com/crimera/piko/commit/5a7ef469557e5cf4ecc9ce8465d73c20501dc524))

## [1.45.0](https://github.com/crimera/piko/compare/v1.44.0...v1.45.0) (2024-11-14)

### Bug Fixes

* **Twitter:** Share menu button add hook in/from 10.67 ([a640946](https://github.com/crimera/piko/commit/a640946e7045be359535ed0eead00ec80d2e10c4))

### Features

* **Twitter:** Added `Customise post font size` patch ([ea608e0](https://github.com/crimera/piko/commit/ea608e09b7b0775f38ca1914503e1b54dc7b73f9))

### Refactors

* **Twitter:** refactor values of list preference ([e0e5c5b](https://github.com/crimera/piko/commit/e0e5c5b8639efcd5eecd6476bc59b7f125d5b851))

### Perfomance

* **Bring back twitter:** Optimize string replacement ([#440](https://github.com/crimera/piko/issues/440)) ([7e61023](https://github.com/crimera/piko/commit/7e6102351d9488f89489f87df2ec45d6d0d178d8))

## [1.45.0-dev.1](https://github.com/crimera/piko/compare/v1.44.1-dev.2...v1.45.0-dev.1) (2024-11-12)

### Features

* **Twitter:** Added `Customise post font size` patch ([ea608e0](https://github.com/crimera/piko/commit/ea608e09b7b0775f38ca1914503e1b54dc7b73f9))

## [1.44.1-dev.2](https://github.com/crimera/piko/compare/v1.44.1-dev.1...v1.44.1-dev.2) (2024-11-11)

### Perfomance

* **Bring back twitter:** Optimize string replacement ([#440](https://github.com/crimera/piko/issues/440)) ([7e61023](https://github.com/crimera/piko/commit/7e6102351d9488f89489f87df2ec45d6d0d178d8))

## [1.44.1-dev.1](https://github.com/crimera/piko/compare/v1.44.0...v1.44.1-dev.1) (2024-11-09)

### Bug Fixes

* **Twitter:** Share menu button add hook in/from 10.67 ([a640946](https://github.com/crimera/piko/commit/a640946e7045be359535ed0eead00ec80d2e10c4))

### Refactors

* **Twitter:** refactor values of list preference ([e0e5c5b](https://github.com/crimera/piko/commit/e0e5c5b8639efcd5eecd6476bc59b7f125d5b851))

## [1.44.0](https://github.com/crimera/piko/compare/v1.43.0...v1.44.0) (2024-11-06)

### Features

* **Twitter:** Added `Custom translator` patch ([737fb9e](https://github.com/crimera/piko/commit/737fb9eaa0b8da7f020b93c314f5da60f961e345))

### Refactors

* **Twitter:** Change translator icon ([bf5f027](https://github.com/crimera/piko/commit/bf5f027f80507cf0db5b3dfd208d26b131987eca))
* **Twitter:** refactor `Custom downloader` patch ([42cc752](https://github.com/crimera/piko/commit/42cc752c599f978f455f84ae9a917f7bb457af98))
* **Twitter:** Refactor `Custom downloader` patch ([1e966f7](https://github.com/crimera/piko/commit/1e966f7f519b7d947e0b516f8bc0ca0c55c1d623))
* **Twitter:** Refactor hooks filename ([2daa292](https://github.com/crimera/piko/commit/2daa2922c7225711fd1aa5d0556493e068026e0a))
* **Twitter:** renamed 'Share menu button' fingerprints to hooks ([395c221](https://github.com/crimera/piko/commit/395c2217fc5f5b18cdc76568c3845140f76940d6))

## [1.44.0-dev.1](https://github.com/crimera/piko/compare/v1.43.0...v1.44.0-dev.1) (2024-11-02)

### Features

* **Twitter:** Added `Custom translator` patch ([737fb9e](https://github.com/crimera/piko/commit/737fb9eaa0b8da7f020b93c314f5da60f961e345))

### Refactors

* **Twitter:** Change translator icon ([bf5f027](https://github.com/crimera/piko/commit/bf5f027f80507cf0db5b3dfd208d26b131987eca))
* **Twitter:** refactor `Custom downloader` patch ([42cc752](https://github.com/crimera/piko/commit/42cc752c599f978f455f84ae9a917f7bb457af98))
* **Twitter:** Refactor `Custom downloader` patch ([1e966f7](https://github.com/crimera/piko/commit/1e966f7f519b7d947e0b516f8bc0ca0c55c1d623))
* **Twitter:** Refactor hooks filename ([2daa292](https://github.com/crimera/piko/commit/2daa2922c7225711fd1aa5d0556493e068026e0a))
* **Twitter:** renamed 'Share menu button' fingerprints to hooks ([395c221](https://github.com/crimera/piko/commit/395c2217fc5f5b18cdc76568c3845140f76940d6))

## [1.43.0](https://github.com/crimera/piko/compare/v1.42.1...v1.43.0) (2024-10-29)

### Bug Fixes

* Remove debug prints ([33e4d08](https://github.com/crimera/piko/commit/33e4d08a58451217781914953c1ffb711ea8480b))

### Features

* **Customize side bar items:** Allow for hiding of the "Jobs" item ([14ce811](https://github.com/crimera/piko/commit/14ce811a7b4d885fa6779524aad0b41034a2d8d0))

## [1.43.0-dev.1](https://github.com/crimera/piko/compare/v1.42.2-dev.1...v1.43.0-dev.1) (2024-10-26)

### Features

* **Customize side bar items:** Allow for hiding of the "Jobs" item ([14ce811](https://github.com/crimera/piko/commit/14ce811a7b4d885fa6779524aad0b41034a2d8d0))

## [1.42.2-dev.1](https://github.com/crimera/piko/compare/v1.42.1...v1.42.2-dev.1) (2024-10-26)

### Bug Fixes

* Remove debug prints ([33e4d08](https://github.com/crimera/piko/commit/33e4d08a58451217781914953c1ffb711ea8480b))

## [1.42.1](https://github.com/crimera/piko/compare/v1.42.0...v1.42.1) (2024-10-24)

### Bug Fixes

* **Bring back twitter:** Change the character "𝕏" into "Twitter". ([#441](https://github.com/crimera/piko/issues/441)) ([c20e16f](https://github.com/crimera/piko/commit/c20e16f80499df75176e9080f156e529f4f7d326))
* **Custom download folder:** Restore compatibility with versions prior to 10.64 ([b88b00b](https://github.com/crimera/piko/commit/b88b00ba97632d62517c0e52a924c453ea022d7a))
* **Custom downloader:** Improve fingerprint ([2a2a4a4](https://github.com/crimera/piko/commit/2a2a4a4e2cdc6587c5c3b91bb3888918d7cd720d))
* Resource strings getting corrupted, resulting on failure to patch on revanced manager ([#439](https://github.com/crimera/piko/issues/439)) ([1763137](https://github.com/crimera/piko/commit/1763137126b9a95df51fe23ce816853ccf0a8f44))
* **Twitter:** Add support for version 10.64.0-beta.1 ([c81378d](https://github.com/crimera/piko/commit/c81378d80275465acbf9caed5f48235b56395d56))

### Refactors

* **Custom Downloader:** Improve getting of tweet method declarations ([5237e49](https://github.com/crimera/piko/commit/5237e496140cc94fb9beb4a72057d927527dd78b))

## [1.42.1-dev.6](https://github.com/crimera/piko/compare/v1.42.1-dev.5...v1.42.1-dev.6) (2024-10-23)

### Bug Fixes

* **Custom downloader:** Improve fingerprint ([2a2a4a4](https://github.com/crimera/piko/commit/2a2a4a4e2cdc6587c5c3b91bb3888918d7cd720d))

## [1.42.1-dev.5](https://github.com/crimera/piko/compare/v1.42.1-dev.4...v1.42.1-dev.5) (2024-10-22)

### Bug Fixes

* **Bring back twitter:** Change the character "𝕏" into "Twitter". ([#441](https://github.com/crimera/piko/issues/441)) ([c20e16f](https://github.com/crimera/piko/commit/c20e16f80499df75176e9080f156e529f4f7d326))

## [1.42.1-dev.4](https://github.com/crimera/piko/compare/v1.42.1-dev.3...v1.42.1-dev.4) (2024-10-21)

### Bug Fixes

* **Custom download folder:** Restore compatibility with versions prior to 10.64 ([b88b00b](https://github.com/crimera/piko/commit/b88b00ba97632d62517c0e52a924c453ea022d7a))

## [1.42.1-dev.3](https://github.com/crimera/piko/compare/v1.42.1-dev.2...v1.42.1-dev.3) (2024-10-20)

### Bug Fixes

* Resource strings getting corrupted, resulting on failure to patch on revanced manager ([#439](https://github.com/crimera/piko/issues/439)) ([1763137](https://github.com/crimera/piko/commit/1763137126b9a95df51fe23ce816853ccf0a8f44))

## [1.42.1-dev.2](https://github.com/crimera/piko/compare/v1.42.1-dev.1...v1.42.1-dev.2) (2024-10-20)

### Refactors

* **Custom Downloader:** Improve getting of tweet method declarations ([5237e49](https://github.com/crimera/piko/commit/5237e496140cc94fb9beb4a72057d927527dd78b))

## [1.42.1-dev.1](https://github.com/crimera/piko/compare/v1.42.0...v1.42.1-dev.1) (2024-10-20)

### Bug Fixes

* **Twitter:** Add support for version 10.64.0-beta.1 ([c81378d](https://github.com/crimera/piko/commit/c81378d80275465acbf9caed5f48235b56395d56))

## [1.42.0](https://github.com/crimera/piko/compare/v1.41.0...v1.42.0) (2024-10-15)

### Bug Fixes

* **Remove Google Ad:** Include ads in the comments ([79d6e35](https://github.com/crimera/piko/commit/79d6e35144ffc6c81d3bb36499fc2c22e5a089ac))

### Features

* **Bring back twitter:** Add Japanese ([4eb08b5](https://github.com/crimera/piko/commit/4eb08b554eaf92958e0e159647fc71b35340e2b2))

### Updates

* **Translations:** Update `Japanese` ([b326d10](https://github.com/crimera/piko/commit/b326d10599db407e1e922ac8d6d2694a67c6e42b))

## [1.42.0-dev.2](https://github.com/crimera/piko/compare/v1.42.0-dev.1...v1.42.0-dev.2) (2024-10-15)

### Bug Fixes

* **Remove Google Ad:** Include ads in the comments ([79d6e35](https://github.com/crimera/piko/commit/79d6e35144ffc6c81d3bb36499fc2c22e5a089ac))

## [1.42.0-dev.1](https://github.com/crimera/piko/compare/v1.41.1-dev.1...v1.42.0-dev.1) (2024-10-13)

### Features

* **Bring back twitter:** Add Japanese ([4eb08b5](https://github.com/crimera/piko/commit/4eb08b554eaf92958e0e159647fc71b35340e2b2))

## [1.41.1-dev.1](https://github.com/crimera/piko/compare/v1.41.0...v1.41.1-dev.1) (2024-10-09)

### Updates

* **Translations:** Update `Japanese` ([b326d10](https://github.com/crimera/piko/commit/b326d10599db407e1e922ac8d6d2694a67c6e42b))

## [1.41.0](https://github.com/crimera/piko/compare/v1.40.0...v1.41.0) (2024-10-03)

### Bug Fixes

* **Twitter:** Fix `Hide nudge button` patch ([d7572fe](https://github.com/crimera/piko/commit/d7572feac66d44f0fe669073ee09bc09637adb9a))

### Features

* **Twitter:** Added `Hide followed by context` patch ([261e1d0](https://github.com/crimera/piko/commit/261e1d0156702a4a72105b430d50e59e88795198))

## [1.41.0-dev.1](https://github.com/crimera/piko/compare/v1.40.0...v1.41.0-dev.1) (2024-09-27)

### Bug Fixes

* **Twitter:** Fix `Hide nudge button` patch ([d7572fe](https://github.com/crimera/piko/commit/d7572feac66d44f0fe669073ee09bc09637adb9a))

### Features

* **Twitter:** Added `Hide followed by context` patch ([261e1d0](https://github.com/crimera/piko/commit/261e1d0156702a4a72105b430d50e59e88795198))

## [1.40.0](https://github.com/crimera/piko/compare/v1.39.3...v1.40.0) (2024-09-25)

### Features

* **Twitter:** Added `Hide nudge button` patch ([ad27484](https://github.com/crimera/piko/commit/ad27484f4cc0d727cf07cb4f202c8ddd6b582d67))

## [1.40.0-dev.1](https://github.com/crimera/piko/compare/v1.39.3...v1.40.0-dev.1) (2024-09-25)

### Features

* **Twitter:** Added `Hide nudge button` patch ([ad27484](https://github.com/crimera/piko/commit/ad27484f4cc0d727cf07cb4f202c8ddd6b582d67))

## [1.39.3](https://github.com/crimera/piko/compare/v1.39.2...v1.39.3) (2024-09-11)

### Updates

* **Translations:** Update translations ([9686863](https://github.com/crimera/piko/commit/968686390263fa700488deb5d87085470267c7cf))

## [1.39.2](https://github.com/crimera/piko/compare/v1.39.1...v1.39.2) (2024-09-09)

### Bug Fixes

* **Twitter:** fix `Control video auto scroll` in 10.57 ([b7ae78c](https://github.com/crimera/piko/commit/b7ae78cd61b2f75d266e3fe3d57c5c21cd798e79))
* **Twitter:** fix `Enable app icon settings` patch ([c2b6f79](https://github.com/crimera/piko/commit/c2b6f79b5c833c2441432b2511374361318e5507))
* **Twitter:** fix video entity hook in `10.58` ([e8a833d](https://github.com/crimera/piko/commit/e8a833d2123b92a40caf68b4f6798e822a6d1737))

## [1.39.2-dev.2](https://github.com/crimera/piko/compare/v1.39.2-dev.1...v1.39.2-dev.2) (2024-09-09)

### Bug Fixes

* **Twitter:** fix `Enable app icon settings` patch ([c2b6f79](https://github.com/crimera/piko/commit/c2b6f79b5c833c2441432b2511374361318e5507))
* **Twitter:** fix video entity hook in `10.58` ([e8a833d](https://github.com/crimera/piko/commit/e8a833d2123b92a40caf68b4f6798e822a6d1737))

## [1.39.2-dev.1](https://github.com/crimera/piko/compare/v1.39.1...v1.39.2-dev.1) (2024-09-05)

### Bug Fixes

* **Twitter:** fix `Control video auto scroll` in 10.57 ([b7ae78c](https://github.com/crimera/piko/commit/b7ae78cd61b2f75d266e3fe3d57c5c21cd798e79))

## [1.39.1](https://github.com/crimera/piko/compare/v1.39.0...v1.39.1) (2024-08-30)

### Bug Fixes

* Remove duplicate strings ([94c6642](https://github.com/crimera/piko/commit/94c66422e0ced2cbdfd820dfee60cedd2c68e636))

## [1.39.0](https://github.com/crimera/piko/compare/v1.38.0...v1.39.0) (2024-08-30)

### Features

* **Twitter:** Custom deeplinks ([325a281](https://github.com/crimera/piko/commit/325a281225b1379b310d8ba14629bdbae0b314e5))

### Updates

* **Twitter:** Added strings ([fad9b1a](https://github.com/crimera/piko/commit/fad9b1a9fd79b164c713fe35b61bad8ed3d9373b))
* **Twitter:** Change Quick Btn path ([7febdf6](https://github.com/crimera/piko/commit/7febdf612212ba61638fd818121c8cc4b9db8ed8))
* **Twitter:** Updated strings ([3cb159e](https://github.com/crimera/piko/commit/3cb159e57d66e22b7c2f638e5d0b7422a4ef2a10))

## [1.39.0-dev.1](https://github.com/crimera/piko/compare/v1.38.0...v1.39.0-dev.1) (2024-08-25)

### Features

* **Twitter:** Custom deeplinks ([325a281](https://github.com/crimera/piko/commit/325a281225b1379b310d8ba14629bdbae0b314e5))

### Updates

* **Twitter:** Added strings ([fad9b1a](https://github.com/crimera/piko/commit/fad9b1a9fd79b164c713fe35b61bad8ed3d9373b))
* **Twitter:** Change Quick Btn path ([7febdf6](https://github.com/crimera/piko/commit/7febdf612212ba61638fd818121c8cc4b9db8ed8))
* **Twitter:** Updated strings ([3cb159e](https://github.com/crimera/piko/commit/3cb159e57d66e22b7c2f638e5d0b7422a4ef2a10))

## [1.38.0](https://github.com/crimera/piko/compare/v1.37.1...v1.38.0) (2024-08-20)

### Bug Fixes

* **Feature Flags:** Use ListView instead of RecyclerView for a more reliable list. ([6f16b7f](https://github.com/crimera/piko/commit/6f16b7f7d61c81e7a21394f74b6e0d0e80ed9a55))

### Features

* **Twitter:** Added `Enable force HD videos` patch ([d316612](https://github.com/crimera/piko/commit/d3166121ac39adf45440e6888b43487e398f61e6))

### Updates

* **Twitter:** Updated `Enable force HD videos` patch description ([86ea041](https://github.com/crimera/piko/commit/86ea0418d3606b6e04f8fbea8fc530aba5316f0f))

## [1.38.0-dev.1](https://github.com/crimera/piko/compare/v1.37.2-dev.1...v1.38.0-dev.1) (2024-08-18)

### Features

* **Twitter:** Added `Enable force HD videos` patch ([d316612](https://github.com/crimera/piko/commit/d3166121ac39adf45440e6888b43487e398f61e6))

### Updates

* **Twitter:** Updated `Enable force HD videos` patch description ([86ea041](https://github.com/crimera/piko/commit/86ea0418d3606b6e04f8fbea8fc530aba5316f0f))

## [1.37.2-dev.1](https://github.com/crimera/piko/compare/v1.37.1...v1.37.2-dev.1) (2024-08-18)

### Bug Fixes

* **Feature Flags:** Use ListView instead of RecyclerView for a more reliable list. ([6f16b7f](https://github.com/crimera/piko/commit/6f16b7f7d61c81e7a21394f74b6e0d0e80ed9a55))

## [1.37.1](https://github.com/crimera/piko/compare/v1.37.0...v1.37.1) (2024-08-17)

### Updates

* **Twitter:** Added hide 'Settings and privacy' in `Customize side bar items` ([cb01885](https://github.com/crimera/piko/commit/cb018852c8af8caaf4b986444208ab00a39eab41))

## [1.37.1-dev.1](https://github.com/crimera/piko/compare/v1.37.0...v1.37.1-dev.1) (2024-08-16)

### Updates

* **Twitter:** Added hide 'Settings and privacy' in `Customize side bar items` ([cb01885](https://github.com/crimera/piko/commit/cb018852c8af8caaf4b986444208ab00a39eab41))

## [1.37.0](https://github.com/crimera/piko/compare/v1.36.0...v1.37.0) (2024-08-15)

### Features

* Enable recent patches by default ([e84f358](https://github.com/crimera/piko/commit/e84f358e494830fdecdc3dd12662b5f5ccd644b3))
* Quick settings button is now optional ([e9e54e5](https://github.com/crimera/piko/commit/e9e54e5e44437b92db9700c363f0abd9117cc325))

### Updates

* Improve quick settings appearance ([6dc27b4](https://github.com/crimera/piko/commit/6dc27b4a888d0028e455be1e1b41b83cdd7f7940))

## [1.37.0-dev.3](https://github.com/crimera/piko/compare/v1.37.0-dev.2...v1.37.0-dev.3) (2024-08-15)

### Features

* Quick settings button is now optional ([e9e54e5](https://github.com/crimera/piko/commit/e9e54e5e44437b92db9700c363f0abd9117cc325))

## [1.37.0-dev.2](https://github.com/crimera/piko/compare/v1.37.0-dev.1...v1.37.0-dev.2) (2024-08-14)

### Updates

* Improve quick settings appearance ([6dc27b4](https://github.com/crimera/piko/commit/6dc27b4a888d0028e455be1e1b41b83cdd7f7940))

## [1.37.0-dev.1](https://github.com/crimera/piko/compare/v1.36.0...v1.37.0-dev.1) (2024-08-13)

### Features

* Enable recent patches by default ([e84f358](https://github.com/crimera/piko/commit/e84f358e494830fdecdc3dd12662b5f5ccd644b3))

## [1.36.0](https://github.com/crimera/piko/compare/v1.35.0...v1.36.0) (2024-08-12)

### Features

* **Twitter:** Added `Customize reply sort filter` patch ([121b8a6](https://github.com/crimera/piko/commit/121b8a6e9345ea462ad9cb06f7b20f863fc08d4a))
* **Twitter:** Added Remember filter for `Customize reply sort filter` ([24df398](https://github.com/crimera/piko/commit/24df3987e5008aeca52c11a8b20714766cdafff1))

### Updates

* **Twitter:** updated string ([60afc68](https://github.com/crimera/piko/commit/60afc683c4be02ba4d5cdc92879aad2e6755b14b))

## [1.36.0-dev.1](https://github.com/crimera/piko/compare/v1.35.0...v1.36.0-dev.1) (2024-08-11)

### Features

* **Twitter:** Added `Customize reply sort filter` patch ([121b8a6](https://github.com/crimera/piko/commit/121b8a6e9345ea462ad9cb06f7b20f863fc08d4a))
* **Twitter:** Added Remember filter for `Customize reply sort filter` ([24df398](https://github.com/crimera/piko/commit/24df3987e5008aeca52c11a8b20714766cdafff1))

### Updates

* **Twitter:** updated string ([60afc68](https://github.com/crimera/piko/commit/60afc683c4be02ba4d5cdc92879aad2e6755b14b))

## [1.35.0](https://github.com/crimera/piko/compare/v1.34.1...v1.35.0) (2024-08-10)

### Bug Fixes

* **Twitter:** fix `Remove videos for you` patch ([b19f943](https://github.com/crimera/piko/commit/b19f943ee8a19ea158e89cc031ae037e43da6e50))

### Features

* **Hook feature flag:** Added ability to search for supported flags. ([28a2c0a](https://github.com/crimera/piko/commit/28a2c0a6ca97fa50711ce44cfa1f20b5147e906f))
* **Twitter:** Added `Remove videos for you` patch ([25934a2](https://github.com/crimera/piko/commit/25934a2b58a8eefc05d4313b623580371d964a12))

### Updates

* **Hook feature flag:** Improve flag matching in search. ([d7f0827](https://github.com/crimera/piko/commit/d7f0827218a9501a0b2e061990ce60a0af18ba0e))

### Refactors

* **Twitter:** Added quick settings button in side drawer ([c0152e3](https://github.com/crimera/piko/commit/c0152e327e8b2e3fa2ad57d63c35738d4575cc98))

## [1.35.0-dev.3](https://github.com/crimera/piko/compare/v1.35.0-dev.2...v1.35.0-dev.3) (2024-08-10)

### Bug Fixes

* **Twitter:** fix `Remove videos for you` patch ([b19f943](https://github.com/crimera/piko/commit/b19f943ee8a19ea158e89cc031ae037e43da6e50))

### Features

* **Twitter:** Added `Remove videos for you` patch ([25934a2](https://github.com/crimera/piko/commit/25934a2b58a8eefc05d4313b623580371d964a12))

### Refactors

* **Twitter:** Added quick settings button in side drawer ([c0152e3](https://github.com/crimera/piko/commit/c0152e327e8b2e3fa2ad57d63c35738d4575cc98))

## [1.35.0-dev.2](https://github.com/crimera/piko/compare/v1.35.0-dev.1...v1.35.0-dev.2) (2024-08-09)

### Updates

* **Hook feature flag:** Improve flag matching in search. ([d7f0827](https://github.com/crimera/piko/commit/d7f0827218a9501a0b2e061990ce60a0af18ba0e))

## [1.35.0-dev.1](https://github.com/crimera/piko/compare/v1.34.1...v1.35.0-dev.1) (2024-08-09)

### Features

* **Hook feature flag:** Added ability to search for supported flags. ([28a2c0a](https://github.com/crimera/piko/commit/28a2c0a6ca97fa50711ce44cfa1f20b5147e906f))

## [1.34.1](https://github.com/crimera/piko/compare/v1.34.0...v1.34.1) (2024-08-06)

### Bug Fixes

* **Twitter:** Fix aapt breakage due to tag mismatch ([730a51c](https://github.com/crimera/piko/commit/730a51c20f464bbe2b680004721161dd5f34dadf))

## [1.34.0](https://github.com/crimera/piko/compare/v1.33.0...v1.34.0) (2024-08-06)

### Bug Fixes

* **Bring back twitter:** Change x icon to legacy twitter. ([3006f47](https://github.com/crimera/piko/commit/3006f47d973ffde1622ae1544590a11e923c68ab))
* **Twitter:** `Customize Navigation Bar items` in/from `10.53.0-beta.1` ([e8154fb](https://github.com/crimera/piko/commit/e8154fb0ffa91e6d3ed2812bed3f71a034f3bc01))
* **Twitter:** Fix `Remove premium upsell` patch ([4df5e32](https://github.com/crimera/piko/commit/4df5e32088eb57702c5f30e20b3c75d2ec11ee87))

### Features

* **Twitter:** Added `Remove main event` patch ([806598d](https://github.com/crimera/piko/commit/806598d7154c538fb238f3d9b186746cb8c956bf))

### Updates

* **Translations:** Translation updates ([4bf8a8d](https://github.com/crimera/piko/commit/4bf8a8dd954a7013a65ceee9d39521fd445d069d))

### Refactors

* **Twitter:** Seperated/Added `Remove superhero event` patch ([d60ee17](https://github.com/crimera/piko/commit/d60ee17294b311bb964e3cc6200465218d7baca3))

## [1.34.0-dev.2](https://github.com/crimera/piko/compare/v1.34.0-dev.1...v1.34.0-dev.2) (2024-08-05)

### Updates

* **Translations:** Translation updates ([4bf8a8d](https://github.com/crimera/piko/commit/4bf8a8dd954a7013a65ceee9d39521fd445d069d))

## [1.34.0-dev.1](https://github.com/crimera/piko/compare/v1.33.1-dev.2...v1.34.0-dev.1) (2024-08-03)

### Bug Fixes

* **Twitter:** `Customize Navigation Bar items` in/from `10.53.0-beta.1` ([e8154fb](https://github.com/crimera/piko/commit/e8154fb0ffa91e6d3ed2812bed3f71a034f3bc01))

### Features

* **Twitter:** Added `Remove main event` patch ([806598d](https://github.com/crimera/piko/commit/806598d7154c538fb238f3d9b186746cb8c956bf))

### Refactors

* **Twitter:** Seperated/Added `Remove superhero event` patch ([d60ee17](https://github.com/crimera/piko/commit/d60ee17294b311bb964e3cc6200465218d7baca3))

## [1.33.1-dev.2](https://github.com/crimera/piko/compare/v1.33.1-dev.1...v1.33.1-dev.2) (2024-08-03)

### Bug Fixes

* **Bring back twitter:** Change x icon to legacy twitter. ([3006f47](https://github.com/crimera/piko/commit/3006f47d973ffde1622ae1544590a11e923c68ab))

## [1.33.1-dev.1](https://github.com/crimera/piko/compare/v1.33.0...v1.33.1-dev.1) (2024-08-02)

### Bug Fixes

* **Twitter:** Fix `Remove premium upsell` patch ([4df5e32](https://github.com/crimera/piko/commit/4df5e32088eb57702c5f30e20b3c75d2ec11ee87))

## [1.33.0](https://github.com/crimera/piko/compare/v1.32.0...v1.33.0) (2024-07-31)

### Features

* **Twitter:** Added `Control video auto scroll` patch ([7a21924](https://github.com/crimera/piko/commit/7a21924dc7f30a15feef1797b0416c91de27d1e4))
* **Twitter:** Added `Enable PiP mode automatically` patch ([59d6b67](https://github.com/crimera/piko/commit/59d6b6723cbff6fa96218fb6210e2cb0b8bc1338))
* **Twitter:** Added `Remove premium upsell` patch ([37525de](https://github.com/crimera/piko/commit/37525de868c38254cbfd20b58d4fd077b0c14ca2))

### Updates

* Add spanish to languages ([e9b8efd](https://github.com/crimera/piko/commit/e9b8efdb3570fa516f06a736f2709d1c166df1bf))

### Refactors

* **Twitter:** More strings refactor ([d5a629f](https://github.com/crimera/piko/commit/d5a629f39bc4c15be1914a6ab98034129ed53f64))
* **Twitter:** Strings refactor ([2db8866](https://github.com/crimera/piko/commit/2db88663e70745ef81024d896ad5204c29b1ba06))

## [1.33.0-dev.1](https://github.com/crimera/piko/compare/v1.32.1-dev.1...v1.33.0-dev.1) (2024-07-30)

### Features

* **Twitter:** Added `Control video auto scroll` patch ([7a21924](https://github.com/crimera/piko/commit/7a21924dc7f30a15feef1797b0416c91de27d1e4))
* **Twitter:** Added `Enable PiP mode automatically` patch ([59d6b67](https://github.com/crimera/piko/commit/59d6b6723cbff6fa96218fb6210e2cb0b8bc1338))
* **Twitter:** Added `Remove premium upsell` patch ([37525de](https://github.com/crimera/piko/commit/37525de868c38254cbfd20b58d4fd077b0c14ca2))

### Refactors

* **Twitter:** More strings refactor ([d5a629f](https://github.com/crimera/piko/commit/d5a629f39bc4c15be1914a6ab98034129ed53f64))
* **Twitter:** Strings refactor ([2db8866](https://github.com/crimera/piko/commit/2db88663e70745ef81024d896ad5204c29b1ba06))

## [1.32.1-dev.1](https://github.com/crimera/piko/compare/v1.32.0...v1.32.1-dev.1) (2024-07-26)

### Updates

* Add spanish to languages ([e9b8efd](https://github.com/crimera/piko/commit/e9b8efdb3570fa516f06a736f2709d1c166df1bf))

## [1.32.0](https://github.com/crimera/piko/compare/v1.31.2...v1.32.0) (2024-07-17)


### Bug Fixes

* **Twitter:** Missing download option in immersive view ([6b0aa2c](https://github.com/crimera/piko/commit/6b0aa2c0d8d0f9192630e42abef418a834a95df0))


### Features

* **Twitter:** Added `Custom downloader` ([3d5941e](https://github.com/crimera/piko/commit/3d5941e226c1fb9402edeeb138c1c974026e0598))


### Updates

* Russian translation ([42b68e9](https://github.com/crimera/piko/commit/42b68e96fccca505a60d6eb2682cbfb7f7acfb17))

## [1.32.0-dev.3](https://github.com/crimera/piko/compare/v1.32.0-dev.2...v1.32.0-dev.3) (2024-07-13)


### Updates

* Russian translation ([42b68e9](https://github.com/crimera/piko/commit/42b68e96fccca505a60d6eb2682cbfb7f7acfb17))

## [1.32.0-dev.2](https://github.com/crimera/piko/compare/v1.32.0-dev.1...v1.32.0-dev.2) (2024-07-12)


### Bug Fixes

* **Twitter:** Missing download option in immersive view ([6b0aa2c](https://github.com/crimera/piko/commit/6b0aa2c0d8d0f9192630e42abef418a834a95df0))

## [1.32.0-dev.1](https://github.com/crimera/piko/compare/v1.31.2...v1.32.0-dev.1) (2024-07-06)


### Features

* **Twitter:** Added `Custom downloader` ([3d5941e](https://github.com/crimera/piko/commit/3d5941e226c1fb9402edeeb138c1c974026e0598))

## [1.31.2](https://github.com/crimera/piko/compare/v1.31.1...v1.31.2) (2024-06-25)


### Updates

* Translation updates ([509dfbb](https://github.com/crimera/piko/commit/509dfbb9e92511379406979a19b131a685229fc6))

## [1.31.2-dev.1](https://github.com/crimera/piko/compare/v1.31.1...v1.31.2-dev.1) (2024-06-25)


### Updates

* Translation updates ([509dfbb](https://github.com/crimera/piko/commit/509dfbb9e92511379406979a19b131a685229fc6))

## [1.31.1](https://github.com/crimera/piko/compare/v1.31.0...v1.31.1) (2024-06-11)


### Updates

* Improved the hooking of the recyclerview methods. also fixes the crash when opening feature flags. ([25e5bc4](https://github.com/crimera/piko/commit/25e5bc422c3893747b8fadd0744833a4ecb7b6ea))

## [1.31.1-dev.1](https://github.com/crimera/piko/compare/v1.31.0...v1.31.1-dev.1) (2024-06-11)


### Updates

* Improved the hooking of the recyclerview methods. also fixes the crash when opening feature flags. ([25e5bc4](https://github.com/crimera/piko/commit/25e5bc422c3893747b8fadd0744833a4ecb7b6ea))

## [1.31.0](https://github.com/crimera/piko/compare/v1.30.2...v1.31.0) (2024-06-11)


### Bug Fixes

* Fix crash when opening feature flags ([2b1484d](https://github.com/crimera/piko/commit/2b1484d6c291a997283d98358cff98b0195acfed))


### Features

* **all:** Added `Export all activities` patch from ReVanced ([7cc405f](https://github.com/crimera/piko/commit/7cc405f7e900b85aaa172e8693cd4ca2e790451d))
* **Twitter:** Added `Delete from database` patch ([d785660](https://github.com/crimera/piko/commit/d7856602786d3fb9d7a8721f05d80be97bc4fd3b))
* **Twitter:** Added tab redirects hook (for Bookmark Navbar) ([f01b418](https://github.com/crimera/piko/commit/f01b418fcc13e9fe54d845eab3bea1cd62687f9f))


### Updates

* Enable `Customize profile tabs` patch by default ([a8543bf](https://github.com/crimera/piko/commit/a8543bf0d2eebe8a1580870b95c75a890e845ff4))
* Enable `Hide Live Threads` patch by default ([b9862b5](https://github.com/crimera/piko/commit/b9862b50b97741721448c0ea667769b0024961c9))


### Refactors

* **Twitter:** Major string changes ([f22fdf0](https://github.com/crimera/piko/commit/f22fdf086184f71447d2696461d76914dbef731d))

## [1.31.0-dev.6](https://github.com/crimera/piko/compare/v1.31.0-dev.5...v1.31.0-dev.6) (2024-06-11)


### Updates

* **Translations:** Update polish translations ([6200d65](https://github.com/crimera/piko/commit/6200d657b5db4040f10ec4f82054ad440b09221c))

## [1.31.0-dev.5](https://github.com/crimera/piko/compare/v1.31.0-dev.4...v1.31.0-dev.5) (2024-06-11)


### Bug Fixes

* Fix crash when opening feature flags ([2b1484d](https://github.com/crimera/piko/commit/2b1484d6c291a997283d98358cff98b0195acfed))


### Updates

* Enable `Hide Live Threads` patch by default ([b9862b5](https://github.com/crimera/piko/commit/b9862b50b97741721448c0ea667769b0024961c9))

## [1.31.0-dev.4](https://github.com/crimera/piko/compare/v1.31.0-dev.3...v1.31.0-dev.4) (2024-06-09)


### Features

* **Twitter:** Added tab redirects hook (for Bookmark Navbar) ([f01b418](https://github.com/crimera/piko/commit/f01b418fcc13e9fe54d845eab3bea1cd62687f9f))

## [1.31.0-dev.3](https://github.com/crimera/piko/compare/v1.31.0-dev.2...v1.31.0-dev.3) (2024-06-06)


### Features

* **all:** Added `Export all activities` patch from ReVanced ([7cc405f](https://github.com/crimera/piko/commit/7cc405f7e900b85aaa172e8693cd4ca2e790451d))

## [1.31.0-dev.2](https://github.com/crimera/piko/compare/v1.31.0-dev.1...v1.31.0-dev.2) (2024-06-04)


### Refactors

* **Twitter:** Major string changes ([f22fdf0](https://github.com/crimera/piko/commit/f22fdf086184f71447d2696461d76914dbef731d))

## [1.31.0-dev.1](https://github.com/crimera/piko/compare/v1.30.1...v1.31.0-dev.1) (2024-06-02)


### Features

* **Twitter:** Added `Delete from database` patch ([d785660](https://github.com/crimera/piko/commit/d7856602786d3fb9d7a8721f05d80be97bc4fd3b))

### Updates

* Enable `Customize profile tabs` patch by default ([a8543bf](https://github.com/crimera/piko/commit/a8543bf0d2eebe8a1580870b95c75a890e845ff4))

## [1.30.1](https://github.com/crimera/piko/compare/v1.30.0...v1.30.1) (2024-06-01)


### Bug Fixes

* tweet highlight color on hold ([#243](https://github.com/crimera/piko/issues/243)) ([b22ea42](https://github.com/crimera/piko/commit/b22ea426830b250abaa336e3b158dea34f82f6d6))
* **Twitter:** Fix `Customize profile tabs` crash after `10.43` ([a38d621](https://github.com/crimera/piko/commit/a38d6213e06404fde21f6b5b8eddfcdfe8edd73e))


### Updates

* Translations ([d3ae8ec](https://github.com/crimera/piko/commit/d3ae8ec55dced8d7d09146c224d332f72414382a))
* **Translations:** update simplified chinese translation ([3e5a8fd](https://github.com/crimera/piko/commit/3e5a8fdd07a7f7646e860a76fc81165b67b211bf))


### Refactors

* **Twitter:** Added `No shortened URL` as a settings toggle ([ea33a30](https://github.com/crimera/piko/commit/ea33a308c277e3e40e085112e970406cee64f0cd))
* **Twitter:** Renamed patch `Remove Buy Premium Banner` to `Remove message prompts Banner` ([45dbad8](https://github.com/crimera/piko/commit/45dbad85abb22e0ab74d1dd0bcd977c4aeef3349))

## [1.30.1-dev.4](https://github.com/crimera/piko/compare/v1.30.1-dev.3...v1.30.1-dev.4) (2024-06-01)


### Bug Fixes

* **Twitter:** Fix `Customize profile tabs` crash after `10.43` ([a38d621](https://github.com/crimera/piko/commit/a38d6213e06404fde21f6b5b8eddfcdfe8edd73e))


### Refactors

* **Twitter:** Added `No shortened URL` as a settings toggle ([ea33a30](https://github.com/crimera/piko/commit/ea33a308c277e3e40e085112e970406cee64f0cd))
* **Twitter:** Renamed patch `Remove Buy Premium Banner` to `Remove message prompts Banner` ([45dbad8](https://github.com/crimera/piko/commit/45dbad85abb22e0ab74d1dd0bcd977c4aeef3349))

## [1.30.1-dev.3](https://github.com/crimera/piko/compare/v1.30.1-dev.2...v1.30.1-dev.3) (2024-05-27)


### Updates

* Translations ([d3ae8ec](https://github.com/crimera/piko/commit/d3ae8ec55dced8d7d09146c224d332f72414382a))

## [1.30.1-dev.2](https://github.com/crimera/piko/compare/v1.30.1-dev.1...v1.30.1-dev.2) (2024-05-26)


### Bug Fixes

* tweet highlight color on hold ([#243](https://github.com/crimera/piko/issues/243)) ([b22ea42](https://github.com/crimera/piko/commit/b22ea426830b250abaa336e3b158dea34f82f6d6))

## [1.30.1-dev.1](https://github.com/crimera/piko/compare/v1.30.0...v1.30.1-dev.1) (2024-05-25)


### Updates

* **Translations:** update simplified chinese translation ([3e5a8fd](https://github.com/crimera/piko/commit/3e5a8fdd07a7f7646e860a76fc81165b67b211bf))

## [1.30.0](https://github.com/crimera/piko/compare/v1.29.0...v1.30.0) (2024-05-22)


### Bug Fixes

* URL decode path to JAR containing spaces by osumatrix ([e6671ba](https://github.com/crimera/piko/commit/e6671ba4a8359db7aefa1ab20600e1f17144e002))
* Use UrlDecoder API available in older Android versions ([d9e6374](https://github.com/crimera/piko/commit/d9e63740b7eb7c8a4f44abf6d59998ea14194346))


### Features

* Remove throw file ([86bff99](https://github.com/crimera/piko/commit/86bff993636928c67ca95dabeebcf1f5cc191a36))
* **Twitter:** Added `Customize Inline action Bar items` patch ([05b06f9](https://github.com/crimera/piko/commit/05b06f9fa4a183c9626acc7fda69c0bebdbae761))
* **Twitter:** Added `Debug Menu` patch ([7d5ca77](https://github.com/crimera/piko/commit/7d5ca77bf633a8dfcd8657d12b24bd076b2f5d11))
* **Twitter:** Added `Hide Buy Premium Banner` patch ([7ba6419](https://github.com/crimera/piko/commit/7ba64198f289ffac2e3d397e5bf0f1137ba2aa2b))
* **Twitter:** Added `Hide hidden replies` patch ([431acc4](https://github.com/crimera/piko/commit/431acc435675002c7d9f068b4fc3ebade2487db3))
* **Twitter:** Added `Round off numbers` patch ([b1c1b13](https://github.com/crimera/piko/commit/b1c1b1361b55f08e2eba64e086943b30b2dc1212))
* **Twitter:** Added ability to reset pref and flags ([4aaeb09](https://github.com/crimera/piko/commit/4aaeb09ce6c38c6513be6293140a7e7e0b796f28))


### Updates

* **Twitter:** Enable new patches by default ([19f9149](https://github.com/crimera/piko/commit/19f9149452fafae83584508fe7ae9d594fcf5543))


### Refactors

* **Twitter:** Combined `customize patch` into single class ([6c04aed](https://github.com/crimera/piko/commit/6c04aed5ec958cb86471d94dd1729c4ad7952c8d))
* **Twitter:** Force enable `Enable app icon settings` patch ([ee605f1](https://github.com/crimera/piko/commit/ee605f11f8c95e6b8cf5d1d1cf2357593e1ea318))

## [1.30.0-dev.8](https://github.com/crimera/piko/compare/v1.30.0-dev.7...v1.30.0-dev.8) (2024-05-22)


### Features

* Remove throw file ([86bff99](https://github.com/crimera/piko/commit/86bff993636928c67ca95dabeebcf1f5cc191a36))

## [1.30.0-dev.7](https://github.com/crimera/piko/compare/v1.30.0-dev.6...v1.30.0-dev.7) (2024-05-22)


### Bug Fixes

* URL decode path to JAR containing spaces by osumatrix ([e6671ba](https://github.com/crimera/piko/commit/e6671ba4a8359db7aefa1ab20600e1f17144e002))
* Use UrlDecoder API available in older Android versions ([d9e6374](https://github.com/crimera/piko/commit/d9e63740b7eb7c8a4f44abf6d59998ea14194346))

## [1.30.0-dev.6](https://github.com/crimera/piko/compare/v1.30.0-dev.5...v1.30.0-dev.6) (2024-05-22)


### Updates

* **Twitter:** Enable new patches by default ([19f9149](https://github.com/crimera/piko/commit/19f9149452fafae83584508fe7ae9d594fcf5543))

## [1.30.0-dev.5](https://github.com/crimera/piko/compare/v1.30.0-dev.4...v1.30.0-dev.5) (2024-05-22)


### Features

* **Twitter:** Added `Hide Buy Premium Banner` patch ([7ba6419](https://github.com/crimera/piko/commit/7ba64198f289ffac2e3d397e5bf0f1137ba2aa2b))
* **Twitter:** Added `Hide hidden replies` patch ([431acc4](https://github.com/crimera/piko/commit/431acc435675002c7d9f068b4fc3ebade2487db3))

## [1.30.0-dev.4](https://github.com/crimera/piko/compare/v1.30.0-dev.3...v1.30.0-dev.4) (2024-05-20)


### Features

* **Twitter:** Added `Debug Menu` patch ([7d5ca77](https://github.com/crimera/piko/commit/7d5ca77bf633a8dfcd8657d12b24bd076b2f5d11))

## [1.30.0-dev.3](https://github.com/crimera/piko/compare/v1.30.0-dev.2...v1.30.0-dev.3) (2024-05-19)


### Features

* **Twitter:** Added `Customize Inline action Bar items` patch ([05b06f9](https://github.com/crimera/piko/commit/05b06f9fa4a183c9626acc7fda69c0bebdbae761))


### Refactors

* **Twitter:** Combined `customize patch` into single class ([6c04aed](https://github.com/crimera/piko/commit/6c04aed5ec958cb86471d94dd1729c4ad7952c8d))

## [1.30.0-dev.2](https://github.com/crimera/piko/compare/v1.30.0-dev.1...v1.30.0-dev.2) (2024-05-18)


### Features

* **Twitter:** Added ability to reset pref and flags ([4aaeb09](https://github.com/crimera/piko/commit/4aaeb09ce6c38c6513be6293140a7e7e0b796f28))

## [1.30.0-dev.1](https://github.com/crimera/piko/compare/v1.29.0...v1.30.0-dev.1) (2024-05-18)


### Features

* **Twitter:** Added `Round off numbers` patch ([b1c1b13](https://github.com/crimera/piko/commit/b1c1b1361b55f08e2eba64e086943b30b2dc1212))


### Refactors

* **Twitter:** Force enable `Enable app icon settings` patch ([ee605f1](https://github.com/crimera/piko/commit/ee605f11f8c95e6b8cf5d1d1cf2357593e1ea318))

## [1.29.0](https://github.com/crimera/piko/compare/v1.28.0...v1.29.0) (2024-05-18)


### Features

* **ui:** app wide monet theming in light mode ([46f920b](https://github.com/crimera/piko/commit/46f920bd35841e3df85617aed6a439f0df114d7b))


### Refactors

* **Twitter:** Refactor `Enable app icon settings` patch ([e7b3d0e](https://github.com/crimera/piko/commit/e7b3d0e3bfdfb5fc7dff3564c021c04d7d2d564c))
* **Twitter:** Separated `App icon` and `Navigation icon` patch ([8a67f12](https://github.com/crimera/piko/commit/8a67f12e0430dbd06a6184a150ba75da832a2c54))

## [1.29.0-dev.1](https://github.com/crimera/piko/compare/v1.28.1-dev.2...v1.29.0-dev.1) (2024-05-17)


### Features

* **ui:** app wide monet theming in light mode ([46f920b](https://github.com/crimera/piko/commit/46f920bd35841e3df85617aed6a439f0df114d7b))

## [1.28.1-dev.2](https://github.com/crimera/piko/compare/v1.28.1-dev.1...v1.28.1-dev.2) (2024-05-17)


### Refactors

* **Twitter:** Refactor `Enable app icon settings` patch ([e7b3d0e](https://github.com/crimera/piko/commit/e7b3d0e3bfdfb5fc7dff3564c021c04d7d2d564c))

## [1.28.1-dev.1](https://github.com/crimera/piko/compare/v1.28.0...v1.28.1-dev.1) (2024-05-16)


### Refactors

* **Twitter:** Separated `App icon` and `Navigation icon` patch ([8a67f12](https://github.com/crimera/piko/commit/8a67f12e0430dbd06a6184a150ba75da832a2c54))

## [1.28.0](https://github.com/crimera/piko/compare/v1.27.1...v1.28.0) (2024-05-15)


### Features

* **Translations:** Update `japanese` ([444623f](https://github.com/crimera/piko/commit/444623faaa5761b33445705e04e5c3078ff88124))
* **Twitter:** Added `Customize Navigation Bar items` patch ([9c6f59c](https://github.com/crimera/piko/commit/9c6f59cf6f40cc4d4d61b13bf496f800f452c0c1))
* **Twitter:** Added `Customize side bar items` patch ([ca0d28f](https://github.com/crimera/piko/commit/ca0d28f96d65d7d7f300f6089029ec24e55802b4))
* **Twitter:** Added `Disable auto timeline scroll on launch` patch ([b8d431e](https://github.com/crimera/piko/commit/b8d431ea44a2b53f9065c226116d86ec1fb7b70f))


### Updates

* **Translations:** Update Brazilian Portuguese ([8745f61](https://github.com/crimera/piko/commit/8745f61c060a62152bd84ee510d835ac8346e01e))


### Refactors

* **Twitter:** Added missing patches names ([b3fda95](https://github.com/crimera/piko/commit/b3fda9558251eda91e6e3b43e994a9dbcdb1daac))

## [1.28.0-dev.5](https://github.com/crimera/piko/compare/v1.28.0-dev.4...v1.28.0-dev.5) (2024-05-15)


### Updates

* **Translations:** Improved & updates polish translations ([9bbb9f4](https://github.com/crimera/piko/commit/9bbb9f4ea8c5aa3fee0be0580a281dc967f7981a))

## [1.28.0-dev.4](https://github.com/crimera/piko/compare/v1.28.0-dev.3...v1.28.0-dev.4) (2024-05-13)


### Features

* **Twitter:** Added `Customize Navigation Bar items` patch ([9c6f59c](https://github.com/crimera/piko/commit/9c6f59cf6f40cc4d4d61b13bf496f800f452c0c1))

## [1.28.0-dev.3](https://github.com/crimera/piko/compare/v1.28.0-dev.2...v1.28.0-dev.3) (2024-05-12)


### Features

* **Twitter:** Added `Customize side bar items` patch ([ca0d28f](https://github.com/crimera/piko/commit/ca0d28f96d65d7d7f300f6089029ec24e55802b4))


### Refactors

* **Twitter:** Added missing patches names ([b3fda95](https://github.com/crimera/piko/commit/b3fda9558251eda91e6e3b43e994a9dbcdb1daac))

## [1.28.0-dev.2](https://github.com/crimera/piko/compare/v1.28.0-dev.1...v1.28.0-dev.2) (2024-05-11)


### Features

* **Twitter:** Added `Disable auto timeline scroll on launch` patch ([b8d431e](https://github.com/crimera/piko/commit/b8d431ea44a2b53f9065c226116d86ec1fb7b70f))

## [1.28.0-dev.1](https://github.com/crimera/piko/compare/v1.27.0...v1.28.0-dev.1) (2024-05-09)


### Features

* **Translations:** Update `japanese` ([444623f](https://github.com/crimera/piko/commit/444623faaa5761b33445705e04e5c3078ff88124))


### Updates

* **Translations:** Update Brazilian Portuguese ([8745f61](https://github.com/crimera/piko/commit/8745f61c060a62152bd84ee510d835ac8346e01e))

## [1.27.0](https://github.com/crimera/piko/compare/v1.26.0...v1.27.0) (2024-05-08)


### Bug Fixes

* add "SettingsStatusLoadFingerprint" to fingerprints of `Hide Community Notes` and `Hide Live Threads` patch ([9c0232a](https://github.com/crimera/piko/commit/9c0232afd684024cc7028960aa2c65a82ce90cb7))
* **Twitter:** Bookmark in nav bar dix ([03fb96c](https://github.com/crimera/piko/commit/03fb96c485edb8931e9d37452f5a45c0b8a0103b))
* **Twitter:** Bookmark nav bar fix ([a6e8ab9](https://github.com/crimera/piko/commit/a6e8ab9c6817e15fa7c9ba182650f65ee2e65132))
* Unescaped characters ([8e539df](https://github.com/crimera/piko/commit/8e539dfd8c4e1ef6889357b9850a842db54a2a99))


### Features

* **Twitter:** Added `Ability to copy video media link` patch ([14bfdc7](https://github.com/crimera/piko/commit/14bfdc7d0b2d1fbf6644e496cbc186bd5ade3494))
* **Twitter:** Added `Patch info` section ([7f794c3](https://github.com/crimera/piko/commit/7f794c3cc88b1fd1170f43589aaff356532bb9e4))


### Updates

* Improve the retrieval of the patches version ([ba940da](https://github.com/crimera/piko/commit/ba940da7b84e52345533dd3802410811b7fa4cb7))
* **Translations:** Update `Indonesian (Bahasa)` ([1442b6c](https://github.com/crimera/piko/commit/1442b6c798f5fd58e1381f1e23581cc8f55ca0fc))
* **Translations:** Update `japanese` ([9fce4a2](https://github.com/crimera/piko/commit/9fce4a20d7db77992bd92eaa5ada75af8af56103))
* **Translations:** update simplified chinese translation ([b24f7cc](https://github.com/crimera/piko/commit/b24f7cca23c6b003c7246951de8a361ff5ef2dfb))


### Refactors

* Add `enableSettings` helper function ([7d6ebd5](https://github.com/crimera/piko/commit/7d6ebd579a32161bf782f2ce0843817dbbf8b69d))
* Add `SettingsPatch ` dependencies to patches ([6d252f8](https://github.com/crimera/piko/commit/6d252f84c6086b15e7be4a58676254748bd8ff73))
* Optimize imports ([2f42add](https://github.com/crimera/piko/commit/2f42add01463d36336423574b76670c6cbf2659a))
* **Twitter:** `Add ability to copy media link` patch ([e8ef551](https://github.com/crimera/piko/commit/e8ef5519abf64594676f0de1e0e3e01b06571079))
* **Twitter:** refactor default feature flag hook ([6fd6001](https://github.com/crimera/piko/commit/6fd60012c74c83944fd80b57e444c3f54da5823c))

## [1.27.0-dev.8](https://github.com/crimera/piko/compare/v1.27.0-dev.7...v1.27.0-dev.8) (2024-05-08)


### Updates

* **Translations:** Update `Indonesian (Bahasa)` ([1442b6c](https://github.com/crimera/piko/commit/1442b6c798f5fd58e1381f1e23581cc8f55ca0fc))
* **Translations:** update simplified chinese translation ([b24f7cc](https://github.com/crimera/piko/commit/b24f7cca23c6b003c7246951de8a361ff5ef2dfb))

## [1.27.0-dev.7](https://github.com/crimera/piko/compare/v1.27.0-dev.6...v1.27.0-dev.7) (2024-05-08)


### Updates

* Improve the retrieval of the patches version ([ba940da](https://github.com/crimera/piko/commit/ba940da7b84e52345533dd3802410811b7fa4cb7))

## [1.27.0-dev.6](https://github.com/crimera/piko/compare/v1.27.0-dev.5...v1.27.0-dev.6) (2024-05-07)


### Features

* **Twitter:** Added `Patch info` section ([7f794c3](https://github.com/crimera/piko/commit/7f794c3cc88b1fd1170f43589aaff356532bb9e4))

## [1.27.0-dev.5](https://github.com/crimera/piko/compare/v1.27.0-dev.4...v1.27.0-dev.5) (2024-05-05)


### Refactors

* **Twitter:** `Add ability to copy media link` patch ([e8ef551](https://github.com/crimera/piko/commit/e8ef5519abf64594676f0de1e0e3e01b06571079))

## [1.27.0-dev.4](https://github.com/crimera/piko/compare/v1.27.0-dev.3...v1.27.0-dev.4) (2024-05-02)


### Bug Fixes

* **Twitter:** Bookmark in nav bar dix ([03fb96c](https://github.com/crimera/piko/commit/03fb96c485edb8931e9d37452f5a45c0b8a0103b))
* **Twitter:** Bookmark nav bar fix ([a6e8ab9](https://github.com/crimera/piko/commit/a6e8ab9c6817e15fa7c9ba182650f65ee2e65132))


### Refactors

* **Twitter:** refactor default feature flag hook ([6fd6001](https://github.com/crimera/piko/commit/6fd60012c74c83944fd80b57e444c3f54da5823c))

## [1.27.0-dev.3](https://github.com/crimera/piko/compare/v1.27.0-dev.2...v1.27.0-dev.3) (2024-05-02)


### Updates

* **Translations:** Update `japanese` ([9fce4a2](https://github.com/crimera/piko/commit/9fce4a20d7db77992bd92eaa5ada75af8af56103))

## [1.27.0-dev.2](https://github.com/crimera/piko/compare/v1.27.0-dev.1...v1.27.0-dev.2) (2024-05-01)


### Bug Fixes

* Unescaped characters ([8e539df](https://github.com/crimera/piko/commit/8e539dfd8c4e1ef6889357b9850a842db54a2a99))

## [1.27.0-dev.1](https://github.com/crimera/piko/compare/v1.26.1-dev.3...v1.27.0-dev.1) (2024-05-01)


### Features

* **Twitter:** Added `Ability to copy video media link` patch ([14bfdc7](https://github.com/crimera/piko/commit/14bfdc7d0b2d1fbf6644e496cbc186bd5ade3494))

## [1.26.1-dev.3](https://github.com/crimera/piko/compare/v1.26.1-dev.2...v1.26.1-dev.3) (2024-04-30)


### Refactors

* Add `enableSettings` helper function ([7d6ebd5](https://github.com/crimera/piko/commit/7d6ebd579a32161bf782f2ce0843817dbbf8b69d))
* Optimize imports ([2f42add](https://github.com/crimera/piko/commit/2f42add01463d36336423574b76670c6cbf2659a))

## [1.26.1-dev.2](https://github.com/crimera/piko/compare/v1.26.1-dev.1...v1.26.1-dev.2) (2024-04-30)


### Refactors

* Add `SettingsPatch ` dependencies to patches ([6d252f8](https://github.com/crimera/piko/commit/6d252f84c6086b15e7be4a58676254748bd8ff73))

## [1.26.1-dev.1](https://github.com/crimera/piko/compare/v1.26.0...v1.26.1-dev.1) (2024-04-30)


### Bug Fixes

* add "SettingsStatusLoadFingerprint" to fingerprints of `Hide Community Notes` and `Hide Live Threads` patch ([9c0232a](https://github.com/crimera/piko/commit/9c0232afd684024cc7028960aa2c65a82ce90cb7))

## [1.26.0](https://github.com/crimera/piko/compare/v1.25.1...v1.26.0) (2024-04-30)


### Bug Fixes

* **Twitter:** Fix `Hide Promoted Trends` patch ([7052d25](https://github.com/crimera/piko/commit/7052d2583527354ee1a719f808993049364c8718))


### Features

* Add toggle for `Open browser chooser on opening links` patch ([6f217f0](https://github.com/crimera/piko/commit/6f217f08a8037be067791b318b750d7f6d91b4ea))
* **Translations:** Add Brazilian Portuguese translations [Bring back Twitter] ([3a831d3](https://github.com/crimera/piko/commit/3a831d3869a5fbbb22342cbfe1859241b2126fa5))
* **Translations:** Add Simplified Chinese translations and Taiwanese Traditional Chinese translations[Bring back Twitter] ([d44bfd7](https://github.com/crimera/piko/commit/d44bfd73f0063703179c097d68738063a000d80b))


### Updates

* **Bring back twitter:** Create strings file if not found ([9f51a5c](https://github.com/crimera/piko/commit/9f51a5cf9525e829166a5b82261abe209823eb5b))
* **Custom sharing domain:** require settings patch also turned it on by default. ([6a3777f](https://github.com/crimera/piko/commit/6a3777f0631a97dff3a31129a45cfc671e71283d))
* **Translations:** Update `Indonesian (Bahasa)` ([b9488d6](https://github.com/crimera/piko/commit/b9488d6fed4e521f80ca9c292112130d806f77aa))
* **Translations:** Update Brazilian Portuguese ([7de9493](https://github.com/crimera/piko/commit/7de949327844e06e1fda1946bed5555fb150b67c))
* **Translations:** Update Japanese ([61ff288](https://github.com/crimera/piko/commit/61ff288ba6aa086c984a317a52fb7228710878f5))
* **Translations:** Update Russian translation ([8b1c4c8](https://github.com/crimera/piko/commit/8b1c4c8185a482a72ecc7cdc2dbb31940660a70d))
* **Translations:** Update simplified chinese translation ([147cb29](https://github.com/crimera/piko/commit/147cb29cd4e4f260fd168934584971e6620e7f9b))
* **Translations:** Update Turkish translations ([bab6ae9](https://github.com/crimera/piko/commit/bab6ae97e400d89f7551eebfc1ee04f385a1c62c))
* **Translation:** Update Hindi translations [Bring back Twitter] ([20ac044](https://github.com/crimera/piko/commit/20ac044efe3f96f2cefadce6cb42a00e1a820840))


### Refactors

* **Twitter:** Added multiple language support for `Bring back twitter` ([9eacab3](https://github.com/crimera/piko/commit/9eacab308dab4f4ea1de834d81308e9d616766c2))
* **Twitter:** Rearrange `Bring back twitter` resources ([a476924](https://github.com/crimera/piko/commit/a47692437d7f80c44b67ff61204b02db93743b86))

## [1.26.0-dev.9](https://github.com/crimera/piko/compare/v1.26.0-dev.8...v1.26.0-dev.9) (2024-04-30)


### Features

* **Translations:** Add Simplified Chinese translations and Taiwanese Traditional Chinese translations[Bring back Twitter] ([d44bfd7](https://github.com/crimera/piko/commit/d44bfd73f0063703179c097d68738063a000d80b))

## [1.26.0-dev.8](https://github.com/crimera/piko/compare/v1.26.0-dev.7...v1.26.0-dev.8) (2024-04-30)


### Updates

* **Bring back twitter:** Create strings file if not found ([9f51a5c](https://github.com/crimera/piko/commit/9f51a5cf9525e829166a5b82261abe209823eb5b))
* **Custom sharing domain:** require settings patch also turned it on by default. ([6a3777f](https://github.com/crimera/piko/commit/6a3777f0631a97dff3a31129a45cfc671e71283d))

## [1.26.0-dev.7](https://github.com/crimera/piko/compare/v1.26.0-dev.6...v1.26.0-dev.7) (2024-04-30)


### Updates

* **Translations:** Update polish ([9d8f4fc](https://github.com/crimera/piko/commit/9d8f4fc57174b0cc28540e29b7b9725af5e65421))

## [1.26.0-dev.6](https://github.com/crimera/piko/compare/v1.26.0-dev.5...v1.26.0-dev.6) (2024-04-29)


### Features

* **Translations:** Add Brazilian Portuguese translations [Bring back Twitter] ([3a831d3](https://github.com/crimera/piko/commit/3a831d3869a5fbbb22342cbfe1859241b2126fa5))

## [1.26.0-dev.5](https://github.com/crimera/piko/compare/v1.26.0-dev.4...v1.26.0-dev.5) (2024-04-28)


### Updates

* **Translation:** Update Hindi translations [Bring back Twitter] ([20ac044](https://github.com/crimera/piko/commit/20ac044efe3f96f2cefadce6cb42a00e1a820840))


### Refactors

* **Twitter:** Added multiple language support for `Bring back twitter` ([9eacab3](https://github.com/crimera/piko/commit/9eacab308dab4f4ea1de834d81308e9d616766c2))
* **Twitter:** Rearrange `Bring back twitter` resources ([a476924](https://github.com/crimera/piko/commit/a47692437d7f80c44b67ff61204b02db93743b86))

## [1.26.0-dev.4](https://github.com/crimera/piko/compare/v1.26.0-dev.3...v1.26.0-dev.4) (2024-04-27)


### Updates

* **Translations:** Update Turkish translations ([bab6ae9](https://github.com/crimera/piko/commit/bab6ae97e400d89f7551eebfc1ee04f385a1c62c))

## [1.26.0-dev.3](https://github.com/crimera/piko/compare/v1.26.0-dev.2...v1.26.0-dev.3) (2024-04-27)


### Bug Fixes

* **Twitter:** Fix `Hide Promoted Trends` patch ([7052d25](https://github.com/crimera/piko/commit/7052d2583527354ee1a719f808993049364c8718))

## [1.26.0-dev.2](https://github.com/crimera/piko/compare/v1.26.0-dev.1...v1.26.0-dev.2) (2024-04-27)


### Updates

* **Translations:** Update `Indonesian (Bahasa)` ([b9488d6](https://github.com/crimera/piko/commit/b9488d6fed4e521f80ca9c292112130d806f77aa))
* **Translations:** Update Japanese ([61ff288](https://github.com/crimera/piko/commit/61ff288ba6aa086c984a317a52fb7228710878f5))
* **Translations:** Update simplified chinese translation ([147cb29](https://github.com/crimera/piko/commit/147cb29cd4e4f260fd168934584971e6620e7f9b))

## [1.26.0-dev.1](https://github.com/crimera/piko/compare/v1.25.1-dev.1...v1.26.0-dev.1) (2024-04-26)


### Features

* Add toggle for `Open browser chooser on opening links` patch ([6f217f0](https://github.com/crimera/piko/commit/6f217f08a8037be067791b318b750d7f6d91b4ea))


### Updates

* **Translations:** Update Russian translation ([8b1c4c8](https://github.com/crimera/piko/commit/8b1c4c8185a482a72ecc7cdc2dbb31940660a70d))

## [1.25.1-dev.1](https://github.com/crimera/piko/compare/v1.25.0...v1.25.1-dev.1) (2024-04-26)


### Updates

* **Translations:** Update Brazilian Portuguese ([7de9493](https://github.com/crimera/piko/commit/7de949327844e06e1fda1946bed5555fb150b67c))

## [1.25.0](https://github.com/crimera/piko/compare/v1.24.0...v1.25.0) (2024-04-25)


### Features

* **Twitter:** Added `Customize timeline top bar` patch ([245c5f6](https://github.com/crimera/piko/commit/245c5f6f8f82e98b405ec853624c3cad52ae1764))
* use browser chooser when opening links ([cc165f4](https://github.com/crimera/piko/commit/cc165f41db4392d9dcc554ee8800333e87dc8cdf))

## [1.25.0-dev.2](https://github.com/crimera/piko/compare/v1.25.0-dev.1...v1.25.0-dev.2) (2024-04-25)


### Features

* **Twitter:** Added `Customize timeline top bar` patch ([245c5f6](https://github.com/crimera/piko/commit/245c5f6f8f82e98b405ec853624c3cad52ae1764))

## [1.25.0-dev.1](https://github.com/crimera/piko/compare/v1.24.0...v1.25.0-dev.1) (2024-04-25)


### Features

* use browser chooser when opening links ([cc165f4](https://github.com/crimera/piko/commit/cc165f41db4392d9dcc554ee8800333e87dc8cdf))

## [1.24.0](https://github.com/crimera/piko/compare/v1.23.0...v1.24.0) (2024-04-25)


### Bug Fixes

* Opening mod settings with root installation results in crash ([8161644](https://github.com/crimera/piko/commit/81616443f2104eb1633c2c92c555f45341a7680e))
* Opening mod settings with root installation results in crash ([47e7670](https://github.com/crimera/piko/commit/47e7670cc09da736cbca6c9447f82d9fa343ee56))
* unescaped character on `pl` string values ([a6444be](https://github.com/crimera/piko/commit/a6444bed45872df6a55be17a2b64dd2d40e2d16a))


### Features

* **Translations:** Added Traditional Chinese translation ([1c0b10a](https://github.com/crimera/piko/commit/1c0b10af732a6e159862a99369b57368cbbdab91))
* **Twitter:** Added `Profile tabs customisation` ([db0298b](https://github.com/crimera/piko/commit/db0298b9f0cc6066974630d29812a2e8a11e7262))


### Refactors

* **Twitter:** updated profile tab string ([1af7846](https://github.com/crimera/piko/commit/1af78461de97661a82d5eb638300402eaab00afe))

## [1.24.0-dev.3](https://github.com/crimera/piko/compare/v1.24.0-dev.2...v1.24.0-dev.3) (2024-04-23)


### Features

* **Translations:** Added Traditional Chinese translation ([1c0b10a](https://github.com/crimera/piko/commit/1c0b10af732a6e159862a99369b57368cbbdab91))

## [1.24.0-dev.2](https://github.com/crimera/piko/compare/v1.24.0-dev.1...v1.24.0-dev.2) (2024-04-21)


### Bug Fixes

* Opening mod settings with root installation results in crash ([8161644](https://github.com/crimera/piko/commit/81616443f2104eb1633c2c92c555f45341a7680e))
* Opening mod settings with root installation results in crash ([47e7670](https://github.com/crimera/piko/commit/47e7670cc09da736cbca6c9447f82d9fa343ee56))
* unescaped character on `pl` string values ([a6444be](https://github.com/crimera/piko/commit/a6444bed45872df6a55be17a2b64dd2d40e2d16a))

## [1.24.0-dev.1](https://github.com/crimera/piko/compare/v1.23.0...v1.24.0-dev.1) (2024-04-19)


### Features

* **Twitter:** Added `Profile tabs customisation` ([db0298b](https://github.com/crimera/piko/commit/db0298b9f0cc6066974630d29812a2e8a11e7262))


### Refactors

* **Twitter:** updated profile tab string ([1af7846](https://github.com/crimera/piko/commit/1af78461de97661a82d5eb638300402eaab00afe))

## [1.23.0](https://github.com/crimera/piko/compare/v1.22.0...v1.23.0) (2024-04-19)


### Bug Fixes

* Fix oopsie ([2af661f](https://github.com/crimera/piko/commit/2af661f5dfa1cc08e436ce04800ab230030a5079))
* Missing `,` ([67675fe](https://github.com/crimera/piko/commit/67675fe381f0554cb69c0f061ec792df9e523479))
* Not creating `values-night-v31` dir ([e3f3491](https://github.com/crimera/piko/commit/e3f3491fea403f55d5200d1afc4aebd5c7507c2e))
* switch jp to ja for Japanese translation ([c13cc87](https://github.com/crimera/piko/commit/c13cc87afeaea8cb623e7652a154a507ce532d61))


### Features

* **Translations:** Add `Turkish` ([bf70b91](https://github.com/crimera/piko/commit/bf70b913775ec299a87725b15d30bb2506da7a5d))
* **Translations:** Add Arabic translations ([c1d797b](https://github.com/crimera/piko/commit/c1d797b21bcbf0752bb48c94e4009e8221e46b36))
* **Translations:** Add japanese ([c123d8e](https://github.com/crimera/piko/commit/c123d8ed58f92dce6337cd194be64e21b3d9559c))
* **Translations:** Add simplified Chinese translation ([7662a34](https://github.com/crimera/piko/commit/7662a34a87e2dd5d819188993054a8fc4808ef03))
* **Translations:** Fix Simplified Chinese Translation ([ec0a3dc](https://github.com/crimera/piko/commit/ec0a3dcadf4027c3a6a6d411d44043d245b5ca29))
* **Translations:** Update `japanese` ([f5ece19](https://github.com/crimera/piko/commit/f5ece191a724f7bc0aed0cb90df8902f6d9e110b))
* **Translations:** Update Russian translation ([54ba664](https://github.com/crimera/piko/commit/54ba664921218ce79218e4ce4a9a2d4d2d1cf1b6))
* **Translations:** Updated Brazilian Portuguese ([e25ec0e](https://github.com/crimera/piko/commit/e25ec0ecee9e576f6fe74c2bf70d750399275b7e))
* **translation:** Update Simplified Chinese translation ([4f3027a](https://github.com/crimera/piko/commit/4f3027a2279e9cd1a2cc010d190cab3551c45cd4))
* **Translation:** Update Simplified Chinese translation ([b9fe0e8](https://github.com/crimera/piko/commit/b9fe0e83a3ddd1fd2633dca6403723c4dbea32ce))
* **Twitter:** Added `Enable app downgrading` patch ([9f581ce](https://github.com/crimera/piko/commit/9f581ce41b202fe7e5dfbb634a18a5bf6fb8faa5))
* **Twitter:** Added ability to export and import prefs & feature flags ([01cdd6b](https://github.com/crimera/piko/commit/01cdd6b7b25f08a3b258704f38c25b11aa1a9703))
* **Twitter:** Added ability to export and import prefs & feature flags ([a591133](https://github.com/crimera/piko/commit/a591133381a0b620a82d83580757300042680c85))
* **ui:** full app wide material theming in dim mode replacing dark blue ([52d7444](https://github.com/crimera/piko/commit/52d74441f0ae509ec66ba04b3939c90deb4755c5))


### Refactors

* **Twitter:** load `Utils.load()` dynamically ([5379276](https://github.com/crimera/piko/commit/53792768e4e5465559478041f51e516159c1f93f))

## [1.23.0-dev.11](https://github.com/crimera/piko/compare/v1.23.0-dev.10...v1.23.0-dev.11) (2024-04-18)


### Features

* **Twitter:** Added `Enable app downgrading` patch ([9f581ce](https://github.com/crimera/piko/commit/9f581ce41b202fe7e5dfbb634a18a5bf6fb8faa5))


### Refactors

* **Twitter:** load `Utils.load()` dynamically ([5379276](https://github.com/crimera/piko/commit/53792768e4e5465559478041f51e516159c1f93f))

## [1.23.0-dev.10](https://github.com/crimera/piko/compare/v1.23.0-dev.9...v1.23.0-dev.10) (2024-04-17)


### Features

* **Translations:** Fix Simplified Chinese Translation ([ec0a3dc](https://github.com/crimera/piko/commit/ec0a3dcadf4027c3a6a6d411d44043d245b5ca29))

## [1.23.0-dev.9](https://github.com/crimera/piko/compare/v1.23.0-dev.8...v1.23.0-dev.9) (2024-04-17)


### Bug Fixes

* switch jp to ja for Japanese translation ([c13cc87](https://github.com/crimera/piko/commit/c13cc87afeaea8cb623e7652a154a507ce532d61))

## [1.23.0-dev.8](https://github.com/crimera/piko/compare/v1.23.0-dev.7...v1.23.0-dev.8) (2024-04-17)


### Bug Fixes

* Not creating `values-night-v31` dir ([e3f3491](https://github.com/crimera/piko/commit/e3f3491fea403f55d5200d1afc4aebd5c7507c2e))

## [1.23.0-dev.7](https://github.com/crimera/piko/compare/v1.23.0-dev.6...v1.23.0-dev.7) (2024-04-17)


### Features

* **ui:** full app wide material theming in dim mode replacing dark blue ([52d7444](https://github.com/crimera/piko/commit/52d74441f0ae509ec66ba04b3939c90deb4755c5))

## [1.23.0-dev.6](https://github.com/crimera/piko/compare/v1.23.0-dev.5...v1.23.0-dev.6) (2024-04-16)


### Bug Fixes

* Missing `,` ([67675fe](https://github.com/crimera/piko/commit/67675fe381f0554cb69c0f061ec792df9e523479))


### Features

* **Translations:** Add `Turkish` ([bf70b91](https://github.com/crimera/piko/commit/bf70b913775ec299a87725b15d30bb2506da7a5d))
* **Translations:** Update Russian translation ([54ba664](https://github.com/crimera/piko/commit/54ba664921218ce79218e4ce4a9a2d4d2d1cf1b6))
* **Translations:** Updated Brazilian Portuguese ([e25ec0e](https://github.com/crimera/piko/commit/e25ec0ecee9e576f6fe74c2bf70d750399275b7e))

## [1.23.0-dev.5](https://github.com/crimera/piko/compare/v1.23.0-dev.4...v1.23.0-dev.5) (2024-04-16)


### Features

* **Translations:** Update `japanese` ([f5ece19](https://github.com/crimera/piko/commit/f5ece191a724f7bc0aed0cb90df8902f6d9e110b))
* **translation:** Update Simplified Chinese translation ([4f3027a](https://github.com/crimera/piko/commit/4f3027a2279e9cd1a2cc010d190cab3551c45cd4))
* **Translation:** Update Simplified Chinese translation ([b9fe0e8](https://github.com/crimera/piko/commit/b9fe0e83a3ddd1fd2633dca6403723c4dbea32ce))

## [1.23.0-dev.4](https://github.com/crimera/piko/compare/v1.23.0-dev.3...v1.23.0-dev.4) (2024-04-15)


### Features

* **Twitter:** Added ability to export and import prefs & feature flags ([01cdd6b](https://github.com/crimera/piko/commit/01cdd6b7b25f08a3b258704f38c25b11aa1a9703))
* **Twitter:** Added ability to export and import prefs & feature flags ([a591133](https://github.com/crimera/piko/commit/a591133381a0b620a82d83580757300042680c85))

## [1.23.0-dev.3](https://github.com/crimera/piko/compare/v1.23.0-dev.2...v1.23.0-dev.3) (2024-04-15)


### Features

* **Translations:** Add japanese ([c123d8e](https://github.com/crimera/piko/commit/c123d8ed58f92dce6337cd194be64e21b3d9559c))
* **Translations:** Add simplified Chinese translation ([7662a34](https://github.com/crimera/piko/commit/7662a34a87e2dd5d819188993054a8fc4808ef03))

## [1.23.0-dev.2](https://github.com/crimera/piko/compare/v1.23.0-dev.1...v1.23.0-dev.2) (2024-04-15)


### Bug Fixes

* Fix oopsie ([2af661f](https://github.com/crimera/piko/commit/2af661f5dfa1cc08e436ce04800ab230030a5079))

## [1.23.0-dev.1](https://github.com/crimera/piko/compare/v1.22.0...v1.23.0-dev.1) (2024-04-15)


### Features

* **Translations:** Add Arabic translations ([c1d797b](https://github.com/crimera/piko/commit/c1d797b21bcbf0752bb48c94e4009e8221e46b36))

## [1.22.0](https://github.com/crimera/piko/compare/v1.21.0...v1.22.0) (2024-04-15)


### Features

* **Translations:** Add polish translation ([8102f35](https://github.com/crimera/piko/commit/8102f35bab392acd8337fdf363c8891e3b96f629))
* **Translations:** Update Russian translation ([3606c10](https://github.com/crimera/piko/commit/3606c101ae1630c303a8ed55c4e21ab75346fbbe))
* **Translations:** Updated Brazilian Portuguese ([45aac73](https://github.com/crimera/piko/commit/45aac7374731e2d3b4a24e3c22ad5aaaccbbc33a))

## [1.22.0](https://github.com/crimera/piko/compare/v1.21.0...v1.22.0) (2024-04-15)


### Features

* **Translations:** Add polish translation ([8102f35](https://github.com/crimera/piko/commit/8102f35bab392acd8337fdf363c8891e3b96f629))
* **Translations:** Update Russian translation ([3606c10](https://github.com/crimera/piko/commit/3606c101ae1630c303a8ed55c4e21ab75346fbbe))

## [1.21.0](https://github.com/crimera/piko/compare/v1.20.0...v1.21.0) (2024-04-14)


### Features

* Add russian translation ([2dc9cee](https://github.com/crimera/piko/commit/2dc9ceed63a5a965f9979e3df1094f6b7a12a001))
* Add support for adding custom feature flags ([a6a91d1](https://github.com/crimera/piko/commit/a6a91d13a8623b505ba299ee23845f2a62399f33))
* Added resource file for strings ([181fd29](https://github.com/crimera/piko/commit/181fd298748c38dc53c10609b6714d8ce255d5be))
* **Translations:** add hindi ( हिन्दी ) translations [#91](https://github.com/crimera/piko/issues/91) ([a766771](https://github.com/crimera/piko/commit/a766771d848a43c3a4d2ba5e955ab72015dfb69d))
* **Translations:** Added Brazilian Portuguese [#90](https://github.com/crimera/piko/issues/90) ([ad307da](https://github.com/crimera/piko/commit/ad307da5ba7f0739024c7a30de2cb3b09d8aee28))
* **Twitter:** Added `Feature Flag Hook` ([2328baf](https://github.com/crimera/piko/commit/2328baf92c733cf99ca364c978514b14b6aae2e0))
* **Twitter:** Added `Hide immersive player` patch ([a649652](https://github.com/crimera/piko/commit/a649652c982903ac29100933122db47e9ed86d17))


### Updates

* Change settings string id ([b9c86d7](https://github.com/crimera/piko/commit/b9c86d715c0ae4ec2da63384462be3c784db7b73))
* **Twitter:** Made some features to use flags ([04c366a](https://github.com/crimera/piko/commit/04c366a6cfac0e8d3ce0bcc41f61df76b6043f42))

## [1.21.0-dev.7](https://github.com/crimera/piko/compare/v1.21.0-dev.6...v1.21.0-dev.7) (2024-04-14)


### Features

* Add support for adding custom feature flags ([a6a91d1](https://github.com/crimera/piko/commit/a6a91d13a8623b505ba299ee23845f2a62399f33))

## [1.21.0-dev.6](https://github.com/crimera/piko/compare/v1.21.0-dev.5...v1.21.0-dev.6) (2024-04-14)


### Features

* **Translations:** add hindi ( हिन्दी ) translations [#91](https://github.com/crimera/piko/issues/91) ([a766771](https://github.com/crimera/piko/commit/a766771d848a43c3a4d2ba5e955ab72015dfb69d))

## [1.21.0-dev.5](https://github.com/crimera/piko/compare/v1.21.0-dev.4...v1.21.0-dev.5) (2024-04-14)


### Features

* **Translations:** Added Brazilian Portuguese [#90](https://github.com/crimera/piko/issues/90) ([ad307da](https://github.com/crimera/piko/commit/ad307da5ba7f0739024c7a30de2cb3b09d8aee28))

## [1.21.0-dev.4](https://github.com/crimera/piko/compare/v1.21.0-dev.3...v1.21.0-dev.4) (2024-04-14)


### Updates

* Change settings string id ([b9c86d7](https://github.com/crimera/piko/commit/b9c86d715c0ae4ec2da63384462be3c784db7b73))

## [1.21.0-dev.3](https://github.com/crimera/piko/compare/v1.21.0-dev.2...v1.21.0-dev.3) (2024-04-14)


### Features

* Add russian translation ([2dc9cee](https://github.com/crimera/piko/commit/2dc9ceed63a5a965f9979e3df1094f6b7a12a001))

## [1.21.0-dev.2](https://github.com/crimera/piko/compare/v1.21.0-dev.1...v1.21.0-dev.2) (2024-04-11)


### Features

* Added resource file for strings ([181fd29](https://github.com/crimera/piko/commit/181fd298748c38dc53c10609b6714d8ce255d5be))

## [1.21.0-dev.1](https://github.com/crimera/piko/compare/v1.20.0...v1.21.0-dev.1) (2024-04-09)


### Features

* **Twitter:** Added `Feature Flag Hook` ([2328baf](https://github.com/crimera/piko/commit/2328baf92c733cf99ca364c978514b14b6aae2e0))
* **Twitter:** Added `Hide immersive player` patch ([a649652](https://github.com/crimera/piko/commit/a649652c982903ac29100933122db47e9ed86d17))


### Updates

* **Twitter:** Made some features to use flags ([04c366a](https://github.com/crimera/piko/commit/04c366a6cfac0e8d3ce0bcc41f61df76b6043f42))

## [1.20.0](https://github.com/crimera/piko/compare/v1.19.0...v1.20.0) (2024-04-08)


### Bug Fixes

* **Custom sharing domain:** Now works on "Copy Link" ([8f71415](https://github.com/crimera/piko/commit/8f71415e2c7cb5cf351bbcf11d2942d5f0771995))
* **Hide FAB:** Add description ([ae418a8](https://github.com/crimera/piko/commit/ae418a83d94cbb1091ba9fec3ce07a8704ab5c00))
* **Hide For You:** Included by default ([3b51053](https://github.com/crimera/piko/commit/3b51053658847d9d4d1864c5664c5247dd029bcf))


### Features

* Add `Show poll results` patch ([7b48f1b](https://github.com/crimera/piko/commit/7b48f1b9da05deb9aae73f0982f65eb527666fdc))
* **ci:** Add updates and refactors to changelog ([5fb8ef7](https://github.com/crimera/piko/commit/5fb8ef7902e6be592305c34cf3add0f06e477a68))
* **Show poll results:** Add a toggle on mod settings ([2624561](https://github.com/crimera/piko/commit/262456164e84d81b6c33436ac9f8fa21fa05e2ba))


### Updates

* **Twitter:** Added stubs to `No shortened URL` patch ([6d4f436](https://github.com/crimera/piko/commit/6d4f436f4773a667076930cbfb32eef2691b28bc))
* **Twitter:** refactor Timeline entry Hook ([271da73](https://github.com/crimera/piko/commit/271da73408735e8a3ef83e36bd2462d072c16bf2))
* **Twitter:** use stubs for Timeline entry Hook ([3ce1aee](https://github.com/crimera/piko/commit/3ce1aee32df656c64ba105cb45d148cd88db990a))

## [1.20.0-dev.4](https://github.com/crimera/piko/compare/v1.20.0-dev.3...v1.20.0-dev.4) (2024-04-08)


### Features

* **ci:** Add updates and refactors to changelog ([5fb8ef7](https://github.com/crimera/piko/commit/5fb8ef7902e6be592305c34cf3add0f06e477a68))

# [1.20.0-dev.3](https://github.com/crimera/piko/compare/v1.20.0-dev.2...v1.20.0-dev.3) (2024-04-07)

# [1.20.0-dev.2](https://github.com/crimera/piko/compare/v1.20.0-dev.1...v1.20.0-dev.2) (2024-04-07)


### Features

* **Show poll results:** Add a toggle on mod settings ([2624561](https://github.com/crimera/piko/commit/262456164e84d81b6c33436ac9f8fa21fa05e2ba))

# [1.20.0-dev.1](https://github.com/crimera/piko/compare/v1.19.1-dev.2...v1.20.0-dev.1) (2024-04-07)


### Features

* Add `Show poll results` patch ([7b48f1b](https://github.com/crimera/piko/commit/7b48f1b9da05deb9aae73f0982f65eb527666fdc))

## [1.19.1-dev.2](https://github.com/crimera/piko/compare/v1.19.1-dev.1...v1.19.1-dev.2) (2024-04-06)


### Bug Fixes

* **Custom sharing domain:** Now works on "Copy Link" ([8f71415](https://github.com/crimera/piko/commit/8f71415e2c7cb5cf351bbcf11d2942d5f0771995))
* **Hide For You:** Included by default ([3b51053](https://github.com/crimera/piko/commit/3b51053658847d9d4d1864c5664c5247dd029bcf))

## [1.19.1-dev.1](https://github.com/crimera/piko/compare/v1.19.0...v1.19.1-dev.1) (2024-04-05)


### Bug Fixes

* **Hide FAB:** Add description ([ae418a8](https://github.com/crimera/piko/commit/ae418a83d94cbb1091ba9fec3ce07a8704ab5c00))

# [1.19.0](https://github.com/crimera/piko/compare/v1.18.0...v1.19.0) (2024-04-02)


### Features

* **Twitter:** Added `Hide bookmark icon in timeline` ([ff66167](https://github.com/crimera/piko/commit/ff66167e5678adff4fde4e092a03b030a2a49693))

# [1.19.0-dev.1](https://github.com/crimera/piko/compare/v1.18.0...v1.19.0-dev.1) (2024-04-01)


### Features

* **Twitter:** Added `Hide bookmark icon in timeline` ([ff66167](https://github.com/crimera/piko/commit/ff66167e5678adff4fde4e092a03b030a2a49693))

# [1.18.0](https://github.com/crimera/piko/compare/v1.17.20...v1.18.0) (2024-04-01)


### Bug Fixes

* **Twitter - Custom sharing domain:** Disable by default ([6e7c170](https://github.com/crimera/piko/commit/6e7c17014b75d098eaef5ba3fbe4ed777eb416b1))


### Features

* **Twitter:** Add `Custom sharing domain` patch ([8ffd36c](https://github.com/crimera/piko/commit/8ffd36c4097f3dc1de9f654b44f077e8ed1e9481))

# [1.18.0-dev.2](https://github.com/crimera/piko/compare/v1.18.0-dev.1...v1.18.0-dev.2) (2024-04-01)

# [1.18.0-dev.1](https://github.com/crimera/piko/compare/v1.17.1...v1.18.0-dev.1) (2024-03-31)


### Bug Fixes

* **Twitter - Custom sharing domain:** Disable by default ([6e7c170](https://github.com/crimera/piko/commit/6e7c17014b75d098eaef5ba3fbe4ed777eb416b1))


### Features

* **Twitter:** Add `Custom sharing domain` patch ([8ffd36c](https://github.com/crimera/piko/commit/8ffd36c4097f3dc1de9f654b44f077e8ed1e9481))


## [1.17.1](https://github.com/crimera/piko/compare/v1.17.0...v1.17.1) (2024-03-29)


### Bug Fixes

* **Twitter - Bring back twitter:** Exclude by default ([e654549](https://github.com/crimera/piko/commit/e654549c95412b50932453732b215ebb097d4c19))
* **Twitter - Bring back twitter:** Now changes the app name by writing directly to AndroidManifest (Should make patching faster) ([f61468c](https://github.com/crimera/piko/commit/f61468c4cd1d42d7697a3179a4711dcb9ea01c9e))

## [1.17.1-dev.2](https://github.com/crimera/piko/compare/v1.17.1-dev.1...v1.17.1-dev.2) (2024-03-29)


### Bug Fixes

* **Twitter - Bring back twitter:** Now changes the app name by writing directly to AndroidManifest (Should make patching faster) ([f61468c](https://github.com/crimera/piko/commit/f61468c4cd1d42d7697a3179a4711dcb9ea01c9e))

## [1.17.1-dev.1](https://github.com/crimera/piko/compare/v1.17.0...v1.17.1-dev.1) (2024-03-29)


### Bug Fixes

* **Twitter - Bring back twitter:** Exclude by default ([e654549](https://github.com/crimera/piko/commit/e654549c95412b50932453732b215ebb097d4c19))

# [1.17.0](https://github.com/crimera/piko/compare/v1.16.0...v1.17.0) (2024-03-29)


### Bug Fixes

* **Twitter - Bring back twitter:** Add other languages ([2c63ff1](https://github.com/crimera/piko/commit/2c63ff1bc1444ed6d83f911becca4289001c306c))
* **Twitter - Bring back twitter:** Now changes notification icon ([7e281e4](https://github.com/crimera/piko/commit/7e281e42f2c809ad669113b81f9f888b168882ca))
* **Twitter - Bring back twitter:** Now changes notification icon ([8b57a07](https://github.com/crimera/piko/commit/8b57a07dfb7ca6ce3d92af92b09f2a786e0544f2))
* **Twitter:** Add splash screen icon ([b30e083](https://github.com/crimera/piko/commit/b30e0838de4ac5f72848dcc813d477e52a6d3f1c))


### Features

* **Twitter:** Add `Bring back twitter` patch ([b299b0c](https://github.com/crimera/piko/commit/b299b0c076a9ef68970bc57547830027d336b442))

# [1.17.0-dev.3](https://github.com/crimera/piko/compare/v1.17.0-dev.2...v1.17.0-dev.3) (2024-03-29)


### Bug Fixes

* **Twitter - Bring back twitter:** Now changes notification icon ([7e281e4](https://github.com/crimera/piko/commit/7e281e42f2c809ad669113b81f9f888b168882ca))
* **Twitter - Bring back twitter:** Now changes notification icon ([8b57a07](https://github.com/crimera/piko/commit/8b57a07dfb7ca6ce3d92af92b09f2a786e0544f2))

# [1.17.0-dev.2](https://github.com/crimera/piko/compare/v1.17.0-dev.1...v1.17.0-dev.2) (2024-03-29)


### Bug Fixes

* **Twitter - Bring back twitter:** Add other languages ([2c63ff1](https://github.com/crimera/piko/commit/2c63ff1bc1444ed6d83f911becca4289001c306c))

# [1.17.0-dev.1](https://github.com/crimera/piko/compare/v1.16.0...v1.17.0-dev.1) (2024-03-29)


### Bug Fixes

* **Twitter:** Add splash screen icon ([b30e083](https://github.com/crimera/piko/commit/b30e0838de4ac5f72848dcc813d477e52a6d3f1c))


### Features

* **Twitter:** Add `Bring back twitter` patch ([b299b0c](https://github.com/crimera/piko/commit/b299b0c076a9ef68970bc57547830027d336b442))

# [1.16.0](https://github.com/crimera/piko/compare/v1.15.3...v1.16.0) (2024-03-27)


### Features

* Update README.md ([7d801a9](https://github.com/crimera/piko/commit/7d801a983d7f36eeba927514a26d943e0ea371d5))

# [1.16.0-dev.3](https://github.com/crimera/piko/compare/v1.16.0-dev.2...v1.16.0-dev.3) (2024-03-27)


### Features

* Update README.md ([7d801a9](https://github.com/crimera/piko/commit/7d801a983d7f36eeba927514a26d943e0ea371d5))

## [1.15.3](https://github.com/crimera/piko/compare/v1.15.2...v1.15.3) (2024-03-27)


### Bug Fixes

* refactor ([eab113e](https://github.com/crimera/piko/commit/eab113e471c2b588bbda05acba57e669a312f52c))

# [1.16.0-dev.2](https://github.com/crimera/piko/compare/v1.16.0-dev.1...v1.16.0-dev.2) (2024-03-27)


### Bug Fixes

* idk ([0a4ade0](https://github.com/crimera/piko/commit/0a4ade0e4cf65078cfbdde349c8f7ee92754067f))
* refactor ([eab113e](https://github.com/crimera/piko/commit/eab113e471c2b588bbda05acba57e669a312f52c))
* update pr if it already exists ([6d616d2](https://github.com/crimera/piko/commit/6d616d20ea0a0a4880e5fb339dd569db1cc530a2))

## [1.15.2](https://github.com/crimera/piko/compare/v1.15.1...v1.15.2) (2024-03-27)


### Bug Fixes

* update pr if it already exists ([6d616d2](https://github.com/crimera/piko/commit/6d616d20ea0a0a4880e5fb339dd569db1cc530a2))

# [1.15.0](https://github.com/crimera/piko/compare/v1.14.0...v1.15.0) (2024-03-27)


### Bug Fixes

* Activate release so i can test ([34b7227](https://github.com/crimera/piko/commit/34b7227934bc77e024d37ae5f14b719a9d165288))
* Change run config ([18d4dce](https://github.com/crimera/piko/commit/18d4dcebb67a568e460931c6cd2003a0df7ae5ec))
* idk ([0a4ade0](https://github.com/crimera/piko/commit/0a4ade0e4cf65078cfbdde349c8f7ee92754067f))
* Remove semicolon ;-) ([46e60f7](https://github.com/crimera/piko/commit/46e60f71d3eefc2eb81fbca01451d52731c397c1))
* **Twitter:** fix `Reader mode` for 10.34 ([01cb8c9](https://github.com/crimera/piko/commit/01cb8c94c951c103f0ebea56f8daf88214eb77ae))


### Features

* Add support for patches.json ([f5f63a3](https://github.com/crimera/piko/commit/f5f63a330a06d03a10e1a3232d96764fc2d1ac7c))
* **Twitter:** Add `Dynamic color` patch from revanced ([d2bd0ef](https://github.com/crimera/piko/commit/d2bd0ef4a6c36650edde7c6d8c0c7587dcfb46ac))
* **Twitter:** Add `Premium settings` patch, Unlocks premium options from settings like custom app icon and custom navbar ([066e953](https://github.com/crimera/piko/commit/066e9538a983e6c261a56b1b568375132c0ca33c))
* **Twitter:** Added `App Icon and NavBar Customisation` settings ([7e67d2f](https://github.com/crimera/piko/commit/7e67d2f84049007fe0b836567fd5572ad62b8a43))
* **Twitter:** Added `Undo Post Patch` in mod settings ([54c722e](https://github.com/crimera/piko/commit/54c722e409e3367a9a1e42a7c51878ba81c3aa98))
* **Twitter:** Hide `Pinned posts by followers` ([5807471](https://github.com/crimera/piko/commit/5807471dda09eb379337f55edd650be12e66ff57))

# [1.15.0](https://github.com/crimera/piko/compare/v1.14.0...v1.15.0) (2024-03-27)


### Bug Fixes

* Activate release so i can test ([34b7227](https://github.com/crimera/piko/commit/34b7227934bc77e024d37ae5f14b719a9d165288))
* Change run config ([18d4dce](https://github.com/crimera/piko/commit/18d4dcebb67a568e460931c6cd2003a0df7ae5ec))
* Remove semicolon ;-) ([46e60f7](https://github.com/crimera/piko/commit/46e60f71d3eefc2eb81fbca01451d52731c397c1))
* **Twitter:** fix `Reader mode` for 10.34 ([01cb8c9](https://github.com/crimera/piko/commit/01cb8c94c951c103f0ebea56f8daf88214eb77ae))


### Features

* Add support for patches.json ([f5f63a3](https://github.com/crimera/piko/commit/f5f63a330a06d03a10e1a3232d96764fc2d1ac7c))
* **Twitter:** Add `Dynamic color` patch from revanced ([d2bd0ef](https://github.com/crimera/piko/commit/d2bd0ef4a6c36650edde7c6d8c0c7587dcfb46ac))
* **Twitter:** Add `Premium settings` patch, Unlocks premium options from settings like custom app icon and custom navbar ([066e953](https://github.com/crimera/piko/commit/066e9538a983e6c261a56b1b568375132c0ca33c))
* **Twitter:** Added `App Icon and NavBar Customisation` settings ([7e67d2f](https://github.com/crimera/piko/commit/7e67d2f84049007fe0b836567fd5572ad62b8a43))
* **Twitter:** Added `Undo Post Patch` in mod settings ([54c722e](https://github.com/crimera/piko/commit/54c722e409e3367a9a1e42a7c51878ba81c3aa98))
* **Twitter:** Hide `Pinned posts by followers` ([5807471](https://github.com/crimera/piko/commit/5807471dda09eb379337f55edd650be12e66ff57))

# [1.16.0-dev.1](https://github.com/crimera/piko/compare/v1.15.0-dev.3...v1.16.0-dev.1) (2024-03-27)


### Bug Fixes

* Activate release so i can test ([34b7227](https://github.com/crimera/piko/commit/34b7227934bc77e024d37ae5f14b719a9d165288))
* Remove semicolon ;-) ([46e60f7](https://github.com/crimera/piko/commit/46e60f71d3eefc2eb81fbca01451d52731c397c1))

# [1.16.0-dev.1](https://github.com/crimera/piko/compare/v1.15.0-dev.3...v1.16.0-dev.1) (2024-03-27)


### Bug Fixes

* Activate release so i can test ([34b7227](https://github.com/crimera/piko/commit/34b7227934bc77e024d37ae5f14b719a9d165288))

# [1.16.0-dev.1](https://github.com/crimera/piko/compare/v1.15.0-dev.3...v1.16.0-dev.1) (2024-03-27)



### Bug Fixes

* Change run config ([18d4dce](https://github.com/crimera/piko/commit/18d4dcebb67a568e460931c6cd2003a0df7ae5ec))
* **Twitter:** fix `Reader mode` for 10.34 ([01cb8c9](https://github.com/crimera/piko/commit/01cb8c94c951c103f0ebea56f8daf88214eb77ae))


### Features

* Add support for patches.json ([f5f63a3](https://github.com/crimera/piko/commit/f5f63a330a06d03a10e1a3232d96764fc2d1ac7c))
* **Twitter:** Add `Dynamic color` patch from revanced ([d2bd0ef](https://github.com/crimera/piko/commit/d2bd0ef4a6c36650edde7c6d8c0c7587dcfb46ac))
* **Twitter:** Add `Premium settings` patch, Unlocks premium options from settings like custom app icon and custom navbar ([066e953](https://github.com/crimera/piko/commit/066e9538a983e6c261a56b1b568375132c0ca33c))
* **Twitter:** Added `App Icon and NavBar Customisation` settings ([7e67d2f](https://github.com/crimera/piko/commit/7e67d2f84049007fe0b836567fd5572ad62b8a43))
* **Twitter:** Added `Undo Post Patch` in mod settings ([54c722e](https://github.com/crimera/piko/commit/54c722e409e3367a9a1e42a7c51878ba81c3aa98))
* **Twitter:** Hide `Pinned posts by followers` ([5807471](https://github.com/crimera/piko/commit/5807471dda09eb379337f55edd650be12e66ff57))

# [1.15.0](https://github.com/crimera/piko/compare/v1.14.0...v1.15.0) (2024-03-27)


### Bug Fixes

* Change run config ([18d4dce](https://github.com/crimera/piko/commit/18d4dcebb67a568e460931c6cd2003a0df7ae5ec))
* **Twitter:** fix `Reader mode` for 10.34 ([01cb8c9](https://github.com/crimera/piko/commit/01cb8c94c951c103f0ebea56f8daf88214eb77ae))


### Features

* Add support for patches.json ([f5f63a3](https://github.com/crimera/piko/commit/f5f63a330a06d03a10e1a3232d96764fc2d1ac7c))
* **Twitter:** Add `Dynamic color` patch from revanced ([d2bd0ef](https://github.com/crimera/piko/commit/d2bd0ef4a6c36650edde7c6d8c0c7587dcfb46ac))
* **Twitter:** Add `Premium settings` patch, Unlocks premium options from settings like custom app icon and custom navbar ([066e953](https://github.com/crimera/piko/commit/066e9538a983e6c261a56b1b568375132c0ca33c))
* **Twitter:** Added `App Icon and NavBar Customisation` settings ([7e67d2f](https://github.com/crimera/piko/commit/7e67d2f84049007fe0b836567fd5572ad62b8a43))
* **Twitter:** Added `Undo Post Patch` in mod settings ([54c722e](https://github.com/crimera/piko/commit/54c722e409e3367a9a1e42a7c51878ba81c3aa98))
* **Twitter:** Hide `Pinned posts by followers` ([5807471](https://github.com/crimera/piko/commit/5807471dda09eb379337f55edd650be12e66ff57))

# [1.15.0](https://github.com/crimera/piko/compare/v1.14.0...v1.15.0) (2024-03-27)


### Bug Fixes

* Change run config ([18d4dce](https://github.com/crimera/piko/commit/18d4dcebb67a568e460931c6cd2003a0df7ae5ec))
* **Twitter:** fix `Reader mode` for 10.34 ([01cb8c9](https://github.com/crimera/piko/commit/01cb8c94c951c103f0ebea56f8daf88214eb77ae))


### Features

* Add support for patches.json ([f5f63a3](https://github.com/crimera/piko/commit/f5f63a330a06d03a10e1a3232d96764fc2d1ac7c))
* **Twitter:** Add `Dynamic color` patch from revanced ([d2bd0ef](https://github.com/crimera/piko/commit/d2bd0ef4a6c36650edde7c6d8c0c7587dcfb46ac))
* **Twitter:** Add `Premium settings` patch, Unlocks premium options from settings like custom app icon and custom navbar ([066e953](https://github.com/crimera/piko/commit/066e9538a983e6c261a56b1b568375132c0ca33c))
* **Twitter:** Added `App Icon and NavBar Customisation` settings ([7e67d2f](https://github.com/crimera/piko/commit/7e67d2f84049007fe0b836567fd5572ad62b8a43))
* **Twitter:** Added `Undo Post Patch` in mod settings ([54c722e](https://github.com/crimera/piko/commit/54c722e409e3367a9a1e42a7c51878ba81c3aa98))
* **Twitter:** Hide `Pinned posts by followers` ([5807471](https://github.com/crimera/piko/commit/5807471dda09eb379337f55edd650be12e66ff57))


# [1.15.0-dev.3](https://github.com/crimera/piko/compare/v1.15.0-dev.2...v1.15.0-dev.3) (2024-03-27)


### Bug Fixes

* Change run config ([18d4dce](https://github.com/crimera/piko/commit/18d4dcebb67a568e460931c6cd2003a0df7ae5ec))
* **Twitter:** fix `Reader mode` for 10.34 ([01cb8c9](https://github.com/crimera/piko/commit/01cb8c94c951c103f0ebea56f8daf88214eb77ae))


### Features

* Add support for patches.json ([f5f63a3](https://github.com/crimera/piko/commit/f5f63a330a06d03a10e1a3232d96764fc2d1ac7c))
* **Twitter:** Add `Premium settings` patch, Unlocks premium options from settings like custom app icon and custom navbar ([066e953](https://github.com/crimera/piko/commit/066e9538a983e6c261a56b1b568375132c0ca33c))
* **Twitter:** Added `App Icon and NavBar Customisation` settings ([7e67d2f](https://github.com/crimera/piko/commit/7e67d2f84049007fe0b836567fd5572ad62b8a43))
* **Twitter:** Added `Undo Post Patch` in mod settings ([54c722e](https://github.com/crimera/piko/commit/54c722e409e3367a9a1e42a7c51878ba81c3aa98))

# [1.15.0-dev.3](https://github.com/crimera/piko/compare/v1.15.0-dev.2...v1.15.0-dev.3) (2024-03-27)


### Bug Fixes

* Change run config ([18d4dce](https://github.com/crimera/piko/commit/18d4dcebb67a568e460931c6cd2003a0df7ae5ec))
* **Twitter:** fix `Reader mode` for 10.34 ([01cb8c9](https://github.com/crimera/piko/commit/01cb8c94c951c103f0ebea56f8daf88214eb77ae))


### Features

* Add support for patches.json ([f5f63a3](https://github.com/crimera/piko/commit/f5f63a330a06d03a10e1a3232d96764fc2d1ac7c))
* **Twitter:** Add `Premium settings` patch, Unlocks premium options from settings like custom app icon and custom navbar ([066e953](https://github.com/crimera/piko/commit/066e9538a983e6c261a56b1b568375132c0ca33c))
* **Twitter:** Added `App Icon and NavBar Customisation` settings ([7e67d2f](https://github.com/crimera/piko/commit/7e67d2f84049007fe0b836567fd5572ad62b8a43))
* **Twitter:** Added `Undo Post Patch` in mod settings ([54c722e](https://github.com/crimera/piko/commit/54c722e409e3367a9a1e42a7c51878ba81c3aa98))

# [1.15.0-dev.3](https://github.com/crimera/piko/compare/v1.15.0-dev.2...v1.15.0-dev.3) (2024-03-27)


### Bug Fixes

* Change run config ([18d4dce](https://github.com/crimera/piko/commit/18d4dcebb67a568e460931c6cd2003a0df7ae5ec))
* **Twitter:** fix `Reader mode` for 10.34 ([01cb8c9](https://github.com/crimera/piko/commit/01cb8c94c951c103f0ebea56f8daf88214eb77ae))


### Features

* Add support for patches.json ([f5f63a3](https://github.com/crimera/piko/commit/f5f63a330a06d03a10e1a3232d96764fc2d1ac7c))
* **Twitter:** Add `Premium settings` patch, Unlocks premium options from settings like custom app icon and custom navbar ([066e953](https://github.com/crimera/piko/commit/066e9538a983e6c261a56b1b568375132c0ca33c))
* **Twitter:** Added `App Icon and NavBar Customisation` settings ([7e67d2f](https://github.com/crimera/piko/commit/7e67d2f84049007fe0b836567fd5572ad62b8a43))
* **Twitter:** Added `Undo Post Patch` in mod settings ([54c722e](https://github.com/crimera/piko/commit/54c722e409e3367a9a1e42a7c51878ba81c3aa98))

# [1.15.0-dev.3](https://github.com/crimera/piko/compare/v1.15.0-dev.2...v1.15.0-dev.3) (2024-03-27)


### Bug Fixes

* Change run config ([18d4dce](https://github.com/crimera/piko/commit/18d4dcebb67a568e460931c6cd2003a0df7ae5ec))
* **Twitter:** fix `Reader mode` for 10.34 ([01cb8c9](https://github.com/crimera/piko/commit/01cb8c94c951c103f0ebea56f8daf88214eb77ae))


### Features

* Add support for patches.json ([f5f63a3](https://github.com/crimera/piko/commit/f5f63a330a06d03a10e1a3232d96764fc2d1ac7c))
* **Twitter:** Add `Premium settings` patch, Unlocks premium options from settings like custom app icon and custom navbar ([066e953](https://github.com/crimera/piko/commit/066e9538a983e6c261a56b1b568375132c0ca33c))
* **Twitter:** Added `App Icon and NavBar Customisation` settings ([7e67d2f](https://github.com/crimera/piko/commit/7e67d2f84049007fe0b836567fd5572ad62b8a43))
* **Twitter:** Added `Undo Post Patch` in mod settings ([54c722e](https://github.com/crimera/piko/commit/54c722e409e3367a9a1e42a7c51878ba81c3aa98))

# [1.15.0-dev.3](https://github.com/crimera/piko/compare/v1.15.0-dev.2...v1.15.0-dev.3) (2024-03-27)


### Bug Fixes

* Change run config ([18d4dce](https://github.com/crimera/piko/commit/18d4dcebb67a568e460931c6cd2003a0df7ae5ec))


### Features

* Add support for patches.json ([f5f63a3](https://github.com/crimera/piko/commit/f5f63a330a06d03a10e1a3232d96764fc2d1ac7c))
* **Twitter:** Add `Premium settings` patch, Unlocks premium options from settings like custom app icon and custom navbar ([066e953](https://github.com/crimera/piko/commit/066e9538a983e6c261a56b1b568375132c0ca33c))

# [1.15.0-dev.3](https://github.com/crimera/piko/compare/v1.15.0-dev.2...v1.15.0-dev.3) (2024-03-27)


### Bug Fixes

* Change run config ([18d4dce](https://github.com/crimera/piko/commit/18d4dcebb67a568e460931c6cd2003a0df7ae5ec))


### Features

* Add support for patches.json ([f5f63a3](https://github.com/crimera/piko/commit/f5f63a330a06d03a10e1a3232d96764fc2d1ac7c))
* **Twitter:** Add `Premium settings` patch, Unlocks premium options from settings like custom app icon and custom navbar ([066e953](https://github.com/crimera/piko/commit/066e9538a983e6c261a56b1b568375132c0ca33c))

# [1.15.0-dev.3](https://github.com/crimera/piko/compare/v1.15.0-dev.2...v1.15.0-dev.3) (2024-03-25)


### Bug Fixes

* Change run config ([18d4dce](https://github.com/crimera/piko/commit/18d4dcebb67a568e460931c6cd2003a0df7ae5ec))


### Features

* Add support for patches.json ([f5f63a3](https://github.com/crimera/piko/commit/f5f63a330a06d03a10e1a3232d96764fc2d1ac7c))
* **Twitter:** Add `Premium settings` patch, Unlocks premium options from settings like custom app icon and custom navbar ([066e953](https://github.com/crimera/piko/commit/066e9538a983e6c261a56b1b568375132c0ca33c))

# [1.15.0](https://github.com/crimera/piko/compare/v1.14.0...v1.15.0) (2024-03-22)


### Bug Fixes

* Change run config ([9dc5772](https://github.com/crimera/piko/commit/9dc5772d527189b01d10c0ce8cb22acdb9c38bcd))


### Features

* Add support for packages.json ([f133c12](https://github.com/crimera/piko/commit/f133c1205f88d6fa1b00800a98d1895a52be412a))
* **Twitter:** Add `Dynamic color` patch from revanced ([d2bd0ef](https://github.com/crimera/piko/commit/d2bd0ef4a6c36650edde7c6d8c0c7587dcfb46ac))
* **Twitter:** Hide `Pinned posts by followers` ([5807471](https://github.com/crimera/piko/commit/5807471dda09eb379337f55edd650be12e66ff57))

# [1.15.0-dev.3](https://github.com/crimera/piko/compare/v1.15.0-dev.2...v1.15.0-dev.3) (2024-03-22)


### Bug Fixes

* Change run config ([9dc5772](https://github.com/crimera/piko/commit/9dc5772d527189b01d10c0ce8cb22acdb9c38bcd))


### Features

* Add support for packages.json ([f133c12](https://github.com/crimera/piko/commit/f133c1205f88d6fa1b00800a98d1895a52be412a))

# [1.15.0-dev.2](https://github.com/crimera/piko/compare/v1.15.0-dev.1...v1.15.0-dev.2) (2024-03-22)


### Features

* **Twitter:** Hide `Pinned posts by followers` ([5807471](https://github.com/crimera/piko/commit/5807471dda09eb379337f55edd650be12e66ff57))

# [1.15.0-dev.1](https://github.com/crimera/piko/compare/v1.14.0...v1.15.0-dev.1) (2024-03-22)


### Features

* **Twitter:** Add `Dynamic color` patch from revanced ([d2bd0ef](https://github.com/crimera/piko/commit/d2bd0ef4a6c36650edde7c6d8c0c7587dcfb46ac))

# [1.14.0](https://github.com/crimera/piko/compare/v1.13.0...v1.14.0) (2024-03-22)


### Features

* **Twitter:** Add settings for `Hide FAB` patch ([d5dde7c](https://github.com/crimera/piko/commit/d5dde7cb2e843bb0c8b90b7d1d5989bcf91e712b))
* **Twitter:** Add Settings for `Hide Recommended Users` patch ([f43f027](https://github.com/crimera/piko/commit/f43f027ef6ab0d5ab0bc3433762e9200a3d8e50d))
* **Twitter:** Add settings for `Remove view count` patch ([67bb8ad](https://github.com/crimera/piko/commit/67bb8ad9837bdc21c2fffcad7851e67a8e37054d))
* **Twitter:** Added `Hide Community Notes` to mod settings ([157a32b](https://github.com/crimera/piko/commit/157a32b1e9f24157ad81c2434206f6e13404bbc3))
* **Twitter:** Added `Hide Promoted Trends` to Mod Settings ([9d29f45](https://github.com/crimera/piko/commit/9d29f45ba67ab2d682afe466c2d30af8b3421975))
* **Twitter:** Added Ad block hooks ([4811584](https://github.com/crimera/piko/commit/4811584abfb764c3539733818cf1d2dc96ef1349))

# [1.14.0-dev.5](https://github.com/crimera/piko/compare/v1.14.0-dev.4...v1.14.0-dev.5) (2024-03-22)


### Features

* **Twitter:** Added Ad block hooks ([4811584](https://github.com/crimera/piko/commit/4811584abfb764c3539733818cf1d2dc96ef1349))

# [1.14.0-dev.4](https://github.com/crimera/piko/compare/v1.14.0-dev.3...v1.14.0-dev.4) (2024-03-18)


### Features

* **Twitter:** Added `Hide Community Notes` to mod settings ([157a32b](https://github.com/crimera/piko/commit/157a32b1e9f24157ad81c2434206f6e13404bbc3))
* **Twitter:** Added `Hide Promoted Trends` to Mod Settings ([9d29f45](https://github.com/crimera/piko/commit/9d29f45ba67ab2d682afe466c2d30af8b3421975))

# [1.14.0-dev.3](https://github.com/crimera/piko/compare/v1.14.0-dev.2...v1.14.0-dev.3) (2024-03-18)


### Features

* **Twitter:** Add settings for `Remove view count` patch ([67bb8ad](https://github.com/crimera/piko/commit/67bb8ad9837bdc21c2fffcad7851e67a8e37054d))

# [1.14.0-dev.2](https://github.com/crimera/piko/compare/v1.14.0-dev.1...v1.14.0-dev.2) (2024-03-18)


### Features

* **Twitter:** Add settings for `Hide FAB` patch ([d5dde7c](https://github.com/crimera/piko/commit/d5dde7cb2e843bb0c8b90b7d1d5989bcf91e712b))

# [1.14.0-dev.1](https://github.com/crimera/piko/compare/v1.13.0...v1.14.0-dev.1) (2024-03-18)


### Features

* **Twitter:** Add Settings for `Hide Recommended Users` patch ([f43f027](https://github.com/crimera/piko/commit/f43f027ef6ab0d5ab0bc3433762e9200a3d8e50d))

# [1.13.0](https://github.com/crimera/piko/compare/v1.12.0...v1.13.0) (2024-03-17)


### Features

* Add settings for `Disable chirp font` patch ([dad0a70](https://github.com/crimera/piko/commit/dad0a70b13a281937ea608e7866b20ae30863cb9))
* **Twitter:** Add Settings for `Hide Live Threads` and `Hide Banner` patch ([ca474d4](https://github.com/crimera/piko/commit/ca474d4e7a1baa5f9cfcfd03a0640a4867089131))
* **Twitter:** Added `Hide For You` in Mod Settings ([86ea20f](https://github.com/crimera/piko/commit/86ea20f7c4309de0fcae2ba8fa2fa47990290a5a))

# [1.13.0-dev.3](https://github.com/crimera/piko/compare/v1.13.0-dev.2...v1.13.0-dev.3) (2024-03-17)


### Features

* **Twitter:** Added `Hide For You` in Mod Settings ([86ea20f](https://github.com/crimera/piko/commit/86ea20f7c4309de0fcae2ba8fa2fa47990290a5a))

# [1.13.0-dev.2](https://github.com/crimera/piko/compare/v1.13.0-dev.1...v1.13.0-dev.2) (2024-03-17)


### Features

* **Twitter:** Add Settings for `Hide Live Threads` and `Hide Banner` patch ([ca474d4](https://github.com/crimera/piko/commit/ca474d4e7a1baa5f9cfcfd03a0640a4867089131))

# [1.13.0-dev.1](https://github.com/crimera/piko/compare/v1.12.0...v1.13.0-dev.1) (2024-03-16)


### Features

* Add settings for `Disable chirp font` patch ([dad0a70](https://github.com/crimera/piko/commit/dad0a70b13a281937ea608e7866b20ae30863cb9))

# [1.12.0](https://github.com/crimera/piko/compare/v1.11.1...v1.12.0) (2024-03-16)


### Features

* **Twitter:** added `Reader Mode patch` ([1348099](https://github.com/crimera/piko/commit/134809970363b6eb76b15f1c76b779307a663cc6))
* **Twitter:** added `Undo Posts Patch` ([ced73c6](https://github.com/crimera/piko/commit/ced73c6e316dbbdfaa60858ae5bc8a75b9afc3c0))
* **Twitter:** Hide Community Notes ([ab48b40](https://github.com/crimera/piko/commit/ab48b402009c8603bd9ad9507a444742642282df))

# [1.12.0-dev.1](https://github.com/crimera/piko/compare/v1.11.1...v1.12.0-dev.1) (2024-03-16)


### Features

* **Twitter:** added `Reader Mode patch` ([1348099](https://github.com/crimera/piko/commit/134809970363b6eb76b15f1c76b779307a663cc6))
* **Twitter:** added `Undo Posts Patch` ([ced73c6](https://github.com/crimera/piko/commit/ced73c6e316dbbdfaa60858ae5bc8a75b9afc3c0))
* **Twitter:** Hide Community Notes ([ab48b40](https://github.com/crimera/piko/commit/ab48b402009c8603bd9ad9507a444742642282df))

# [1.12.0-dev.2](https://github.com/crimera/piko/compare/v1.12.0-dev.1...v1.12.0-dev.2) (2024-03-13)


### Features

* **Twitter:** added `Reader Mode patch` ([e4c9e1a](https://github.com/crimera/piko/commit/e4c9e1ade4125c1e75d3becb7fa6271f83d526de))
* **Twitter:** added `Undo Posts Patch` ([9411550](https://github.com/crimera/piko/commit/9411550e26a18bbf90ee049bc3da558350275d81))

# [1.12.0-dev.1](https://github.com/crimera/piko/compare/v1.11.1...v1.12.0-dev.1) (2024-03-11)


### Features

* **Twitter:** Hide Community Notes ([2f018a4](https://github.com/crimera/piko/commit/2f018a443202d90c7de6324de00becca57a3de21))

## [1.11.1](https://github.com/crimera/piko/compare/v1.11.0...v1.11.1) (2024-03-08)


### Bug Fixes

* **Twitter:** Bring back download and viewcount patch ([3eea91f](https://github.com/crimera/piko/commit/3eea91f06a65433275bbd7437b290212654a308d))

## [1.11.1-dev.1](https://github.com/crimera/piko/compare/v1.11.0...v1.11.1-dev.1) (2024-03-08)


### Bug Fixes

* **Twitter:** Brick back download and viewcount patch ([8bf9de4](https://github.com/crimera/piko/commit/8bf9de44a875c2cfd3d248df5a6aa4d1e18903ee))

# [1.11.0](https://github.com/crimera/piko/compare/v1.10.0...v1.11.0) (2024-03-08)


### Bug Fixes

* **Twitter:** Download patch ([f87dee7](https://github.com/crimera/piko/commit/f87dee798632528595ac3efab1349d7a3fecafa0))
* unshort url for 10.30 ([ef3e00f](https://github.com/crimera/piko/commit/ef3e00f80fc469e5f09f8d7e43136791dbd94872))


### Features

* no t.co links ([776e700](https://github.com/crimera/piko/commit/776e7007b571cc2803d566891c72a42057297bb6))
* **Twitter:** Disable in favor of official patch bundle ([9a81fab](https://github.com/crimera/piko/commit/9a81fabed7457d1be967250faa548a67accc27bc))
* **Twitter:** Hide FAB ([4cdf50f](https://github.com/crimera/piko/commit/4cdf50fb036ed8596c9e4a3e3f1702ae78525d28))
* **Twitter:** Hide FAB Menu Buttons ([4f25bd6](https://github.com/crimera/piko/commit/4f25bd60888b70ccd4518a42459583b6ef8fcc54))
* **Twitter:** Hide Promoted Trends ([1be736e](https://github.com/crimera/piko/commit/1be736e31ae11d21a62f7a3f4aad2689647ada92))

# [1.11.0-dev.3](https://github.com/crimera/piko/compare/v1.11.0-dev.2...v1.11.0-dev.3) (2024-03-08)


### Bug Fixes

* **Twitter:** Download patch ([f87dee7](https://github.com/crimera/piko/commit/f87dee798632528595ac3efab1349d7a3fecafa0))

# [1.11.0-dev.2](https://github.com/crimera/piko/compare/v1.11.0-dev.1...v1.11.0-dev.2) (2024-03-04)


### Features

* **Twitter:** Hide FAB ([4cdf50f](https://github.com/crimera/piko/commit/4cdf50fb036ed8596c9e4a3e3f1702ae78525d28))
* **Twitter:** Hide FAB Menu Buttons ([4f25bd6](https://github.com/crimera/piko/commit/4f25bd60888b70ccd4518a42459583b6ef8fcc54))
* **Twitter:** Hide Promoted Trends ([1be736e](https://github.com/crimera/piko/commit/1be736e31ae11d21a62f7a3f4aad2689647ada92))

# [1.11.0-dev.1](https://github.com/crimera/piko/compare/v1.10.0...v1.11.0-dev.1) (2024-03-03)


### Bug Fixes

* unshort url for 10.30 ([ef3e00f](https://github.com/crimera/piko/commit/ef3e00f80fc469e5f09f8d7e43136791dbd94872))


### Features

* no t.co links ([776e700](https://github.com/crimera/piko/commit/776e7007b571cc2803d566891c72a42057297bb6))
* **Twitter:** Disable in favor of official patch bundle ([9a81fab](https://github.com/crimera/piko/commit/9a81fabed7457d1be967250faa548a67accc27bc))

# [1.10.0](https://github.com/crimera/piko/compare/v1.9.1...v1.10.0) (2024-03-03)


### Bug Fixes

* **Twitter:** Fixup patch dependecy ([867926a](https://github.com/crimera/piko/commit/867926acccd1b768b63475aa79d376940a87e075))


### Features

* **Twitter:** Add `Disable chirp font` patch ([59eafd1](https://github.com/crimera/piko/commit/59eafd1ecf9459123fd8565121fd0a42404956bc))

## [1.9.1](https://github.com/crimera/piko/compare/v1.9.0...v1.9.1) (2024-03-02)


### Bug Fixes

* **Twitter:** Only show settings category if patch is applied ([2141680](https://github.com/crimera/piko/commit/21416800ce7176c713b1521649d9760fcd450158))

## [1.9.1-dev.1](https://github.com/crimera/piko/compare/v1.9.0...v1.9.1-dev.1) (2024-03-02)


### Bug Fixes

* **Twitter:** Only show settings category if patch is applied ([2141680](https://github.com/crimera/piko/commit/21416800ce7176c713b1521649d9760fcd450158))

# [1.9.0](https://github.com/crimera/piko/compare/v1.8.1...v1.9.0) (2024-03-02)


### Features

* **Twitter:** Allow choosing public folder ([6c36202](https://github.com/crimera/piko/commit/6c362027f608ea2a84407d681d9b47775ccb0f4d))

# [1.9.0-dev.1](https://github.com/crimera/piko/compare/v1.8.1...v1.9.0-dev.1) (2024-03-02)


### Features

* **Twitter:** Allow choosing public folder ([6c36202](https://github.com/crimera/piko/commit/6c362027f608ea2a84407d681d9b47775ccb0f4d))

## [1.8.1](https://github.com/crimera/piko/compare/v1.8.0...v1.8.1) (2024-03-02)


### Bug Fixes

* Update pull_request.yml[skip ci] ([30e1e4f](https://github.com/crimera/piko/commit/30e1e4f828e4018b3595ea99d21d2a527145b2f5))

# [1.8.0](https://github.com/crimera/piko/compare/v1.7.0...v1.8.0) (2024-03-02)


### Features

* **Twitter:** Add `Custom download folder` ([7c93541](https://github.com/crimera/piko/commit/7c935415329303066cd69753bdeba9657be0f742))
* **Twitter:** Add back settings ([5ba3580](https://github.com/crimera/piko/commit/5ba3580ec94a158c2e1043393aab76a0fae3481c))

# [1.8.0-dev.2](https://github.com/crimera/piko/compare/v1.8.0-dev.1...v1.8.0-dev.2) (2024-03-02)


### Features

* **Twitter:** Add `Custom download folder` ([7c93541](https://github.com/crimera/piko/commit/7c935415329303066cd69753bdeba9657be0f742))

# [1.8.0-dev.1](https://github.com/crimera/piko/compare/v1.7.0...v1.8.0-dev.1) (2024-03-02)


### Features

* **Twitter:** Add back settings ([5ba3580](https://github.com/crimera/piko/commit/5ba3580ec94a158c2e1043393aab76a0fae3481c))

# [1.7.0](https://github.com/crimera/piko/compare/v1.6.0...v1.7.0) (2024-03-02)


### Bug Fixes

* **Twitter:** disable `Hide For You` by default. ([b933c19](https://github.com/crimera/piko/commit/b933c196f8325a02e82520419c049260cc3a4590))


### Features

* **Twitter:** Hide Banner ([b653c84](https://github.com/crimera/piko/commit/b653c84d4992be90386ce3e9031b138a4310b9fa))
* **Twitter:** Hide Live Threads ([0202771](https://github.com/crimera/piko/commit/0202771020f97c32370d9ee7d110399eae6c264c))

# [1.7.0-dev.2](https://github.com/crimera/piko/compare/v1.7.0-dev.1...v1.7.0-dev.2) (2024-03-02)


### Bug Fixes

* **Twitter:** disable `Hide For You` by default. ([b933c19](https://github.com/crimera/piko/commit/b933c196f8325a02e82520419c049260cc3a4590))

# [1.7.0-dev.1](https://github.com/crimera/piko/compare/v1.6.0...v1.7.0-dev.1) (2024-03-02)


### Features

* **Twitter:** Hide Banner ([b653c84](https://github.com/crimera/piko/commit/b653c84d4992be90386ce3e9031b138a4310b9fa))
* **Twitter:** Hide Live Threads ([0202771](https://github.com/crimera/piko/commit/0202771020f97c32370d9ee7d110399eae6c264c))

# [1.6.0](https://github.com/crimera/piko/compare/v1.5.1...v1.6.0) (2024-03-01)


### Features

* **Twitter:** Hide For You ([c18f143](https://github.com/crimera/piko/commit/c18f1437882d6aba85c076a198a1a3c87067b716))
* **Twitter:** Hide Recommended Users ([2a55292](https://github.com/crimera/piko/commit/2a55292f81cd2d6f06058c8b4f347016700695eb))

# [1.6.0-dev.1](https://github.com/crimera/piko/compare/v1.5.1...v1.6.0-dev.1) (2024-03-01)


### Features

* **Twitter:** Hide For You ([c18f143](https://github.com/crimera/piko/commit/c18f1437882d6aba85c076a198a1a3c87067b716))
* **Twitter:** Hide Recommended Users ([2a55292](https://github.com/crimera/piko/commit/2a55292f81cd2d6f06058c8b4f347016700695eb))

## [1.5.1](https://github.com/crimera/piko/compare/v1.5.0...v1.5.1) (2024-03-01)


### Reverts

* Revert "feat(Twitter): Added mod settings" ([c252333](https://github.com/crimera/piko/commit/c2523332865ce6338361e49a6c862d491ef3323b))

# [1.5.0](https://github.com/crimera/piko/compare/v1.4.0...v1.5.0) (2024-02-27)


### Features

* **Twitter:** Added mod settings ([76ee8a1](https://github.com/crimera/piko/commit/76ee8a1cfbfe895d006d57afd0c56ed2373d96e6))

# [1.4.0](https://github.com/crimera/piko/compare/v1.3.2...v1.4.0) (2024-02-10)


### Features

* **twitter:** Add `Clear tracking params` patch @FrozenAlex's ([c1f3148](https://github.com/crimera/piko/commit/c1f3148c8b701d76fa518256b320552b9b8a2dd7))

## [1.3.2](https://github.com/crimera/piko/compare/v1.3.1...v1.3.2) (2024-02-10)


### Bug Fixes

* **twitter:** Exclude `Google Ads Patch` by default ([a26e03a](https://github.com/crimera/piko/commit/a26e03a157815445d8416a68dd43aa96b2859ce1))

## [1.3.1](https://github.com/crimera/piko/compare/v1.3.0...v1.3.1) (2024-02-10)


### Bug Fixes

* **twitter:** Remove debug code ([2eb2fa3](https://github.com/crimera/piko/commit/2eb2fa34e101a6d838b28eabc3c0c7ae08af9dc4))

# [1.3.0](https://github.com/crimera/piko/compare/v1.2.1...v1.3.0) (2024-02-08)


### Features

* **twitter:** Add Show sensitive media patch ([21c3fb4](https://github.com/crimera/piko/commit/21c3fb429b82acfb3a6b497c06c2a4e2ad596a9f))

## [1.2.1](https://github.com/crimera/piko/compare/v1.2.0...v1.2.1) (2024-02-08)


### Bug Fixes

* **twitter:** Add twitter to compatible package for SelectableTextPatch ([0b6ee33](https://github.com/crimera/piko/commit/0b6ee33a044433c498c7d522b92b33623dca1a93))

# [1.2.0](https://github.com/crimera/piko/compare/v1.1.0...v1.2.0) (2024-02-08)


### Features

* **twitter:** Add selectable text patch ([ee3bcf1](https://github.com/crimera/piko/commit/ee3bcf17900dfe549a07426182a2149bcf16f87a))

# [1.1.0](https://github.com/crimera/piko/compare/v1.0.0...v1.1.0) (2024-01-31)


### Features

* **twitter:** Add google ads patch ([152b118](https://github.com/crimera/piko/commit/152b118737f84ebc155377ca58c7131486bad8a9))

# 1.0.0 (2024-01-30)


### Bug Fixes

* **twitter:** Refactor packages ([8a5cea6](https://github.com/crimera/piko/commit/8a5cea659350a774fe97ec52bc467f10ba1be341))


### Features

* **twitter:** Add download patch ([b9612bf](https://github.com/crimera/piko/commit/b9612bfc69656681f3b84d0c8837e5d3dad9bc0d))
* **twitter:** Add remove view count patch ([e31f222](https://github.com/crimera/piko/commit/e31f22278e6a5704037f3e3ed1583c25025abed8))

# 1.0.0 (2024-01-26)


### Features

* Init ([66be625](https://github.com/ReVanced/revanced-patches-template/commit/66be625f25ee2d678dac62a5bf4daa631284f8f6))

# 1.0.0-dev.1 (2024-01-26)


### Features

* Init ([66be625](https://github.com/ReVanced/revanced-patches-template/commit/66be625f25ee2d678dac62a5bf4daa631284f8f6))
