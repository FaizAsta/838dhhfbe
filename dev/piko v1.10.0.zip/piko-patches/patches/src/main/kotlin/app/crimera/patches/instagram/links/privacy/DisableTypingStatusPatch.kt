/*
 * Copyright (C) 2026 piko <https://github.com/crimera/piko>
 *
 * See the included NOTICE file for GPLv3 §7(b) terms that apply to this code.
 */

package app.crimera.patches.instagram.links.privacy

import app.crimera.patches.instagram.misc.actionBar.chatActionBarButton.chatActionBarButtonPatch
import app.crimera.patches.instagram.misc.actionBar.inboxActionBarButton.inboxActionBarButtonPatch
import app.crimera.patches.instagram.misc.settings.settingsPatch
import app.crimera.patches.instagram.utils.Constants.COMPATIBILITY_INSTAGRAM
import app.crimera.patches.instagram.utils.Constants.PREF_CALL_DESCRIPTOR
import app.crimera.patches.instagram.utils.enableSettings
import app.morphe.patcher.Fingerprint
import app.morphe.patcher.InstructionLocation.MatchAfterImmediately
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.fieldAccess
import app.morphe.patcher.literal
import app.morphe.patcher.opcode
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction

internal object DMAfterTextChangedFingerprint : Fingerprint(
    name = "afterTextChanged",
    filters =
        listOf(
            literal(8388659L), // 0x800032
            literal(8388627L), // 0x800013
        ),
)

internal object DMOnTextChangedFingerprint : Fingerprint(
    name = "onTextChanged",
    classFingerprint = DMAfterTextChangedFingerprint,
    filters = listOf(
        fieldAccess(opcode = Opcode.IGET_BOOLEAN),
        opcode(Opcode.IF_NEZ, location = MatchAfterImmediately()),
    ),
)

// Thanks to MyInsta.
@Suppress("unused")
val disableTypingStatusPatch =
    bytecodePatch(
        name = "Disable typing status",
    ) {
        dependsOn(settingsPatch, chatActionBarButtonPatch, inboxActionBarButtonPatch)
        compatibleWith(COMPATIBILITY_INSTAGRAM)

        execute {

            DMOnTextChangedFingerprint.let {
                val index = it.instructionMatches.first().index
                val originalInstruction = it.method.getInstruction<OneRegisterInstruction>(index)
                val register = originalInstruction.registerA
                it.method.addInstructionsWithLabels(
                    index,
                    """
                    $PREF_CALL_DESCRIPTOR->disableTypingStatus()Z
                    move-result v$register
                    if-eqz v$register, :piko
                    return-void
                    """.trimIndent(),
                    ExternalLabel("piko", originalInstruction),
                )
            }

            enableSettings("disableTypingStatus")
        }
    }
