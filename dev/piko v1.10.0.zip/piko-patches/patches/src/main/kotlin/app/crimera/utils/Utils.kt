/*
 * Copyright (C) 2026 piko <https://github.com/crimera/piko>
 *
 * See the included NOTICE file for GPLv3 §7(b) terms that apply to this code.
 */

package app.crimera.utils

import app.morphe.patcher.Fingerprint
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.extensions.InstructionExtensions.instructions
import app.morphe.patcher.extensions.InstructionExtensions.replaceInstruction
import app.morphe.patcher.patch.BytecodePatchContext
import app.morphe.patcher.patch.PatchException
import app.morphe.patcher.patch.ResourcePatchContext
import app.morphe.patcher.util.proxy.mutableTypes.MutableMethod
import app.morphe.util.ResourceGroup
import app.morphe.util.copyResources
import app.morphe.util.findElementByAttributeValue
import app.morphe.patcher.util.getReference
import app.morphe.util.inputStreamFromBundledResource
import app.morphe.patcher.util.registersUsed
import com.android.tools.smali.dexlib2.HiddenApiRestriction
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.builder.BuilderInstruction
import com.android.tools.smali.dexlib2.builder.instruction.BuilderInstruction21c
import com.android.tools.smali.dexlib2.dexbacked.reference.DexBackedMethodReference
import com.android.tools.smali.dexlib2.iface.Annotation
import com.android.tools.smali.dexlib2.iface.Method
import com.android.tools.smali.dexlib2.iface.MethodImplementation
import com.android.tools.smali.dexlib2.iface.MethodParameter
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.formats.*
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.Reference
import com.android.tools.smali.dexlib2.iface.reference.StringReference
import org.w3c.dom.Element

fun ResourcePatchContext.replaceXmlResources(
    sourceResourceDirectory: String,
    vararg resourceGroups: ResourceGroup,
) {
    resourceGroups.forEach { resourceGroup ->
        resourceGroup.resources.forEach { resource ->
            val sourceFile = "${resourceGroup.resourceDirectoryName}/$resource"
            val targetFile = "res/$sourceFile"

            // If target file doesn't exist, use copyResources as fallback
            if (!get(targetFile).exists()) {
                copyResources(sourceResourceDirectory, resourceGroup)
                return@forEach
            }

            // Load replacement values from the source resource
            val replacementDoc = document(inputStreamFromBundledResource(sourceResourceDirectory, sourceFile)!!)

            // Apply replacements to the target resource
            document(targetFile).use { targetDoc ->
                val replacementNodes = replacementDoc.getElementsByTagName("string")
                val targetNodes = targetDoc.getElementsByTagName("string")

                // Single loop: iterate through replacement strings and apply them directly
                for (i in 0 until replacementNodes.length) {
                    val replacementNode = replacementNodes.item(i) as Element
                    val stringName = replacementNode.getAttribute("name")
                    val replacementValue = replacementNode.textContent

                    // Find and replace the corresponding element in target document
                    val targetElement = targetNodes.findElementByAttributeValue("name", stringName)
                    targetElement?.textContent = replacementValue
                }
            }

            replacementDoc.close()
        }
    }
}

fun ResourcePatchContext.replaceStringsInFile(
    vararg resourceGroups: ResourceGroup,
    replacements: Map<String, String>,
) {
    resourceGroups.forEach { resourceGroup ->
        resourceGroup.resources.forEach { resource ->
            val sourcePath = "${resourceGroup.resourceDirectoryName}/$resource"
            val sourceFile = get("res/$sourcePath")
            if (sourceFile.exists()) {
                var content = sourceFile.readText()

                replacements.forEach { (from, to) ->
                    content = content.replace(from, to)
                }

                sourceFile.writeText(content)
            }
        }
    }
}

data class MethodFieldMetadata(
    val name: String,
    val definingClass: String,
    val returnType: String,
)

fun classNameToExtension(className: String): String = className.removePrefix("L").replace("/", ".").removeSuffix(";")

fun extensionToClassName(className: String): String = "L" + className.replace(".", "/") + ";"

fun Instruction.methodExtractor(): MethodFieldMetadata {
    val ref = getReference<MethodReference>()
    val defMethodClassName = classNameToExtension(ref!!.definingClass)
    val returnTypeClassName = classNameToExtension(ref.returnType)
    return MethodFieldMetadata(ref.name, defMethodClassName, returnTypeClassName)
}

fun Instruction.fieldExtractor(): MethodFieldMetadata {
    val ref = getReference<FieldReference>()
    val defMethodClassName = classNameToExtension(ref!!.definingClass)
    val fieldTypeClassName = classNameToExtension(ref.type)
    return MethodFieldMetadata(ref.name, defMethodClassName, fieldTypeClassName)
}

fun Reference.extractDescriptors(): List<String> {
    val regex = Regex("L[^;]+;")
    return regex.findAll(this.toString()).map { it.value }.toList()
}

context(patchContext: BytecodePatchContext)
fun Fingerprint.getReference(index: Int): Reference = method.getInstruction<ReferenceInstruction>(index).reference

context(patchContext: BytecodePatchContext)
fun Fingerprint.getMethodName(index: Int): String = (getReference(index) as DexBackedMethodReference).name

context(patchContext: BytecodePatchContext)
fun Fingerprint.getFieldName(index: Int): String = (getReference(index) as FieldReference).name

context(patchContext: BytecodePatchContext)
fun Fingerprint.changeStringAt(
    index: Int,
    value: String,
) {
    val matches = method.instructions.filter { it.opcode == Opcode.CONST_STRING }
    val instruction =
        matches.getOrNull(index)
            ?: throw PatchException("Expected at least ${index + 1} CONST_STRING instruction(s), found ${matches.size}")
    val register = (instruction as BuilderInstruction21c).registerA
    method.replaceInstruction(instruction.location.index, "const-string v$register, \"$value\"")
}

/** Rewrites the placeholder equal to [sentinel], so slot order can shift without breaking. */
context(patchContext: BytecodePatchContext)
fun Fingerprint.changeString(
    sentinel: String,
    value: String,
) {
    val instruction =
        method.instructions.firstOrNull {
            (it.opcode == Opcode.CONST_STRING || it.opcode == Opcode.CONST_STRING_JUMBO) &&
                it.getReference<StringReference>()?.string == sentinel
        } ?: throw PatchException("Expected a CONST_STRING/CONST_STRING_JUMBO instruction with sentinel \"$sentinel\"")
    val register = instruction.registersUsed[0]
    method.replaceInstruction(instruction.location.index, "const-string v$register, \"$value\"")
}

context(patchContext: BytecodePatchContext)
fun Fingerprint.changeFirstString(value: String) {
    changeStringAt(0, value)
}

fun instructionToString(ins: Instruction): String =
    when (ins) {
        is Instruction21c -> {
            if (ins.opcode == Opcode.CONST_STRING) {
                "${ins.opcode.name} v${ins.registerA}, \"${ins.reference}\""
            } else {
                "${ins.opcode.name} v${ins.registerA}, ${ins.reference}"
            }
        }

        is Instruction11n -> {
            "${ins.opcode.name} v${ins.registerA}, ${ins.narrowLiteral}"
        }

        is Instruction35c -> {
            var regs = ""

            val regMap =
                mapOf(
                    1 to ins.registerC,
                    2 to ins.registerD,
                    3 to ins.registerE,
                    4 to ins.registerF,
                    5 to ins.registerG,
                )

            for (i in 1..ins.registerCount) {
                regs += "v${regMap[i]}"

                if (ins.registerCount != i) {
                    regs += ", "
                }
            }
            "${ins.opcode.name} {$regs}, ${ins.reference}"
        }

        is Instruction21s -> {
            "${ins.opcode.name} v${ins.registerA}, ${ins.narrowLiteral}"
        }

        is Instruction22x -> {
            "${ins.opcode.name} v${ins.registerA}, v${ins.registerB}"
        }

        is Instruction3rc -> {
            "${ins.opcode.name} {v${ins.startRegister} .. v${ins.registerCount - 1}}, ${ins.reference}"
        }

        is Instruction11x -> {
            "${ins.opcode.name} v${ins.registerA}"
        }

        is Instruction10x -> {
            ins.opcode.name
        }

        is Instruction31i -> {
            "${ins.opcode.name} v${ins.registerA}, ${ins.narrowLiteral}"
        }

        else -> {
            throw PatchException("${ins.javaClass} is not supported")
        }
    }

val MutableList<BuilderInstruction>.indexOfLastNewInstance
    get() = this.indexOfLast { it.opcode == Opcode.NEW_INSTANCE }

val MutableList<BuilderInstruction>.indexOfLastFilledNewArrayRange
    get() = this.indexOfLast { it.opcode == Opcode.FILLED_NEW_ARRAY_RANGE }

fun MutableMethod.lastInstruction(
    beforeIndex: Int = 0,
    targetOpcode: Opcode,
): BuilderInstruction? {
    val instructions = this.implementation?.instructions ?: return null

    var endIndex: Int = beforeIndex
    if (beforeIndex == 0) endIndex = instructions.size

    val index = instructions.indexOfLast { it.opcode == targetOpcode && it.location.index <= endIndex }
    if (index < 0) return null

    return getInstruction(index)
}

fun MutableMethod.lastInstruction(targetOpcode: Opcode): Instruction? = lastInstruction(0, targetOpcode)

class InitMethod(
    private val validator: () -> Unit,
    private val compare: (other: MethodReference) -> Int,
    private val definingClass: String,
    private val name: String,
    private val parameterTypes: MutableList<out CharSequence>,
    private val returnType: String,
    private val annotations: MutableSet<out Annotation>,
    private val accessFlags: Int,
    private val hiddenApiRestrictions: MutableSet<HiddenApiRestriction>,
    private val parameters: MutableList<out MethodParameter>,
    private val implementation: MethodImplementation,
) : Method {
    override fun validateReference() = validator()

    override fun compareTo(other: MethodReference): Int = this.compare(other)

    override fun getDefiningClass(): String = definingClass

    override fun getName(): String = name

    override fun getParameterTypes(): MutableList<out CharSequence> = parameterTypes

    override fun getReturnType(): String = returnType

    override fun getAnnotations(): MutableSet<out Annotation> = annotations

    override fun getAccessFlags(): Int = accessFlags

    override fun getHiddenApiRestrictions(): MutableSet<HiddenApiRestriction> = hiddenApiRestrictions

    override fun getParameters(): MutableList<out MethodParameter> = parameters

    override fun getImplementation(): MethodImplementation = implementation
}
