/*
 * Copyright (C) 2026 piko <https://github.com/crimera/piko>
 *
 * See the included NOTICE file for GPLv3 §7(b) terms that apply to this code.
*/


package app.morphe.extension.instagram.patches.comment.saveMediaButton;

@SuppressWarnings("unused")
public final class SaveMediaButton {
    public static final SaveMediaButton A00 = new SaveMediaButton();
}