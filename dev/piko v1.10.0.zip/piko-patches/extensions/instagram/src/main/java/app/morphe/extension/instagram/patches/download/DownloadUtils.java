/*
 * Copyright (C) 2026 piko <https://github.com/crimera/piko>
 *
 * See the included NOTICE file for GPLv3 §7(b) terms that apply to this code.
 */


package app.morphe.extension.instagram.patches.download;

import static app.morphe.extension.instagram.utils.IgStr.str;

import android.app.Dialog;
import android.app.Notification;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.graphics.Color;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.lang.reflect.Field;
import java.time.ZoneId;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import app.morphe.extension.instagram.constants.Constants;
import app.morphe.extension.instagram.constants.UI;
import app.morphe.extension.instagram.settings.PikoMenuSheet;
import app.morphe.extension.instagram.settings.Settings;
import app.morphe.extension.instagram.utils.Pref;
import app.morphe.extension.instagram.utils.MediaUrls;
import app.morphe.extension.crimera.sharedPreference.SharedPref;
import app.morphe.extension.instagram.settings.SettingsStatus;
import app.morphe.extension.instagram.entity.DashVideoData;
import app.morphe.extension.instagram.entity.Entity;
import app.morphe.extension.instagram.entity.MediaData;
import app.morphe.extension.instagram.entity.UserData;
import app.morphe.extension.instagram.entity.VideoData;
import app.morphe.extension.instagram.entity.VideoResolution;
import app.morphe.extension.instagram.entity.VideoVariant;
import app.morphe.extension.instagram.entity.ImageResolution;
import app.morphe.extension.instagram.entity.InstagramDialogBox;
import app.morphe.extension.instagram.entity.AudioMediaInterface;
import app.morphe.extension.instagram.entity.MediaInterface;
import app.morphe.extension.shared.Logger;
import app.morphe.extension.shared.ResourceType;
import app.morphe.extension.shared.ResourceUtils;
import app.morphe.extension.shared.Utils;
import app.morphe.extension.instagram.settings.ActivityHook;
import app.morphe.extension.instagram.patches.Links;
import app.morphe.extension.crimera.ObjectBrowser;
import app.morphe.extension.crimera.downloader.MediaDownloader;
import app.morphe.extension.crimera.downloader.DownloadMetadata;
import app.morphe.extension.crimera.downloader.DownloadRequest;
import app.morphe.extension.crimera.downloader.MediaType;
import app.morphe.extension.crimera.downloader.StorageUtils;
import app.morphe.extension.crimera.PikoUtils;

import com.instagram.common.session.UserSession;

public class DownloadUtils {

    private static MediaDownloader downloadAllDownloader;

    private static synchronized MediaDownloader getDownloadAllDownloader(Context context) {
        if (downloadAllDownloader == null) {
            downloadAllDownloader = new MediaDownloader(context);
        }
        return downloadAllDownloader;
    }

    public static String getSubfolderName(String username){
        boolean SPLIT_BY_USERNAME = Pref.downloadUsernameFolder() && SettingsStatus.downloadMedia;
        return SPLIT_BY_USERNAME ? username : null;
    }

    private static void buildVariantDialogBox(
            Context context,
            MediaData mediaInfo,
            int position,
            int filenameIndex,
            MediaType mediaType,
            DialogInterface.OnDismissListener onDismiss
    ) throws Exception {
        MediaData currentMediaData = mediaInfo.getMediaAt(position);
        String username = mediaInfo.getUserData().getUsername();
        List<MediaInterface> variantList;
        String title = "";
        if(mediaType.equals(MediaType.VIDEO)){
            title = str("piko_video_variants");
            List<VideoVariant> videos = new ArrayList<>();
            if (Pref.preferDashFormat()) videos.addAll(currentMediaData.getDashVideos());
            List<VideoData> progressive = currentMediaData.getVideoVariants();
            if (progressive != null) videos.addAll(progressive);
            variantList = new ArrayList<>(VideoResolution.group(videos));
        }else{
            title = str("piko_image_variants");
            variantList = new ArrayList<>(ImageResolution.group(currentMediaData.getImageVariants()));
        }

        InstagramDialogBox dialog = new InstagramDialogBox(context);
        ArrayList<String> options = new ArrayList<>();
        for (MediaInterface item : variantList) {
            String label = item.getLabel();
            if (item instanceof VideoResolution) {
                label = item.shortSide() > 0 ? label : str("piko_unknown");
            }
            options.add(label);
        }
        CharSequence[] items = options.toArray(new CharSequence[0]);

        dialog.addDialogMenuItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int which) {
                MediaInterface data = variantList.get(which);

                try {
                    String subFolder = getSubfolderName(username);
                    String fileName = username + "_" + currentMediaData.getVariantFileName(data);
                    DownloadRequest request = buildMediaRequest(
                            mediaInfo,
                            currentMediaData,
                            position,
                            filenameIndex,
                            data.getMediaType(),
                            data.getUrl(),
                            subFolder,
                            fileName,
                            data
                    );
                    enqueueDownload(context, request);
                } catch (Exception e) {
                    PikoUtils.logger(e);
                    Logger.printException(() -> "Error at buildVariantDialogBox", e);
                    Utils.showToastShort(e.getMessage());
                }

            }
        });

        dialog.setOnDismissListener(onDismiss);
        dialog.setTitle(title);
        dialog.setNegativeButton(str("piko_close"), (d, which) -> d.dismiss());
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        Dialog dlg = dialog.getDialog();
        dlg.show();

    }

    private static void downloadDialogBox(Context context, MediaData mediaInfo, int position, DownloadMediaGroup group,
                                          DialogInterface.OnDismissListener onDismiss) throws Exception {
        MediaData currentMediaData = mediaInfo.getMediaAt(position);
        int filenameIndex = group.currentFilenameIndex(position);
        Boolean isCurrentMediaVideo = currentMediaData.isVideo();
        Boolean currentMediaHasAudio = currentMediaData.hasAudio();

        InstagramDialogBox dialog = new InstagramDialogBox(context);

        ArrayList<String> options = new ArrayList<>();
        options.add(str("piko_download_current_media"));
        options.add(str("piko_download_as_image"));
        if (currentMediaHasAudio) options.add(str("piko_download_audio"));
        options.add(str("piko_copy_media_link"));
        options.add(str("piko_image_variants"));
        if (isCurrentMediaVideo) {
            options.add(str("piko_video_variants"));
            options.add(str("piko_open_video_externally"));
        } else {
            options.add(str("piko_open_image_externally"));
        }

        if (group.size() > 1) {
            options.add(str("piko_select_media_download"));
            options.add(str("piko_download_all"));
        }

        CharSequence[] items = options.toArray(new CharSequence[0]);
        boolean[] childDialogShown = {false};

        DialogInterface.OnClickListener optionHandler = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int which) {
                try {
                    // Doing like this because options are dynamic.
                    String selectedOption = options.get(which);

                    if (selectedOption.equals(str("piko_download_current_media"))) {
                        downloadMedia(context, mediaInfo, position, filenameIndex, MediaType.ANY);

                    } else if (selectedOption.equals(str("piko_download_as_image"))) {
                        downloadMedia(context, mediaInfo, position, filenameIndex, MediaType.IMAGE);

                    } else if (selectedOption.equals(str("piko_copy_media_link"))) {
                        Utils.setClipboard(MediaUrls.forViewing(currentMediaData.getMediaLink()));
                        Utils.showToastShort(str("piko_copied_media_link"));

                    } else if (selectedOption.equals(str("piko_open_video_externally")) || selectedOption.equals(str("piko_open_image_externally"))) {
                        ActivityHook.handleUrlIntent(isCurrentMediaVideo, currentMediaData.getMediaLink());

                    } else if (selectedOption.equals(str("piko_select_media_download"))) {
                        DownloadSelectionSheet.show(context, group, onDismiss);
                        childDialogShown[0] = true;

                    } else if (selectedOption.equals(str("piko_download_all"))) {
                        downloadAllMedia(context, group);

                    } else if (selectedOption.equals(str("piko_download_audio"))) {
                        downloadMedia(context, mediaInfo, position, MediaType.AUDIO);

                    } else if (selectedOption.equals(str("piko_video_variants"))) {
                        buildVariantDialogBox(context, mediaInfo, position, filenameIndex, MediaType.VIDEO, onDismiss);
                        childDialogShown[0] = true;

                    } else if (selectedOption.equals(str("piko_image_variants"))) {
                        buildVariantDialogBox(context, mediaInfo, position, filenameIndex, MediaType.IMAGE, onDismiss);
                        childDialogShown[0] = true;

                    }
                } catch (Exception e) {
                    PikoUtils.logger(e);
                    Logger.printException(() -> "Error at downloadDialogBox", e);
                    Utils.showToastShort(e.getMessage());
                }
            }
        };

        // A replacement dialog owns the dismissal until the user finishes there.
        DialogInterface.OnDismissListener dismissListener = d -> {
            if (!childDialogShown[0] && onDismiss != null) onDismiss.onDismiss(d);
        };

        // Same card sheet as "More profile options" (blurred page behind it, slides up from the bottom).
        try {
            ArrayList<PikoMenuSheet.Option> cards = new ArrayList<>();
            for (int i = 0; i < options.size(); i++) {
                final int index = i;
                final String key = optionKey(options.get(i));
                cards.add(new PikoMenuSheet.Option(
                        optionHue(key), optionIcon(key), optionGlyph(key), options.get(i), null,
                        optionHasChevron(key),
                        () -> optionHandler.onClick(null, index)));
            }
            if (PikoMenuSheet.showOptions(context, str("piko_download_options"), cards, dismissListener)) {
                return;
            }
        } catch (Throwable t) {
            Logger.printException(() -> "Error at downloadDialogBox sheet", t);
        }

        // The sheet could not be shown: the plain dialog keeps every option reachable.
        dialog.addDialogMenuItems(items, optionHandler);
        dialog.setOnDismissListener(dismissListener);
        dialog.setTitle(str("piko_download_options"));
        dialog.setNegativeButton(str("piko_close"), (d, which) -> d.dismiss());
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        Dialog dlg = dialog.getDialog();
        dlg.show();
    }


    // ---------- Card look of the download options sheet ----------

    private static String optionKey(String label) {
        String[] keys = {
                "piko_download_current_media", "piko_download_as_image", "piko_download_audio",
                "piko_copy_media_link", "piko_image_variants", "piko_video_variants",
                "piko_open_video_externally", "piko_open_image_externally",
                "piko_select_media_download", "piko_download_all"
        };
        for (String key : keys) {
            if (label.equals(str(key))) return key;
        }
        return "";
    }

    private static int optionHue(String key) {
        switch (key) {
            case "piko_download_current_media": return 0xFF3B9EFF;
            case "piko_download_as_image": return 0xFFFF5C9E;
            case "piko_download_audio": return 0xFF8B6CFF;
            case "piko_copy_media_link": return 0xFF8CC63F;
            case "piko_image_variants":
            case "piko_video_variants": return 0xFFFFA33B;
            case "piko_open_video_externally":
            case "piko_open_image_externally": return 0xFF2EC4B6;
            case "piko_select_media_download": return 0xFF8B6CFF;
            case "piko_download_all": return 0xFFFF6B5E;
            default: return 0xFF3B9EFF;
        }
    }

    private static String optionIcon(String key) {
        switch (key) {
            case "piko_download_current_media":
            case "piko_download_all": return UI.DRAWABLE_DOWNLOAD_ICON;
            case "piko_download_as_image": return "instagram_photo_outline_24";
            case "piko_copy_media_link": return UI.DRAWABLE_LINK_ICON;
            case "piko_image_variants":
            case "piko_video_variants": return UI.DRAWABLE_COLLECTIONS_ICON;
            case "piko_select_media_download": return UI.DRAWABLE_STACK_ICON;
            default: return null;
        }
    }

    /** Text badge for the options that have no icon. */
    private static String optionGlyph(String key) {
        switch (key) {
            case "piko_download_audio": return "\u266A";
            case "piko_open_video_externally":
            case "piko_open_image_externally": return "\u2197";
            default: return optionIcon(key) == null ? "#" : null;
        }
    }

    /** The options that open another sheet get an arrow, like "View profile picture". */
    private static boolean optionHasChevron(String key) {
        return key.equals("piko_image_variants") || key.equals("piko_video_variants")
                || key.equals("piko_select_media_download");
    }

    public static void downloadPost(Context context,  UserSession userSession, Object mediaObject, int position) {
        try {
            position = position < 1 ? 0 : position;
            MediaData mediaInfo = new MediaData(mediaObject, userSession);
            if (directDownloadEnabled()) {
                downloadMedia(context, mediaInfo, position, MediaType.ANY);
            } else {
                downloadDialogBox(context, mediaInfo, position, DownloadMediaGroup.carousel(mediaInfo), null);
            }

        } catch (Exception e) {
            PikoUtils.logger(e);
            Logger.printException(() -> "Error at downloadPost", e);
        }
    }

    private static boolean directDownloadEnabled() {
        return SettingsStatus.downloadMedia && Pref.enableDirectDownload();
    }

    static boolean onPostDownloadLongClick(Context context, UserSession session, Object mediaObject, int position) {
        try {
            MediaData post = new MediaData(mediaObject, session);
            downloadAllOrShowOptions(context, post, Math.max(0, position), DownloadMediaGroup.carousel(post));
        } catch (Exception e) {
            Logger.printException(() -> "Error on download button long press", e);
            Utils.showToastShort(str("piko_download_failed_media"));
        }
        return true;
    }

    public static void showDownloadOptions(Context context, UserSession userSession, Object mediaObject, int position) {
        showDownloadOptions(context, userSession, mediaObject, position, null);
    }

    public static void showDownloadOptions(Context context, UserSession userSession, Object mediaObject, int position,
                                           DialogInterface.OnDismissListener onDismiss) {
        try {
            MediaData media = new MediaData(mediaObject, userSession);
            downloadDialogBox(context, media, Math.max(0, position), DownloadMediaGroup.carousel(media), onDismiss);
        } catch (Exception e) {
            Logger.printException(() -> "Could not show download options", e);
            Utils.showToastShort(str("piko_download_failed_media"));
            if (onDismiss != null) onDismiss.onDismiss(null);
        }
    }

    public static void showStoryDownloadOptions(Context context, UserSession session, Object media, Object reel,
                                                DialogInterface.OnDismissListener onDismiss) {
        try {
            MediaData current = new MediaData(media, session);
            downloadDialogBox(context, current, 0, DownloadMediaGroup.stories(current, reel, session), onDismiss);
        } catch (Exception e) {
            Logger.printException(() -> "Could not show story download options", e);
            Utils.showToastShort(str("piko_download_failed_media"));
            if (onDismiss != null) onDismiss.onDismiss(null);
        }
    }

    private static void downloadAllMedia(Context context, DownloadMediaGroup group) throws Exception {
        int total = group.size();
        List<Integer> indexes = new ArrayList<>(total);
        for (int index = 0; index < total; index++) indexes.add(index);
        downloadSelectedMedia(context, group, indexes);
    }

    private static void downloadAllOrShowOptions(Context context, MediaData current, int position, DownloadMediaGroup group) throws Exception {
        if (directDownloadEnabled() && group.size() > 1) {
            downloadAllMedia(context, group);
        } else {
            downloadDialogBox(context, current, position, group, null);
        }
    }

    static void downloadSelectedMedia(Context context, DownloadMediaGroup group, List<Integer> indexes) throws Exception {
        if (indexes.isEmpty()) return;
        if (!Utils.isNetworkConnected()) {
            Utils.showToastShort(str("piko_no_internet"));
            return;
        }
        int total = group.size();
        String username = group.username();
        String subFolder = getSubfolderName(username);
        List<DownloadRequest> requests = new ArrayList<>(indexes.size());
        for (int index : new TreeSet<>(indexes)) {
            if (index < 0 || index >= total) throw new IllegalArgumentException("Invalid media index");
            MediaData child = group.itemAt(index);
            MediaData root = group.carouselParent == null ? child : group.carouselParent;
            requests.add(buildMediaRequest(root, child, group.carouselParent == null ? 0 : index, index, MediaType.ANY, child.getMediaLink(),
                    subFolder, username + "_" + child.getDownloadFilename(MediaType.ANY), null));
        }
        getDownloadAllDownloader(context).enqueueBatch(requests);
    }

    // Position is set to -1 if we want to download all medias from the media info object.
    public static void downloadMedia(Context context, MediaData mediaInfo, int position, MediaType mediaType) throws Exception {
        downloadMedia(context, mediaInfo, position, position, mediaType);
    }

    private static void downloadMedia(Context context, MediaData mediaInfo, int position, int filenameIndex,
                                      MediaType mediaType) throws Exception {
        if(!Utils.isNetworkConnected()){
            Utils.showToastShort(str("piko_no_internet"));
            return;
        }
        MediaDownloader downloader = position == -1
                ? getDownloadAllDownloader(context)
                : new MediaDownloader(context);
        String username = mediaInfo.getUserData().getUsername();
        String subFolder = getSubfolderName(username);

        if (mediaType.equals(MediaType.AUDIO)) {
            AudioMediaInterface audioMedia = mediaInfo.getMediaAt(position).getAudioMedia();
            String audioUrl = audioMedia.getAudioUrl();
            String fileName = audioMedia.getDownloadName() + ".mp3";
            downloader.enqueue(new DownloadRequest(audioUrl, Constants.DEFAULT_AUDIO_FOLDER, fileName));

        } else if (position != -1) {
            MediaData mediaData = mediaInfo.getMediaAt(position);
            String mediaUrl;
            if (mediaType.equals(MediaType.IMAGE)) {
                mediaUrl = mediaData.getImageLink();
            } else {
                mediaUrl = mediaData.getMediaLink();
            }
            String fileName = username + "_" + mediaData.getDownloadFilename(mediaType);
            DownloadRequest request = buildMediaRequest(
                    mediaInfo,
                    mediaData,
                    position,
                    filenameIndex,
                    mediaType,
                    mediaUrl,
                    subFolder,
                    fileName,
                    null
            );
            if (!mediaType.equals(MediaType.IMAGE) || !mediaData.isVideo()
                    || !StorageUtils.checkStoragePermissions()) {
                downloader.enqueue(request);
                return;
            }
            MediaInterface cover = mediaData.getBestImage();
            int coverShortSide = cover == null ? 0 : cover.shortSide();
            // A picture lookup by shortcode addresses a post, never a carousel's child.
            boolean single = mediaInfo.getCarouselSize() == 1;
            String shortcode = mediaData.getShortcode();
            Utils.runOnBackgroundThread(() -> {
                MediaPicture picture = single ? MediaPicture.largerThan(shortcode, coverShortSide) : null;
                long coverPixels = 0;
                MediaInterface frameVideo = null;
                try {
                    coverPixels = picture != null ? (long) picture.width * picture.height
                            : cover == null ? 0 : (long) cover.getWidth() * cover.getHeight();
                    if (coverPixels > 0 && mediaData.isFirstFrameCover()) {
                        List<MediaInterface> videos = new ArrayList<>();
                        List<VideoData> progressive = mediaData.getVideoVariants();
                        if (progressive != null) videos.addAll(progressive);
                        videos.addAll(mediaData.getDashVideos());
                        long bestPixels = (long) (coverPixels * (1 + MediaData.ROUNDING_TOLERANCE));
                        for (MediaInterface video : videos) {
                            long pixels = (long) video.getWidth() * video.getHeight();
                            if (pixels > bestPixels && video.getUrl() != null) {
                                frameVideo = video;
                                bestPixels = pixels;
                            }
                        }
                    }
                } catch (Exception | LinkageError e) {
                    PikoUtils.logger(e);
                }
                MediaDownloader coverDownloader = frameVideo == null ? downloader
                        : firstFrameDownloader(context.getApplicationContext(), frameVideo, coverPixels);
                Utils.runOnMainThread(() -> {
                    if (picture != null) {
                        if (request.url != null && !request.url.trim().isEmpty()) {
                            request.fallbackSources.add(0, new DownloadRequest.Source(request.url, null));
                        }
                        request.url = picture.url;
                    }
                    coverDownloader.enqueue(request);
                });
            });

        } else if (position == -1) {
            downloadAllMedia(context, DownloadMediaGroup.carousel(mediaInfo));
        } else {
            Utils.showToastShort("There is nothing to download");
        }

    }

    private static MediaDownloader firstFrameDownloader(Context context, MediaInterface video, long coverPixels) {
        return new MediaDownloader(context) {
            private boolean attempted;

            @Override
            protected void download(String url, OutputStream output, Notification.Builder builder, int notificationId)
                    throws IOException {
                if (attempted) {
                    super.download(url, output, builder, notificationId);
                    return;
                }
                attempted = true;
                File source = null;
                File picture = null;
                Bitmap frame = null;
                boolean extracted = false;
                try {
                    try {
                        source = File.createTempFile("piko-cover-", ".mp4", context.getCacheDir());
                        picture = File.createTempFile("piko-cover-", ".jpg", context.getCacheDir());
                        try (OutputStream cached = new FileOutputStream(source)) {
                            super.download(video.getUrl(), cached, builder, notificationId);
                        }
                        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                        try {
                            retriever.setDataSource(source.getAbsolutePath());
                            frame = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST);
                        } finally {
                            retriever.release();
                        }
                        if (frame != null && (long) frame.getWidth() * frame.getHeight() > coverPixels) {
                            try (OutputStream jpeg = new FileOutputStream(picture)) {
                                extracted = frame.compress(Bitmap.CompressFormat.JPEG, 95, jpeg);
                            }
                        }
                    } catch (Exception | LinkageError | OutOfMemoryError e) {
                        extracted = false;
                        PikoUtils.logger(e);
                    }
                    if (extracted) {
                        // Finish encoding before writing the document so extraction failures leave it untouched.
                        try (FileInputStream jpeg = new FileInputStream(picture)) {
                            byte[] buffer = new byte[8192];
                            int count;
                            while ((count = jpeg.read(buffer)) != -1) output.write(buffer, 0, count);
                        }
                    } else {
                        super.download(url, output, builder, notificationId);
                    }
                } finally {
                    if (frame != null) frame.recycle();
                    if (source != null) source.delete();
                    if (picture != null) picture.delete();
                }
            }
        };
    }

    /**
     * The request for one media, as {@code variant} when one was chosen. A video with none chosen
     * downloads as the sharpest DASH rendition, with its audio merged in, when that is sharper
     * than the progressive file. Automatic downloads retry the same resolution before the
     * existing progressive fallback; a chosen resolution only retries its own renditions.
     */
    private static DownloadRequest buildMediaRequest(
            MediaData rootMediaData,
            MediaData childMediaData,
            int postPosition,
            int filenameIndex,
            MediaType mediaType,
            String mediaUrl,
            String subFolder,
            String fallbackFileName,
            MediaInterface variant
    ) throws Exception {
        boolean isVideo = mediaType.equals(MediaType.VIDEO)
                || (mediaType.equals(MediaType.ANY) && childMediaData.isVideo());
        String fileName = fallbackFileName;
        String progressiveUrl = mediaUrl;
        String audioUrl = variant == null ? null : variant.getAudioUrl();

        String variantTag = variant == null ? null : variant.getVariantTag();
        DashVideoData dashVideo = variant instanceof DashVideoData
                ? (DashVideoData) variant
                : isVideo && variant == null && Pref.preferDashFormat()
                ? childMediaData.getSharperDashVideo()
                : null;
        if (dashVideo != null) {
            mediaUrl = dashVideo.getUrl();
            audioUrl = dashVideo.getAudioUrl();
        }

        try {
            String username = rootMediaData.getUserData().getUsername();
            Long takenAtSeconds = rootMediaData.getTakenAtSeconds();
            Long uploadTimestampMillis = takenAtSeconds == null
                    ? null
                    : takenAtSeconds * 1000L;
            String variantSuffix = variantTag == null || variantTag.trim().isEmpty()
                    ? ""
                    : variantTag;
            DownloadFileNameFormatter.Values fileNameValues =
                    new DownloadFileNameFormatter.Values(
                            username,
                            childMediaData.getMediaPkId(),
                            rootMediaData.getShortcode(),
                            uploadTimestampMillis,
                            isVideo ? "video" : "image",
                            filenameIndex,
                            variantSuffix
                    );
            fileName = DownloadFileNameFormatter.format(
                    Pref.downloadFileNameTemplate(),
                    fileNameValues,
                    isVideo ? ".mp4" : ".jpg",
                    ZoneId.systemDefault()
            );
        } catch (Exception | LinkageError fileNameException) {
            PikoUtils.logger(fileNameException);
            Logger.printException(
                    () -> "Could not format download filename",
                    fileNameException
            );
        }

        DownloadRequest request = new DownloadRequest(mediaUrl, subFolder, fileName);
        if (variant instanceof VideoResolution) {
            List<VideoVariant> candidates = ((VideoResolution) variant).getCandidates();
            for (int i = 1; i < candidates.size(); i++) {
                try {
                    VideoVariant candidate = candidates.get(i);
                    String url = candidate.getUrl();
                    if (url == null || url.trim().isEmpty()) continue;
                    request.fallbackSources.add(new DownloadRequest.Source(url, candidate.getAudioUrl()));
                } catch (Exception | LinkageError ignored) {
                    // A failed optional candidate must not prevent the selected download.
                }
            }
        } else if (variant instanceof ImageResolution) {
            List<String> urls = ((ImageResolution) variant).getCandidateUrls();
            for (int i = 1; i < urls.size(); i++) {
                request.fallbackSources.add(new DownloadRequest.Source(urls.get(i), null));
            }
        }
        MediaInterface originalImage = null;
        if (!isVideo && variant == null && mediaType == MediaType.IMAGE && childMediaData.isVideo()) {
            originalImage = childMediaData.getBestOriginalImage();
            if (originalImage != null && !originalImage.getUrl().equals(mediaUrl)) request.fallbackUrl = originalImage.getUrl();
        }
        request.audioUrl = audioUrl;
        request.audioToAacLc = isVideo && Pref.dashAudioAacLc();
        if (variant == null && dashVideo != null
                && progressiveUrl != null && !progressiveUrl.trim().isEmpty()) {
            request.fallbackUrl = progressiveUrl;
        }
        if (isVideo && variant == null) addSameResolutionFallbacks(request, childMediaData);
        if (!isVideo && variant == null && (mediaType == MediaType.ANY || mediaType == MediaType.IMAGE)) {
            try {
                MediaInterface image = childMediaData.getBestImage();
                // Only use dimensions belonging to the URL already selected by the existing path.
                if (image != null && request.url != null && request.url.equals(image.getUrl())) {
                    addImageFallbacks(request, childMediaData, image.getWidth(), image.getHeight());
                }
            } catch (Exception | LinkageError ignored) {
                // Optional alternatives must not prevent the original image from being saved.
            }
            addFinalImageFallbacks(request, childMediaData, originalImage);
        }
        if (!isVideo || !Pref.embedDownloadMetadata()) {
            return request;
        }

        try {
            String username = rootMediaData.getUserData().getUsername();
            Long takenAtSeconds = rootMediaData.getTakenAtSeconds();
            Long uploadTimestampMillis = takenAtSeconds == null
                    ? null
                    : takenAtSeconds * 1000L;
            request.metadata = new DownloadMetadata(
                    rootMediaData.getDescriptionText(),
                    Links.generatePostLink(rootMediaData, postPosition),
                    username,
                    uploadTimestampMillis
            );
            return request;
        } catch (Exception | LinkageError metadataException) {
            PikoUtils.logger(metadataException);
            Logger.printException(
                    () -> "Could not collect download metadata",
                    metadataException
            );
            return request;
        }
    }

    private static void addFinalImageFallbacks(DownloadRequest request, MediaData mediaData,
                                              MediaInterface image) {
        if (image == null || request.fallbackUrl == null) return;
        try {
            if (!request.fallbackUrl.equals(image.getUrl())) return;
            DownloadRequest fallback = new DownloadRequest(request.fallbackUrl, request.subFolder, request.fileName);
            addImageFallbacks(fallback, mediaData, image.getWidth(), image.getHeight());
            Set<String> seen = new HashSet<>();
            seen.add(request.url);
            seen.add(request.fallbackUrl);
            for (DownloadRequest.Source source : request.fallbackSources) seen.add(source.url);
            fallback.fallbackSources.removeIf(source -> !seen.add(source.url));
            if (fallback.fallbackSources.isEmpty()) return;
            // Sources run before fallbackUrl, so move the original cover ahead of its new peers.
            request.fallbackSources.add(new DownloadRequest.Source(request.fallbackUrl, null));
            request.fallbackSources.addAll(fallback.fallbackSources);
            request.fallbackUrl = null;
        } catch (Exception | LinkageError ignored) {
            // Keep the legacy fallback if its dimensions or optional peers cannot be read.
        }
    }

    private static void addImageFallbacks(DownloadRequest request, MediaData mediaData,
                                          Integer width, Integer height) {
        if (request.url != null && request.url.equals(request.fallbackUrl)) request.fallbackUrl = null;
        if (width == null || height == null || width <= 0 || height <= 0) return;
        try {
            Set<String> seen = new HashSet<>();
            seen.add(request.url);
            seen.add(request.fallbackUrl);
            for (ImageResolution resolution : ImageResolution.group(mediaData.getImageVariants())) {
                if (!width.equals(resolution.getWidth()) || !height.equals(resolution.getHeight())) continue;
                for (String url : resolution.getCandidateUrls()) {
                    if (seen.add(url)) request.fallbackSources.add(new DownloadRequest.Source(url, null));
                }
                break;
            }
        } catch (Exception | LinkageError ignored) {
            // Keep the initial image and legacy fallback when alternatives cannot be read.
        }
    }

    private static void addSameResolutionFallbacks(DownloadRequest request, MediaData mediaData) {
        try {
            List<VideoVariant> videos = new ArrayList<>();
            if (Pref.preferDashFormat()) videos.addAll(mediaData.getDashVideos());
            List<VideoData> progressive = mediaData.getVideoVariants();
            if (progressive != null) videos.addAll(progressive);

            List<String> primary = Arrays.asList(request.url, request.audioUrl);
            for (VideoResolution resolution : VideoResolution.group(videos)) {
                if (resolution.shortSide() <= 0) continue;
                List<DownloadRequest.Source> sources = new ArrayList<>();
                boolean containsPrimary = false;
                for (VideoVariant candidate : resolution.getCandidates()) {
                    try {
                        String url = candidate.getUrl();
                        String audio = candidate.getAudioUrl();
                        if (url == null || url.trim().isEmpty()) continue;
                        if (primary.equals(Arrays.asList(url, audio))) containsPrimary = true;
                        sources.add(new DownloadRequest.Source(url, audio));
                    } catch (Exception | LinkageError ignored) {
                        // A failed optional candidate must not prevent the original download.
                    }
                }
                if (!containsPrimary) continue;

                Set<List<String>> seen = new HashSet<>();
                seen.add(primary);
                // Keep the legacy complete-file fallback last, even if it appears in this group.
                if (request.fallbackUrl != null) seen.add(Arrays.asList(request.fallbackUrl, null));
                for (DownloadRequest.Source source : sources) {
                    if (seen.add(Arrays.asList(source.url, source.audioUrl))) request.fallbackSources.add(source);
                }
                return;
            }
        } catch (Exception | LinkageError e) {
            PikoUtils.logger(e);
        }
    }


    public static void downloadMediaUrl(Context context, String mediaUrl, String subFolder, String fileName) throws Exception {
        enqueueDownload(context, new DownloadRequest(mediaUrl, subFolder, fileName));
    }

    private static final Object FEED_DOWNLOAD_BUTTON_TAG = new Object();
    private static final String MEDIA_CLASS_NAME = "com.instagram.feed.media.Media";

    /** Shared by the injected Litho component and the view holder hook. */
    public static boolean isFeedDownloadButtonEnabled() {
        return Boolean.TRUE.equals(SharedPref.getBooleanPref(Settings.ENABLE_DOWNLOAD))
                && Boolean.TRUE.equals(SharedPref.getBooleanPref(Settings.FEED_DOWNLOAD_BUTTON));
    }

    public static String feedDownloadButtonDescription() {
        return str("piko_download_current_media");
    }

    // Placeholders the patch rewrites inside `currentMediaIndex` with the live-index field names.
    static final String FEED_VIEW_STATE_FIELD = "feedViewStateField";
    static final String FEED_CURRENT_MEDIA_FIELD = "feedCurrentMediaField";

    /** Adds a download button beside the save button; called from the patched row binder on every bind. */
    public static void addFeedDownloadButton(
            View rootView, Object media, UserSession userSession, Object mediaState) {
        try {
            if (rootView == null || media == null) return;
            if (!isFeedDownloadButtonEnabled()) {
                removeFeedDownloadButton(rootView);
                return;
            }

            Context context = rootView.getContext();
            int saveButtonId = ResourceUtils.getIdentifier(context, ResourceType.ID, "row_feed_button_save");
            View saveButton = saveButtonId == 0 ? null : rootView.findViewById(saveButtonId);
            if (saveButton == null || !(saveButton.getParent() instanceof ViewGroup)) return;

            // Litho hosts reject added views; their button is built into the component instead.
            ViewGroup buttonGroup = (ViewGroup) saveButton.getParent();
            if (buttonGroup.getClass().getName().startsWith("com.facebook.litho.")) return;

            ImageView button = buttonGroup.findViewWithTag(FEED_DOWNLOAD_BUTTON_TAG);
            if (button == null) {
                button = createFeedDownloadButton(context, saveButton, buttonGroup);
            }
            button.setOnClickListener(
                    v -> downloadPost(context, userSession, media, currentMediaIndex(mediaState)));
            button.setOnLongClickListener(
                    v -> onPostDownloadLongClick(context, userSession, media, currentMediaIndex(mediaState)));
        } catch (Exception e) {
            Logger.printException(() -> "addFeedDownloadButton failure", e);
        }
    }

    /** Reads the live carousel index at click time, so the download follows a swipe. */
    static int currentMediaIndex(Object mediaState) {
        if (mediaState == null) return 0;
        try {
            Object viewState = new Entity(mediaState).getField(FEED_VIEW_STATE_FIELD);
            if (viewState == null) return 0;
            Object index = new Entity(viewState).getField(FEED_CURRENT_MEDIA_FIELD);
            if (index instanceof Integer) return (Integer) index;
        } catch (Exception e) {
            Logger.printException(() -> "Could not read the current media index", e);
        }
        return 0;
    }

    /** Unwraps a feed row state to the single `Media` it holds; anything else is returned as is. */
    static Object extractMedia(Object source) {
        if (source == null || MEDIA_CLASS_NAME.equals(source.getClass().getName())) return source;
        try {
            for (Field field : source.getClass().getDeclaredFields()) {
                if (!MEDIA_CLASS_NAME.equals(field.getType().getName())) continue;
                field.setAccessible(true);
                Object media = field.get(source);
                if (media != null) return media;
            }
        } catch (Exception e) {
            Logger.printException(() -> "Could not extract the media from the feed row state", e);
        }
        return source;
    }

    /** Drops the button on rebind so turning the toggle off takes effect without recreating the row. */
    private static void removeFeedDownloadButton(View rootView) {
        View existing = rootView.findViewWithTag(FEED_DOWNLOAD_BUTTON_TAG);
        if (existing == null) return;
        ViewParent parent = existing.getParent();
        if (parent instanceof ViewGroup) ((ViewGroup) parent).removeView(existing);
    }

    private static ImageView createFeedDownloadButton(Context context, View saveButton, ViewGroup buttonGroup) {
        ImageView button = new ImageView(context);
        button.setTag(FEED_DOWNLOAD_BUTTON_TAG);
        button.setContentDescription(feedDownloadButtonDescription());
        button.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        applyFeedDownloadIcon(button, context);
        button.setPadding(
                saveButton.getPaddingLeft(),
                saveButton.getPaddingTop(),
                saveButton.getPaddingRight(),
                saveButton.getPaddingBottom());
        buttonGroup.addView(button, buttonGroup.indexOfChild(saveButton), cloneLayoutParams(saveButton));
        return button;
    }

    /** Copies the save button's slot so the download icon matches its size and spacing. */
    private static ViewGroup.LayoutParams cloneLayoutParams(View saveButton) {
        ViewGroup.LayoutParams saveParams = saveButton.getLayoutParams();
        if (saveParams instanceof LinearLayout.LayoutParams) {
            return new LinearLayout.LayoutParams((LinearLayout.LayoutParams) saveParams);
        }
        if (saveParams instanceof ViewGroup.MarginLayoutParams) {
            return new ViewGroup.MarginLayoutParams((ViewGroup.MarginLayoutParams) saveParams);
        }
        if (saveParams != null) {
            return new ViewGroup.LayoutParams(saveParams.width, saveParams.height);
        }
        return new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    /** Uses the row context: the application context cannot resolve activity scoped theme attributes. */
    private static void applyFeedDownloadIcon(ImageView button, Context context) {
        int drawableId = ResourceUtils.getIdentifier(context, ResourceType.DRAWABLE, UI.DRAWABLE_DOWNLOAD_ICON);
        if (drawableId == 0) return;
        button.setImageDrawable(context.getDrawable(drawableId));

        int attrId = ResourceUtils.getAttrIdentifier("igds_color_primary_icon");
        TypedValue typedValue = new TypedValue();
        if (attrId != 0
                && context.getTheme().resolveAttribute(attrId, typedValue, true)
                && typedValue.resourceId != 0) {
            button.setColorFilter(context.getColor(typedValue.resourceId));
        }
    }

    private static final Object STORY_DOWNLOAD_BUTTON_TAG = new Object();

    public static void addStoryDownloadButton(View buttonsContainer, Object media, UserSession userSession, Object reel) {
        try {
            if (!(buttonsContainer instanceof ViewGroup)) return;
            ViewGroup row = (ViewGroup) buttonsContainer;
            ImageView button = row.findViewWithTag(STORY_DOWNLOAD_BUTTON_TAG);
            if (media == null || !SettingsStatus.storyDownloadButton || !Pref.enableDownload()
                    || !SharedPref.getBooleanPref(Settings.STORY_DOWNLOAD_BUTTON)) {
                if (button != null) row.removeView(button);
                return;
            }

            if (button == null) {
                button = createStoryDownloadButton(row);
                if (button == null) return;
            }
            // Reset before the native binder applies any story-specific tint.
            button.getDrawable().setTint(Color.WHITE);
            button.setOnClickListener(v -> downloadStory(v, userSession, media, reel, false));
            button.setOnLongClickListener(v -> {
                downloadStory(v, userSession, media, reel, true);
                return true;
            });
        } catch (Exception e) {
            Logger.printException(() -> "addStoryDownloadButton failure", e);
        }
    }

    private static ImageView createStoryDownloadButton(ViewGroup row) {
        Context context = row.getContext();
        int likeId = ResourceUtils.getIdentifier(context, ResourceType.ID, "toolbar_like_container");
        View model = likeId == 0 ? null : row.findViewById(likeId);
        if (model == null || model.getParent() != row) {
            model = row.getChildCount() == 0 ? null : row.getChildAt(0);
        }
        if (model == null) return null;
        int drawableId = ResourceUtils.getIdentifier(context, ResourceType.DRAWABLE, UI.DRAWABLE_DOWNLOAD_ICON);
        if (drawableId == 0) return null;

        ImageView button = new ImageView(context);
        button.setTag(STORY_DOWNLOAD_BUTTON_TAG);
        button.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        button.setImageDrawable(context.getDrawable(drawableId).mutate());
        button.setContentDescription(str("piko_download_current_media"));
        button.setPadding(model.getPaddingLeft(), model.getPaddingTop(), model.getPaddingRight(), model.getPaddingBottom());
        row.addView(button, row.indexOfChild(model), cloneLayoutParams(model));
        return button;
    }

    private static void downloadStory(View anchor, UserSession userSession, Object media, Object reel, boolean longPress) {
        try {
            Activity activity = storyActivity(anchor);
            MediaData current = new MediaData(media, userSession);
            if (!longPress && directDownloadEnabled()) {
                String template = Pref.downloadFileNameTemplate();
                int filenameIndex = template != null && template.contains(DownloadFileNameFormatter.Token.CAROUSEL_INDEX.placeholder())
                        ? DownloadMediaGroup.stories(current, reel, userSession).currentFilenameIndex(0)
                        : 0;
                downloadMedia(activity, current, 0, filenameIndex, MediaType.ANY);
                return;
            }
            DownloadMediaGroup group = DownloadMediaGroup.stories(current, reel, userSession);
            if (longPress) {
                downloadAllOrShowOptions(activity, current, 0, group);
            } else {
                downloadDialogBox(activity, current, 0, group, null);
            }
        } catch (Exception e) {
            Logger.printException(() -> "Error at story download", e);
            Utils.showToastShort(str("piko_download_failed_media"));
        }
    }

    // The toolbar uses an application context wrapper; its ancestors carry the hosting Activity.
    private static Activity storyActivity(View view) {
        for (View current = view; current != null; ) {
            Context context = current.getContext();
            while (context instanceof ContextWrapper) {
                if (context instanceof Activity) return (Activity) context;
                Context base = ((ContextWrapper) context).getBaseContext();
                if (base == context) break;
                context = base;
            }
            ViewParent parent = current.getParent();
            current = parent instanceof View ? (View) parent : null;
        }
        throw new IllegalStateException("No activity found above the story download button");
    }

    private static void enqueueDownload(Context context, DownloadRequest request) {
        if(!Utils.isNetworkConnected()){
            Utils.showToastShort(str("piko_no_internet"));
            return;
        }
        MediaDownloader downloader = new MediaDownloader(context);
        downloader.enqueue(request);
    }

    public static void externalDownloader(Object mediaObject, int currentMediaIndex){
        try {
            String packageName = Pref.externalDownloaderPackageName();
            packageName = packageName == null ? "" : packageName.trim();
            if(packageName.isEmpty()){
                PikoUtils.toast(str("piko_external_downloader_package_name_not_set"));
                return;
            }
            if(!PikoUtils.isAppInstalledAndEnabled(packageName)){
                PikoUtils.toast(str("piko_external_downloader_package_name_not_found"));
                return;
            }
            String link = Links.generatePostLink(mediaObject, currentMediaIndex);
            PikoUtils.shareTextToPackageName(link, packageName);
        } catch (Exception e){
            PikoUtils.logger(e);
            Logger.printException(() -> "Error at externalDownloader", e);
        }
    }
}
