/*
 * Copyright (C) 2026 piko <https://github.com/crimera/piko>
 *
 * See the included NOTICE file for GPLv3 §7(b) terms that apply to this code.
 */

package app.morphe.extension.instagram.patches.userprofile;

import android.view.ViewGroup;
import java.util.Set;

import app.morphe.extension.shared.Logger;
import app.morphe.extension.shared.ui.Dim;
import app.morphe.extension.instagram.entity.ProfileInfo;
import app.morphe.extension.instagram.utils.Pref;
import app.morphe.extension.instagram.constants.UI;
import app.morphe.extension.instagram.constants.Constants;
import app.morphe.extension.instagram.patches.userprofile.ProfileMoreOption;

public class UserProfileButton {
    private static boolean isSettingsInActionBar;
    private static Set userProfileABPref;

    static {
        userProfileABPref = Pref.userProfileActionBarButtons();
        if(userProfileABPref.contains(Constants.AB_SETTINGS_ICON)){
            isSettingsInActionBar = true;
        } else if(Pref.mainFeedActionBarButtons().contains(Constants.AB_SETTINGS_ICON)){
            isSettingsInActionBar = true;
        } else if(Pref.chatActionBarButtons().contains(Constants.AB_SETTINGS_ICON)){
            isSettingsInActionBar = true;
        } else if(Pref.inboxActionBarButtons().contains(Constants.AB_SETTINGS_ICON)){
            isSettingsInActionBar = true;
        } else{
            isSettingsInActionBar = false;
        }
    }

    public static void addButtons(ViewGroup viewGroup, Object object) {
        try {
            ProfileInfo profileInfo = new ProfileInfo(object);
            Boolean isSelfProfile = profileInfo.isSelfProfile();

            // With "open Piko settings by long-pressing Home" on, no Piko settings button is shown anywhere.
            boolean showSettings = !isSettingsInActionBar && isSelfProfile
                    && !Pref.homeLongPressPikoSettings();
            boolean showProfileOptions = !userProfileABPref.contains(Constants.AB_PROFILE_INFO_ICON)
                    && Pref.isMoreOptionsOnProfilePatched();

            if (showSettings){
                UI.pikoSettingsButton(viewGroup, showProfileOptions ? 0 : Dim.dp8);
            }
            if(showProfileOptions){
                ProfileMoreOption.addProfileMoreOptionsButton(viewGroup, profileInfo);
            }
        } catch (Exception e) {
            Logger.printException(() -> "Failed to add piko button: ", e);
        }

    }
}

