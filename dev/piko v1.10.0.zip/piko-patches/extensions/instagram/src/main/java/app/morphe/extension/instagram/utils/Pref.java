/*
 * Copyright (C) 2026 piko <https://github.com/crimera/piko>
 *
 * See the included NOTICE file for GPLv3 §7(b) terms that apply to this code.
 */


package app.morphe.extension.instagram.utils;

import java.util.Set;
import java.util.HashSet;
import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import app.morphe.extension.shared.Utils;
import app.morphe.extension.instagram.settings.BooleanSetting;
import app.morphe.extension.instagram.settings.StringSetting;

import app.morphe.extension.instagram.settings.Settings;
import static app.morphe.extension.instagram.settings.RestartPolicy.NOT_REQUIRED;
import app.morphe.extension.instagram.settings.SettingsStatus;
import app.morphe.extension.instagram.constants.Constants;
import app.morphe.extension.instagram.patches.focusLock.FocusLock;
import app.morphe.extension.instagram.patches.navigation.FloatingNavSize;
import app.morphe.extension.instagram.patches.download.ReelDownload;

import app.morphe.extension.crimera.sharedPreference.SharedPref;
import app.morphe.extension.shared.MarkChatAsReadScope;

@SuppressWarnings("unused")
public class Pref {
    // Instagram picks the variant closest to the target plus 5%, so a target this large always
    // selects the widest; half of MAX_VALUE keeps that 5% from overflowing.
    private static final int WIDEST_VARIANT_TARGET = Integer.MAX_VALUE / 2;
    // Instagram's full-screen views cap the width they request an image variant for at this.
    private static final int FULL_SCREEN_WIDTH_CAP = 1080;
    // Instagram sizes image variants by the User-Agent's shorter screen side. At 2560 posts get
    // their originals and grid tiles 750 px variants; from 2880 grid tiles get 1080 px.
    private static final int USER_AGENT_SCREEN_SIZE = 2560;

    private static String removeLineBreaks(String value) {
        return value.replace("\r", "").replace("\n", "");
    }

    public static boolean clearAllPreferences() {
        // Resetting settings would silently drop an active Focus Lock.
        if (FocusLock.isActive()) return false;
        return SharedPref.clearAll();
    }
    
    public static boolean pikoDebug() {
        return SharedPref.getBooleanPref(Settings.PIKO_DEBUG);
    }

    public static boolean firstTimePiko() {
        return SharedPref.getBooleanPref(Settings.FIRST_TIME_PIKO);
    }
    public static boolean setFirstTimePiko(boolean bool) {
        return SharedPref.setBooleanPref(Settings.FIRST_TIME_PIKO.key,bool);
    }

    public static boolean unlockPlusBenefits() {
        return SharedPref.getBooleanPref(Settings.UNLOCK_PLUS_BENEFITS);
    }

    public static boolean disableAds() {
        return SharedPref.getBooleanPref(Settings.DISABLE_ADS);
    }

    public static boolean hideSuggestedContent() {
        return SharedPref.getBooleanPref(Settings.HIDE_SUGGESTED_CONTENT);
    }

    public static boolean saveDeletedMessages() {
        return SharedPref.getBooleanPref(Settings.SAVE_DELETED_MESSAGES);
    }

    public static boolean openLinksExternally() {
        return SharedPref.getBooleanPref(Settings.OPEN_LINKS_EXTERNALLY);
    }

    public static boolean sanitizeShareLinks() {
        return SharedPref.getBooleanPref(Settings.SANITIZE_SHARE_LINKS);
    }

    public static String customSharingDomain() {
        return removeLineBreaks(SharedPref.getStringPref(Settings.CUSTOM_SHARING_DOMAIN));
    }

    public static boolean getTurnOnAllGhostModes() {
        return SharedPref.getBooleanPref(Settings.TURN_ON_ALL_GHOST_MODES);
    }

    public static boolean setTurnOnAllGhostModes(boolean bool) {
        return SharedPref.setBooleanPref(Settings.TURN_ON_ALL_GHOST_MODES.key,bool);
    }

    public static boolean isMoreOptionsOnProfilePatched(){
        return SettingsStatus.moreOptionsOnProfile;
    }

    public static boolean viewStoriesAnonymously() {
        return (SharedPref.getBooleanPref(Settings.VIEW_STORIES_ANONYMOUSLY) && SettingsStatus.viewStoriesAnonymously) || Pref.getTurnOnAllGhostModes();
    }

    public static boolean viewLiveAnonymously() {
        return (SharedPref.getBooleanPref(Settings.VIEW_LIVE_ANONYMOUSLY) && SettingsStatus.viewLiveAnonymously) || Pref.getTurnOnAllGhostModes();
    }

    public static boolean disableScreenshotDetection() {
        return SharedPref.getBooleanPref(Settings.DISABLE_SCREENSHOT_DETECTION) || Pref.getTurnOnAllGhostModes();
    }

    public static boolean disableTypingStatus() {
        return SharedPref.getBooleanPref(Settings.DISABLE_TYPING_STATUS) || Pref.getTurnOnAllGhostModes();
    }

    public static boolean enableMarkChatAsReadOption() {
        return SharedPref.getBooleanPref(Settings.ENABLE_MARK_CHAT_AS_READ) && SettingsStatus.markChatAsRead;
    }

    public static boolean markAsReadAfterReply() {
        return SharedPref.getBooleanPref(Settings.MARK_AS_READ_AFTER_REPLY) && SettingsStatus.markAsReadAfterReply;
    }

    // Return false = call the message seen api.
    // Return true = blocks the message seen api.
    public static boolean viewDmAnonymously() {
        return shouldBlockDmSeen(
                SharedPref.getBooleanPref(Settings.VIEW_DM_ANONYMOUSLY),
                Pref.getTurnOnAllGhostModes(),
                enableMarkChatAsReadOption() || markAsReadAfterReply()
        );
    }

    static boolean shouldBlockDmSeen(
            boolean viewDmAnonymously,
            boolean allGhostModes,
            boolean explicitReadEnabled
    ) {
        if (explicitReadEnabled && MarkChatAsReadScope.isActive()) {
            return false;
        }
        return viewDmAnonymously || allGhostModes;
    }

    public static boolean resumeReelsAfterScrolling() {
        return SharedPref.getBooleanPref(Settings.RESUME_REELS_AFTER_SCROLLING);
    }

    public static boolean disableVideoAutoplay() {
        return SharedPref.getBooleanPref(Settings.DISABLE_VIDEO_AUTOPLAY);
    }

    public
    static boolean disableStories() {
        return SharedPref.getBooleanPref(Settings.DISABLE_STORIES);
    }

    public static boolean disableHighlights() {
        return SharedPref.getBooleanPref(Settings.DISABLE_HIGHLIGHTS);
    }

    public static boolean disableExplore() {
        return SharedPref.getBooleanPref(Settings.DISABLE_EXPLORE);
    }

    public static boolean disableComments() {
        return SharedPref.getBooleanPref(Settings.DISABLE_COMMENTS);
    }

    public static boolean hideCommentButtons() {
        return lockable(Settings.DISABLE_COMMENTS) && SettingsStatus.disableComments;
    }

    public static boolean limitFollowingFeed() {
        return SharedPref.getBooleanPref(Settings.LIMIT_FOLLOWING_FEED);
    }

    public static boolean hideFeedPosts() {
        return SharedPref.getBooleanPref(Settings.HIDE_FEED_POSTS) && SettingsStatus.hideFeedPosts;
    }

    public static boolean hideStoriesTray() {
        return lockable(Settings.HIDE_STORIES_TRAY) && SettingsStatus.hideStoriesTray;
    }

    public static boolean hideHiddenRequests() {
        return lockable(Settings.HIDE_HIDDEN_REQUESTS) && SettingsStatus.hideHiddenRequests;
    }

    public static boolean hideNotesTray() {
        return lockable(Settings.HIDE_NOTES_TRAY) && SettingsStatus.hideNotesTray;
    }

    public static boolean disableReelsScrolling() {
        return lockable(Settings.DISABLE_REELS_SCROLLING) && SettingsStatus.disableReelsScrolling;
    }

    public static boolean disableSwipeToCreate() {
        return lockable(Settings.DISABLE_SWIPE_TO_CREATE) && SettingsStatus.disableSwipeToCreate;
    }

    /**
     * A switch that Focus Lock can hold on: the stored value, or true while the lock forces it.
     *
     * Read per call rather than cached, so a lock that expires releases the setting without
     * needing a restart.
     */
    private static boolean lockable(BooleanSetting setting) {
        return SharedPref.getBooleanPref(setting) || FocusLock.isForced(setting);
    }

    /** Whether the target behind {@code key} is one of the things Focus Lock holds on. */
    public static boolean focusLockSelected(String key) {
        return SharedPref.getBooleanPref(focusLockSelection(key));
    }

    public static BooleanSetting focusLockSelection(String key) {
        return new BooleanSetting(FocusLock.SELECTION_PREFIX + key, false, NOT_REQUIRED);
    }

    public static String focusLockDurationMinutes() {
        return SharedPref.getStringPref(Settings.FOCUS_LOCK_DURATION_MINUTES);
    }

    public static boolean setFocusLockDurationMinutes(String value) {
        return SharedPref.setStringPref(Settings.FOCUS_LOCK_DURATION_MINUTES.key, value);
    }

    /** Keys of the first released Focus Lock, read so a lock it wrote still counts. */
    public static boolean legacyFocusLockBlockReels() {
        return SharedPref.getBooleanPref(new BooleanSetting("focus_lock_block_reels", false, NOT_REQUIRED));
    }

    public static boolean legacyFocusLockBlockExplore() {
        return SharedPref.getBooleanPref(new BooleanSetting("focus_lock_block_explore", false, NOT_REQUIRED));
    }

    public static String focusLockFormat() {
        return SharedPref.getStringPref(Settings.FOCUS_LOCK_FORMAT);
    }

    public static boolean setFocusLockFormat(String value) {
        return SharedPref.setStringPref(Settings.FOCUS_LOCK_FORMAT.key, value);
    }

    public static String focusLockUntil() {
        return SharedPref.getStringPref(Settings.FOCUS_LOCK_UNTIL);
    }

    public static boolean setFocusLockUntil(String value) {
        return SharedPref.setStringPref(Settings.FOCUS_LOCK_UNTIL.key, value);
    }

    public static String focusLockUnlockRequestedAt() {
        return SharedPref.getStringPref(Settings.FOCUS_LOCK_UNLOCK_REQUESTED_AT);
    }

    public static boolean setFocusLockUnlockRequestedAt(String value) {
        return SharedPref.setStringPref(Settings.FOCUS_LOCK_UNLOCK_REQUESTED_AT.key, value);
    }

    public static boolean ephemeralMediaCaption() {
        return SharedPref.getBooleanPref(Settings.EPHEMERAL_MEDIA_CAPTION);
    }

    public static boolean disableDisappearingMessagesGesture() {
        return SharedPref.getBooleanPref(Settings.DISABLE_DISAPPEARING_MESSAGES_GESTURE) && SettingsStatus.disableDisappearingMessagesGesture;
    }

    public static boolean makeEphemeralMediaPermanent() {
        return SharedPref.getBooleanPref(Settings.UNLIMITED_REPLAYS) && SettingsStatus.unlimitedReplaysOnEphemeralMedia;
    }

    public static boolean hideLikes() {
        return SharedPref.getBooleanPref(Settings.HIDE_LIKES) && SettingsStatus.hideLikes;
    }

    public static boolean showLikeButton(boolean visible) {
        return visible && !hideLikes();
    }

    public static void hideLikeView(View view) {
        if (hideLikes()) view.setVisibility(View.GONE);
    }

    public static boolean hideShareButton() {
        return SharedPref.getBooleanPref(Settings.HIDE_SHARE_BUTTON) && SettingsStatus.hideShareButton;
    }

    /** The surfaces the save button is hidden on; "posts" / "reels" (hide_save_button_surfaces). */
    public static Set<String> hideSaveButtonSurfaces() {
        Set<String> surfaces = SharedPref.getSetPref(Settings.HIDE_SAVE_BUTTON_SURFACES);
        Context context = Utils.getContext();
        var preferences = context == null ? null
                : context.getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);
        if (preferences == null || preferences.contains(Settings.HIDE_SAVE_BUTTON_SURFACES.key)) return surfaces;
        if (SharedPref.getBooleanPref(Settings.HIDE_SAVE_BUTTONS_LEGACY)) {
            surfaces = new HashSet<>(surfaces);
            surfaces.add("posts");
            surfaces.add("reels");
            SharedPref.setSetPref(Settings.HIDE_SAVE_BUTTON_SURFACES.key, surfaces);
        }
        return surfaces;
    }

    public static boolean hideSaveButtons() {
        return hideSaveButtonSurfaces().contains("posts") && SettingsStatus.hideSaveButtons;
    }

    public static boolean hideSaveButtonReels() {
        return hideSaveButtonSurfaces().contains("reels") && SettingsStatus.hideSaveButtons;
    }

    public static boolean showSaveButton(boolean original) {
        return original && !hideSaveButtons();
    }

    // Reels need the native save state to build the download component even when save is hidden.
    public static boolean showReelSaveButton(boolean original) {
        return original && (!hideSaveButtonReels() || ReelDownload.isEnabled());
    }

    public static boolean showReelSaveIcon(boolean original) {
        return original && !hideSaveButtonReels();
    }

    public static boolean hideReshareButton() {
        return SharedPref.getBooleanPref(Settings.HIDE_RESHARE_BUTTON) && SettingsStatus.hideReshareButton;
    }

    public static boolean hideGroupCreationOnSharesheet() {
        return lockable(Settings.HIDE_GROUP_CREATION_BUTTON_ON_SHARESHEET);
    }

       public static boolean showReelsFollowButton(boolean original) {
        boolean hide = lockable(Settings.HIDE_REELS_FOLLOW_BUTTON) && SettingsStatus.hideReelsFollowButton;
        return original && !hide;
    }

    /** Set for one Home long press fired by the Piko menu's "Developer options" card. */
    private static volatile boolean forceDeveloperOptions = false;

    public static void setForceDeveloperOptions(boolean force) {
        forceDeveloperOptions = force;
    }

    public static boolean isForceDeveloperOptions() {
        return forceDeveloperOptions;
    }

    public static boolean enableDevOptions() {
        // Opened on purpose from the Piko menu: always allowed, whatever Home long press is set to.
        if (forceDeveloperOptions) {
            forceDeveloperOptions = false;
            return true;
        }
        // Long-pressing Home can only do one thing: when it opens Piko settings it must not open developer options.
        return SharedPref.getBooleanPref(Settings.DEVELOPER_OPTIONS) && !homeLongPressPikoSettings();
    }
    /** True when Piko settings are opened by long-pressing Home and every Piko settings button is hidden. */
    public static boolean homeLongPressPikoSettings() {
        return SharedPref.getBooleanPref(Settings.HOME_LONG_PRESS_PIKO_SETTINGS);
    }
    public static boolean directlyOpenMetaConfig() {
        return SharedPref.getBooleanPref(Settings.DIRECTLY_OPEN_METACONFIG);
    }
    public static boolean enableEmployeeOptions() {
        return SharedPref.getBooleanPref(Settings.ENABLE_EMP_OPTIONS);
    }
    public static boolean allowUserNetworkCertificate() {
        return SharedPref.getBooleanPref(Settings.ALLOW_USER_NETWORK_CERTIFICATE);
    }

    public static boolean disableAnalytics() {
        return SharedPref.getBooleanPref(Settings.DISABLE_ANALYTICS);
    }

    public static boolean disableDiscoverPeople() {
        return SharedPref.getBooleanPref(Settings.DISABLE_DISCOVER_PEOPLE);
    }

    public static boolean followBackIndicator() {
        return SharedPref.getBooleanPref(Settings.FOLLOW_BACK_INDICATOR);
    }
    public static boolean followBackColorIndicator() {
        return SharedPref.getBooleanPref(Settings.FOLLOW_BACK_COLOR_INDICATOR);
    }

    public static boolean followListNonFollowerBadge() {
        return SharedPref.getBooleanPref(Settings.FOLLOW_LIST_NON_FOLLOWER_BADGE);
    }

    public static boolean disableStoryFlipping() {
        return SharedPref.getBooleanPref(Settings.DISABLE_STORY_FLIPPING);
    }

    public static boolean loopStory() {
        return SharedPref.getBooleanPref(Settings.LOOP_STORY);
    }

    public static int storyFollowButtonState(int original) {
        return SharedPref.getBooleanPref(Settings.HIDE_STORY_FOLLOW_BUTTON) ? 0 : original;
    }

    public static boolean viewStoryMentions() {
        return SharedPref.getBooleanPref(Settings.VIEW_STORY_MENTIONS);
    }

    public static String customiseStoryTimestamp() {
        return SharedPref.getStringPref(Settings.CUSTOMISE_STORY_TIMESTAMP);
    }

    // Takes the width Instagram picks an image variant for. Requests at least as wide as a
    // full-screen view get the widest variant; narrower ones, such as grid tiles, stay unchanged.
    public static int imageVariantTargetWidth(int original) {
        if (!SharedPref.getBooleanPref(Settings.IMPROVE_IMAGE_VIEWING)) return original;
        Activity activity = Utils.getActivity();
        Resources resources = activity != null ? activity.getResources() : Resources.getSystem();
        int fullScreenWidth = Math.min(resources.getDisplayMetrics().widthPixels, FULL_SCREEN_WIDTH_CAP);
        return original >= fullScreenWidth ? WIDEST_VARIANT_TARGET : original;
    }

    public static Integer userAgentScreenSize(Integer original) {
        return SharedPref.getBooleanPref(Settings.IMPROVE_IMAGE_VIEWING) ? USER_AGENT_SCREEN_SIZE : original;
    }

    public static boolean enableDownload() {
        return SharedPref.getBooleanPref(Settings.ENABLE_DOWNLOAD) && SettingsStatus.downloadMedia;
    }

    public static boolean enableDirectDownload() {
        return SharedPref.getBooleanPref(Settings.ENABLE_DIRECT_DOWNLOAD);
    }

    public static boolean downloadUsernameFolder() {
        return SharedPref.getBooleanPref(Settings.DOWNLOAD_USERNAME_FOLDER);
    }

    public static boolean embedDownloadMetadata() {
        return SharedPref.getBooleanPref(Settings.EMBED_DOWNLOAD_METADATA);
    }

    public static boolean preferDashFormat() {
        return SharedPref.getBooleanPref(Settings.PREFER_DASH_FORMAT);
    }

    public static boolean dashAudioAacLc() {
        return SharedPref.getBooleanPref(Settings.DASH_AUDIO_AAC_LC);
    }

    public static String downloadFileNameTemplate() {
        return removeLineBreaks(SharedPref.getStringPref(Settings.DOWNLOAD_FILE_NAME_TEMPLATE));
    }

    public static boolean floatingNavBar() {
        return SharedPref.getBooleanPref(Settings.FLOATING_NAV_BAR);
    }

    public static boolean nativeFloatingNav() {
        return SharedPref.getBooleanPref(Settings.NATIVE_FLOATING_NAV);
    }

    public static boolean nativeFloatingNavBlur() {
        return SharedPref.getBooleanPref(Settings.NATIVE_FLOATING_NAV_BLUR);
    }

    /** Strength of the blur behind Instagram's own floating bar, 0 to 100 (0 = no blur). */
    public static int nativeFloatingNavBlurLevel() {
        return percent(SharedPref.getStringPref(Settings.NATIVE_FLOATING_NAV_BLUR_LEVEL), 50);
    }

    /** How see-through the glass of Instagram's own floating bar is, 0 to 100 (0 = solid). */
    public static int nativeFloatingNavTransparency() {
        return percent(SharedPref.getStringPref(Settings.NATIVE_FLOATING_NAV_TRANSPARENCY), 50);
    }

    public static boolean setNativeFloatingNavBlurLevel(int percent) {
        return SharedPref.setStringPref(Settings.NATIVE_FLOATING_NAV_BLUR_LEVEL.key,
                String.valueOf(Math.max(0, Math.min(100, percent))));
    }

    public static boolean setNativeFloatingNavTransparency(int percent) {
        return SharedPref.setStringPref(Settings.NATIVE_FLOATING_NAV_TRANSPARENCY.key,
                String.valueOf(Math.max(0, Math.min(100, percent))));
    }

    private static int percent(String stored, int fallback) {
        if (stored == null) return fallback;
        try {
            return Math.max(0, Math.min(100, Integer.parseInt(stored.trim())));
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    public static boolean hideGestureLine() {
        return SharedPref.getBooleanPref(Settings.HIDE_GESTURE_LINE);
    }

    public static boolean removeSelectedTabPill() {
        return SharedPref.getBooleanPref(Settings.REMOVE_SELECTED_TAB_PILL);
    }

    /** The highlight behind the selected tab of the floating navigation bar is drawn from the user's picture. */
    public static boolean customTabPill() {
        return SharedPref.getBooleanPref(Settings.CUSTOM_TAB_PILL);
    }

    /** The highlight can be pressed and held, moved to another tab and let go there to open that tab. */
    public static boolean tabPillDrag() {
        return SharedPref.getBooleanPref(Settings.CUSTOM_TAB_PILL_DRAG);
    }

    public static boolean reelsAmbient() {
        return SharedPref.getBooleanPref(Settings.REELS_AMBIENT);
    }

    /** Distance of the floating bar from each side of the screen, in dp (a larger value is a narrower pill). */
    public static int floatingNavSideDp() {
        return FloatingNavSize.clampSide(FloatingNavSize.parse(
                SharedPref.getStringPref(Settings.FLOATING_NAV_SIDE_DP), FloatingNavSize.SIDE_DEFAULT_DP));
    }

    /** Air above and below the floating bar's pill, in dp (a larger value is a lower pill). */
    public static int floatingNavGapDp() {
        return FloatingNavSize.clampGap(FloatingNavSize.parse(
                SharedPref.getStringPref(Settings.FLOATING_NAV_GAP_DP), FloatingNavSize.GAP_DEFAULT_DP));
    }

    /** Distance between the bottom of the screen and the floating bar, in dp (a larger value floats higher). */
    public static int floatingNavBottomDp() {
        return FloatingNavSize.clampBottom(FloatingNavSize.parse(
                SharedPref.getStringPref(Settings.FLOATING_NAV_BOTTOM_DP), FloatingNavSize.BOTTOM_DEFAULT_DP));
    }

    public static boolean setFloatingNavBottomDp(int dp) {
        return SharedPref.setStringPref(Settings.FLOATING_NAV_BOTTOM_DP.key,
                String.valueOf(FloatingNavSize.clampBottom(dp)));
    }

    public static boolean setFloatingNavSideDp(int dp) {
        return SharedPref.setStringPref(Settings.FLOATING_NAV_SIDE_DP.key,
                String.valueOf(FloatingNavSize.clampSide(dp)));
    }

    public static boolean setFloatingNavGapDp(int dp) {
        return SharedPref.setStringPref(Settings.FLOATING_NAV_GAP_DP.key,
                String.valueOf(FloatingNavSize.clampGap(dp)));
    }

    public static boolean hideNavigationFeed() {
        return SharedPref.getBooleanPref(Settings.HIDE_NAVIGATION_FEED);
    }

    public static boolean getHideHomeCreateButton() {
        return !mainFeedActionBarButtons().contains(Constants.AB_CREATE);
    }

    public static boolean getHideHomeNotificationsButton() {
        return !mainFeedActionBarButtons().contains(Constants.AB_NOTIFICATIONS);
    }

    public static boolean hideNavigationReels() {
        return SharedPref.getBooleanPref(Settings.HIDE_NAVIGATION_REELS);
    }

    public static boolean hideNavigationDirect() {
        return SharedPref.getBooleanPref(Settings.HIDE_NAVIGATION_DIRECT);
    }

    public static boolean hideNavigationSearch() {
        return SharedPref.getBooleanPref(Settings.HIDE_NAVIGATION_SEARCH);
    }

    public static boolean hideNavigationCreate() {
        return SharedPref.getBooleanPref(Settings.HIDE_NAVIGATION_CREATE);
    }

    public static boolean hasLegacyNavigationSettings() {
        return SharedPref.hasKey(Settings.HIDE_NAVIGATION_FEED.key)
                || SharedPref.hasKey(Settings.HIDE_NAVIGATION_REELS.key)
                || SharedPref.hasKey(Settings.HIDE_NAVIGATION_DIRECT.key)
                || SharedPref.hasKey(Settings.HIDE_NAVIGATION_SEARCH.key)
                || SharedPref.hasKey(Settings.HIDE_NAVIGATION_CREATE.key);
    }

    public static String navigationTabs() {
        return SharedPref.getStringPref(Settings.NAVIGATION_TABS);
    }

    public static boolean setNavigationTabs(String value) {
        return SharedPref.setStringPref(Settings.NAVIGATION_TABS.key, value);
    }

    public static boolean removeEmptyBottomSpace() {
        return SharedPref.getBooleanPref(Settings.REMOVE_EMPTY_BOTTOM_SPACE);
    }

    public static boolean commentCopyButton() {
        return SharedPref.getBooleanPref(Settings.COMMENT_COPY_BUTTON) && SettingsStatus.copyCommentButton;
    }

    public static boolean commentSaveMediaButton() {
        return SharedPref.getBooleanPref(Settings.COMMENT_SAVE_MEDIA_BUTTON) && SettingsStatus.saveMediaCommentButton;
    }

    public static String changeLikeAnimation() {
        return SharedPref.getStringPref(Settings.CHANGE_LIKE_ANIMATION);
    }

    public static float customiseStoryRingSize() {
        try {
            return Float.parseFloat(SharedPref.getStringPref(Settings.CUSTOMISE_STORY_RING_SIZE));
        } catch (Exception ex) {
            return 100.0f;
        }
    }

    public static boolean disableDoubleTapLike() {
        return lockable(Settings.DISABLE_DOUBLE_TAP_LIKE);
    }
    public static boolean moreOptionsOnPost() {
        return SharedPref.getBooleanPref(Settings.ENABLE_MORE_OPTIONS_ON_POST) && SettingsStatus.moreOptionsOnPost;
    }
    public static boolean downloadWithExternalDownloader() {
        return SharedPref.getBooleanPref(Settings.DOWNLOAD_WITH_EXTERNAL_DOWNLOADER) && SettingsStatus.downloadWithExternalDownloader;
    }

    public static String externalDownloaderPackageName() {
        return removeLineBreaks(SharedPref.getStringPref(Settings.EXTERNAL_DOWNLOADER_PACKAGE_NAME));
    }

    public static Set<String> mainFeedActionBarButtons() {
        return loadAndMigrateActionBarButtons(Settings.ACTION_BAR_MAIN_FEED, true);
    }

    public static Set<String> userProfileActionBarButtons() {
        return loadAndMigrateActionBarButtons(Settings.ACTION_BAR_USER_PROFILE, false);
    }

    private static Set<String> loadAndMigrateActionBarButtons(StringSetting setting, boolean home) {
        Set<String> buttons = SharedPref.getSetPref(setting);
        Context context = Utils.getContext();
        var preferences = context == null ? null
                : context.getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);
        String migratedKey = setting.key + "_visibility_migrated";
        if (preferences != null && preferences.getBoolean(migratedKey, false)) return buttons;

        String createKey = Settings.HIDE_HOME_CREATE_BUTTON.key;
        String notificationsKey = Settings.HIDE_HOME_NOTIFICATIONS_BUTTON.key;
        buttons = new HashSet<>(buttons);
        boolean hideCreate = buttons.remove("HIDE_CREATE");
        if (home && preferences != null) hideCreate |= preferences.getBoolean(createKey, false);
        if (!hideCreate) buttons.add(Constants.AB_CREATE);
        if (home) {
            boolean hideNotifications = buttons.remove("HIDE_NOTIFICATIONS");
            if (preferences != null) hideNotifications |= preferences.getBoolean(notificationsKey, false);
            if (!hideNotifications) buttons.add(Constants.AB_NOTIFICATIONS);
        }
        if (preferences != null) {
            var editor = preferences.edit().putStringSet(setting.key, buttons).putBoolean(migratedKey, true);
            if (home) editor.remove(createKey).remove(notificationsKey);
            editor.apply();
        }
        return buttons;
    }

    public static Set<String> chatActionBarButtons() {
        return SharedPref.getSetPref(Settings.ACTION_BAR_CHAT);
    }

    public static synchronized Set<String> chatActionsWithCallDefaults() {
        Set<String> actions = chatActionBarButtons();
        Context context = Utils.getContext();
        var preferences = context == null ? null
                : context.getSharedPreferences(Constants.SHARED_PREF_NAME, Context.MODE_PRIVATE);
        String initializedKey = "action_bar_chat_call_icons_initialized";
        if (preferences != null && preferences.getBoolean(initializedKey, false)) return actions;

        // Without this marker, an empty call selection could mean either first use or both icons hidden.
        actions = new HashSet<>(actions);
        actions.add(Constants.AB_AUDIO_CALL_ICON);
        actions.add(Constants.AB_VIDEO_CALL_ICON);
        if (preferences != null) {
            preferences.edit().putStringSet(Settings.ACTION_BAR_CHAT.key, actions)
                    .putBoolean(initializedKey, true).apply();
        }
        return actions;
    }

    public static boolean showChatAudioCallButton(boolean available) {
        return available && chatActionsWithCallDefaults().contains(Constants.AB_AUDIO_CALL_ICON);
    }

    public static boolean showChatVideoCallButton(boolean available) {
        return available && chatActionsWithCallDefaults().contains(Constants.AB_VIDEO_CALL_ICON);
    }

    public static Set<String> inboxActionBarButtons() {
        return SharedPref.getSetPref(Settings.ACTION_BAR_INBOX);
    }

    public static Set<String> filterStoryByType() {
        return SharedPref.getSetPref(Settings.FILTER_STORY_BY_TYPE);
    }

    public static Set<String> filterStoryByUserType() {
        return SharedPref.getSetPref(Settings.FILTER_STORY_BY_USER_TYPE);
    }

    public static Integer filterStoryByMinStoryItems() {
        return Integer.valueOf(SharedPref.getStringPref(Settings.FILTER_STORY_MIN_STORY_ITEMS));
    }

    public static Integer filterStoryByMaxStoryItems() {
        return Integer.valueOf(SharedPref.getStringPref(Settings.FILTER_STORY_MAX_STORY_ITEMS));
    }

    public static boolean inboxLock() {
        return SharedPref.getBooleanPref(Settings.INBOX_LOCK);
    }

    public static boolean inboxLockNotifications() {
        return SharedPref.getBooleanPref(Settings.INBOX_LOCK_NOTIFICATIONS);
    }

    public static boolean hiddenChats() {
        return SharedPref.getBooleanPref(Settings.HIDDEN_CHATS);
    }

    public static boolean hiddenChatsMute() {
        return SharedPref.getBooleanPref(Settings.HIDDEN_CHATS_MUTE);
    }

    public static int hiddenChatsTaps() {
        try {
            return Integer.parseInt(SharedPref.getStringPref(Settings.HIDDEN_CHATS_TAPS));
        } catch (NumberFormatException e) {
            return 3;
        }
    }
}
